package com.mitoolapp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val partList = listOf("boot", "init_boot", "vendor_boot", "dtbo", "recovery")
private val stageNames = listOf("1. Gathering Images", "2. Flash Fastboot Images", "3. Waiting for Sideload Mode", "4. Flashing ROM Sideload")

private fun stageState(i: Int): String = when {
    Ui.aospFail && Ui.aospStage == i -> "fail"
    Ui.aospDone && i == 4 -> "ok"
    Ui.aospStage > i -> "ok"
    Ui.aospStage == i -> "running"
    else -> ""
}

/** A box that glows: pulsing accent while running, steady green when done, pulsing red when failed. */
@Composable
private fun StateBox(state: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val p by pulse(800)
    val color = when (state) {
        "running" -> Accent
        "ok" -> Green
        "fail" -> Danger
        else -> Color(0xFF2A3B4F)
    }
    val g = when (state) {
        "running", "fail" -> p
        "ok" -> 0.8f
        else -> 0f
    }
    Box(
        modifier.glow(color, g, corner = 12.dp, spread = 10.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (state.isEmpty() || state == "pending" || state == "skipped") CardHi else color.copy(alpha = 0.16f))
            .border(1.dp, color, RoundedCornerShape(12.dp))
            .alpha(if (state == "skipped") 0.4f else 1f),
        contentAlignment = Alignment.CenterStart
    ) { content() }
}

internal fun LazyListScope.aospSideloadItems(a: Actions) {
    item {
        Appear(0) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("AOSP ADB Sideload", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("ZIP + IMG", fontSize = 12.sp, color = TextDim)
                    }
                    Pill("FASTBOOT > RECOVERY > SIDELOAD", Accent2)
                }
            }
        }
    }
    item {
        Appear(1) {
            Panel(
                "Custom AOSP ROM (.zip)",
                "Select the ROM zip, flash the images found inside it with fastboot, reboot to recovery, then choose ADB sideload on the phone. The same zip is then sideloaded automatically."
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        Ui.aospZipName ?: "No ROM selected",
                        fontSize = 12.sp, fontFamily = FontFamily.Monospace, maxLines = 2,
                        modifier = Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(CardHi).padding(10.dp)
                    )
                    OutlinedButton(onClick = a.pickAospZip, enabled = !Ui.busy, border = BorderStroke(1.dp, Accent)) {
                        Text("Browse ZIP", color = Accent)
                    }
                }
                Text("Fastboot partitions to flash (optional; missing ROM images are skipped)", fontSize = 11.sp, color = TextDim)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    partList.forEach { part ->
                        StateBox(Ui.aospState[part] ?: "") {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 12.dp)) {
                                Checkbox(
                                    checked = Ui.aospParts[part] == true,
                                    onCheckedChange = { Ui.aospParts[part] = it },
                                    enabled = !Ui.busy
                                )
                                Text(part, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    stageNames.chunked(2).forEachIndexed { row, pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            pair.forEachIndexed { col, name ->
                                val idx = row * 2 + col + 1
                                StateBox(stageState(idx), Modifier.weight(1f)) {
                                    Text(name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 2,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp))
                                }
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = a.startAosp,
                        enabled = Ui.aospZipName != null && Ui.connected && !Ui.busy,
                        modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(25.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF00382B))
                    ) {
                        Icon(Icons.Filled.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Start Auto Flash", fontWeight = FontWeight.Bold)
                    }
                    if (Ui.isActive("aosp")) {
                        OutlinedButton(onClick = a.cancelAosp, border = BorderStroke(1.dp, Danger)) { Text("Cancel", color = Danger) }
                    }
                }
                if (Ui.aospMsg.isNotEmpty()) {
                    Text(Ui.aospMsg, fontSize = 12.sp, color = if (Ui.aospFail) Danger else if (Ui.aospDone) Green else Accent)
                }
                Text(
                    if (!Ui.connected) "Connect the phone in fastboot mode first."
                    else if (Ui.transport == "fastboot") "Connected: ${Ui.deviceName} (fastboot)"
                    else "Connected over ADB: image flashing is skipped, only sideload runs.",
                    fontSize = 11.sp, color = if (Ui.connected) Green else Danger
                )
                Text(
                    "No automatic format data or recovery menu action. You choose ADB sideload on the phone. " +
                        "Transfer progress is reported by ADB and is not a guarantee of a completed installation. " +
                        "Payload-only OTA zips have no boot/vendor_boot images: those partitions are skipped.",
                    fontSize = 11.sp, color = TextDim
                )
            }
        }
    }
    item { Appear(2) { LogCard(maxLines = 40) } }
}
