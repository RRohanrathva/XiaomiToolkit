# MiToolApp (standalone)

Material 3 Android app, no Termux needed. Fastboot runs over USB OTG inside the app.

- Fixed top bar: auto USB scan, device name, mode, battery voltage, glowing status
- ROMs: Stock ROM Xiaomi (finder), Official AOSP ROMs, Download Manager (one screen, tabs)
- Flash: Stock ROM flash (Clean All / Save User Data / Clean All + Lock), single image, fastboot commands
- Extract: zip (password too), 7z, rar (RAR4), tgz; pick files, save to a folder, flash .img
- Bootloader Unlock: Xiaomi account login + official unlock server flow
  (port of MiForge/MiUnlockTool, Apache-2.0 and MiForge/migate, MIT)
- Floating reboot manager on every screen (reboots the connected USB phone)

Build: GitHub -> Actions -> run the workflow -> download the APK artifact.
