package com.mitoolapp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TermBg = Color(0xFF05080D)
private val Mono = FontFamily.Monospace

/** Termux-style terminal for fastboot and adb commands, with saved commands and ROM sideload. */
@Composable
internal fun TerminalScreen(a: Actions, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(loadSaved(ctx)) }
    val listState = rememberLazyListState()

    LaunchedEffect(Ui.term.size) {
        if (Ui.term.isNotEmpty()) listState.scrollToItem(Ui.term.size - 1)
    }

    fun run(text: String) {
        if (text.isBlank()) return
        a.runTerm(text)
        input = ""
    }

    Column(modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ADB / Fastboot Terminal", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (Ui.connected) "${Ui.deviceName} · ${Ui.mode}" else "No device. Type help for commands.",
                    fontSize = 11.sp, color = if (Ui.connected) Green else TextDim
                )
            }
            TextButton(onClick = { Ui.term.clear() }) { Text("Clear") }
        }

        // output area
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(TermBg)
                .border(BorderStroke(1.dp, Color(0xFF1E2C3D)), RoundedCornerShape(14.dp))
        ) {
            if (Ui.term.isEmpty()) {
                Text(
                    "MiTool terminal\nConnect a phone, then type e.g.\n  fastboot getvar product\n  adb shell getprop ro.product.model\nType help for all commands.",
                    fontFamily = Mono, fontSize = 12.sp, color = TextDim, modifier = Modifier.padding(12.dp)
                )
            }
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 8.dp)) {
                items(Ui.term.toList()) { line ->
                    if (line.startsWith("$ ")) {
                        Row(Modifier.clickable { input = line.removePrefix("$ ") }) {
                            Text("$ ", fontFamily = Mono, fontSize = 13.sp, color = Accent, fontWeight = FontWeight.Bold)
                            Text(line.removePrefix("$ "), fontFamily = Mono, fontSize = 13.sp, color = Color.White)
                        }
                    } else {
                        val c = when {
                            line.startsWith("FAIL") || line.startsWith("error") || line.contains("failed") -> Danger
                            line.startsWith("OKAY") || line.startsWith("done") -> Green
                            else -> Color(0xFFC9D4E0)
                        }
                        Text(line.ifEmpty { " " }, fontFamily = Mono, fontSize = 12.sp, color = c)
                    }
                }
            }
        }

        // quick chips
        val quick = if (Ui.transport == "adb")
            listOf("adb devices", "adb shell getprop ro.product.model", "adb shell getprop ro.build.version.release",
                "adb shell dumpsys battery", "adb logcat -d", "adb reboot recovery", "adb reboot bootloader")
        else
            listOf("fastboot getvar product", "fastboot getvar all", "fastboot getvar unlocked", "fastboot getvar current-slot",
                "fastboot getvar max-download-size", "fastboot oem device-info", "fastboot reboot")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            quick.forEach { q -> AssistChip(onClick = { input = q }, label = { Text(q.removePrefix("adb ").removePrefix("fastboot "), fontSize = 11.sp) }) }
        }

        // sideload
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = a.pickSideload, enabled = Ui.transport == "adb" && !Ui.busy,
                shape = RoundedCornerShape(20.dp), modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Accent2)
            ) { Text("Sideload ROM (.zip)", fontSize = 12.sp, maxLines = 1) }
            OutlinedButton(
                onClick = { a.reboot("sideload") }, enabled = Ui.transport == "adb" && !Ui.busy,
                shape = RoundedCornerShape(20.dp), modifier = Modifier.weight(1f)
            ) { Text("Reboot to sideload", fontSize = 12.sp, maxLines = 1) }
        }

        // saved commands
        if (saved.isNotEmpty()) {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 120.dp).clip(RoundedCornerShape(12.dp))
                    .background(CardBg).verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("Saved commands", fontSize = 11.sp, color = TextDim)
                saved.forEach { s ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "$ $s", fontFamily = Mono, fontSize = 12.sp, maxLines = 1,
                            modifier = Modifier.weight(1f).clickable { input = s }.padding(vertical = 6.dp)
                        )
                        Text("Run", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { run(s) }.padding(horizontal = 10.dp, vertical = 6.dp))
                        Text("X", color = Danger, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { saved = saved - s; storeSaved(ctx, saved) }.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
            }
        }

        // input row with automatic $ prompt
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(TermBg)
                .border(BorderStroke(1.dp, Accent.copy(alpha = 0.5f)), RoundedCornerShape(14.dp))
                .padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("$", fontFamily = Mono, fontSize = 16.sp, color = Accent, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = input, onValueChange = { input = it },
                textStyle = TextStyle(color = Color.White, fontFamily = Mono, fontSize = 14.sp),
                cursorBrush = SolidColor(Accent), singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { run(input) }),
                modifier = Modifier.weight(1f).padding(vertical = 12.dp),
                decorationBox = { inner ->
                    if (input.isEmpty()) Text("type a command...", fontFamily = Mono, fontSize = 14.sp, color = TextDim)
                    inner()
                }
            )
            TextButton(onClick = {
                val c = input.trim()
                if (c.isNotEmpty() && c !in saved) { saved = (saved + c).sorted(); storeSaved(ctx, saved) }
            }, enabled = input.isNotBlank()) { Text("Save", fontSize = 12.sp) }
            TextButton(onClick = { run(input) }, enabled = input.isNotBlank()) {
                Text("Run", color = Accent, fontWeight = FontWeight.Bold)
            }
        }
    }
}
