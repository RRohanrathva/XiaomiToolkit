package com.mitoolapp

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbManager
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.Signature
import java.security.interfaces.RSAPrivateCrtKey
import java.security.spec.PKCS8EncodedKeySpec

class AdbException(msg: String) : IOException(msg)

/**
 * ADB over USB host mode (own implementation of the public ADB wire protocol:
 * CNXN / AUTH / OPEN / OKAY / WRTE / CLSE). Supports shell, simple services (reboot:, root:)
 * and ROM sideload (sideload-host).
 */
class Adb private constructor(
    private val conn: UsbDeviceConnection,
    private val epIn: UsbEndpoint,
    private val epOut: UsbEndpoint,
    private val log: (String) -> Unit
) {
    var banner: String = ""
        private set
    private var maxData = 4096
    private var nextId = 1

    private class Msg(val cmd: Int, val a0: Int, val a1: Int, val data: ByteArray)

    companion object {
        private const val A_SYNC = 0x434e5953
        private const val A_CNXN = 0x4e584e43
        private const val A_AUTH = 0x48545541
        private const val A_OPEN = 0x4e45504f
        private const val A_OKAY = 0x59414b4f
        private const val A_CLSE = 0x45534c43
        private const val A_WRTE = 0x45545257
        private const val VERSION = 0x01000001
        private const val MAX_PAYLOAD = 256 * 1024

        private val SHA1_PREFIX = byteArrayOf(
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
        )

        private fun isAdb(d: UsbDevice, idx: Int): Boolean {
            val i = d.getInterface(idx)
            return i.interfaceClass == 0xFF && i.interfaceSubclass == 0x42 && i.interfaceProtocol == 0x01
        }

        fun find(m: UsbManager): UsbDevice? =
            m.deviceList.values.firstOrNull { d -> (0 until d.interfaceCount).any { isAdb(d, it) } }

        fun open(ctx: Context, m: UsbManager, d: UsbDevice, log: (String) -> Unit): Adb {
            val idx = (0 until d.interfaceCount).firstOrNull { isAdb(d, it) }
                ?: throw AdbException("Device has no ADB interface")
            val iface = d.getInterface(idx)
            val conn = m.openDevice(d) ?: throw AdbException("Could not open the USB device")
            if (!conn.claimInterface(iface, true)) {
                conn.close()
                throw AdbException("Could not claim the ADB interface")
            }
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (e in 0 until iface.endpointCount) {
                val ep = iface.getEndpoint(e)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
            }
            if (inEp == null || outEp == null) {
                conn.close()
                throw AdbException("ADB endpoints not found")
            }
            val adb = Adb(conn, inEp, outEp, log)
            try {
                adb.handshake(loadKey(ctx))
            } catch (e: Exception) {
                adb.close()
                throw e
            }
            return adb
        }

        // ----- RSA key (stored in the app's private storage) -----

        private fun loadKey(ctx: Context): PrivateKey {
            val f = File(ctx.filesDir, "adbkey")
            val kf = KeyFactory.getInstance("RSA")
            if (f.exists()) {
                try {
                    return kf.generatePrivate(PKCS8EncodedKeySpec(f.readBytes()))
                } catch (_: Exception) {
                    f.delete()
                }
            }
            val g = KeyPairGenerator.getInstance("RSA")
            g.initialize(2048)
            val pair = g.generateKeyPair()
            f.writeBytes(pair.private.encoded)
            return pair.private
        }

        private fun le32(v: Long): ByteArray =
            ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v.toInt()).array()

        /** Public key in the format Android's adbd expects (base64 of struct RSAPublicKey + name). */
        fun publicKeyBlob(key: PrivateKey): ByteArray {
            val k = key as RSAPrivateCrtKey
            val n = k.modulus
            val e = k.publicExponent
            val words = 64
            val two32 = BigInteger.ONE.shiftLeft(32)
            val n0inv = n.mod(two32).modInverse(two32).negate().mod(two32)
            val rr = BigInteger.ONE.shiftLeft(2048 * 2).mod(n)
            val out = ByteArrayOutputStream()
            out.write(le32(words.toLong()))
            out.write(le32(n0inv.toLong()))
            fun writeWords(v: BigInteger) {
                var x = v
                for (i in 0 until words) {
                    out.write(le32(x.mod(two32).toLong()))
                    x = x.shiftRight(32)
                }
            }
            writeWords(n)
            writeWords(rr)
            out.write(le32(e.toLong()))
            val b64 = Base64.encode(out.toByteArray(), Base64.NO_WRAP)
            return b64 + " mitool@android".toByteArray() + byteArrayOf(0)
        }
    }

    // ----- raw messages -----

    private fun send(cmd: Int, a0: Int, a1: Int, data: ByteArray = ByteArray(0)) {
        val h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        h.putInt(cmd).putInt(a0).putInt(a1).putInt(data.size).putInt(0).putInt(cmd.inv())
        writeAll(h.array())
        if (data.isNotEmpty()) writeAll(data)
    }

    private fun writeAll(b: ByteArray) {
        var off = 0
        while (off < b.size) {
            val n = minOf(16384, b.size - off)
            val r = conn.bulkTransfer(epOut, b, off, n, 10000)
            if (r < 0) throw AdbException("USB write failed")
            off += r
        }
        // exact multiple of the packet size needs a zero-length packet on some devices; adbd copes without
    }

    private fun readExact(len: Int, timeoutMs: Int): ByteArray {
        val buf = ByteArray(len)
        var off = 0
        while (off < len) {
            val r = conn.bulkTransfer(epIn, buf, off, minOf(16384, len - off), timeoutMs)
            if (r < 0) throw AdbException("USB read timed out or device disconnected")
            off += r
        }
        return buf
    }

    private fun recv(timeoutMs: Int): Msg {
        val h = ByteBuffer.wrap(readExact(24, timeoutMs)).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = h.int
        val a0 = h.int
        val a1 = h.int
        val len = h.int
        h.int // data checksum (not used)
        val magic = h.int
        if (magic != cmd.inv()) throw AdbException("Bad ADB message")
        if (len < 0 || len > MAX_PAYLOAD * 4) throw AdbException("Bad ADB length")
        val data = if (len > 0) readExact(len, 10000) else ByteArray(0)
        return Msg(cmd, a0, a1, data)
    }

    // ----- connect + auth -----

    private fun handshake(key: PrivateKey) {
        send(A_CNXN, VERSION, MAX_PAYLOAD, "host::features=shell_v1\u0000".toByteArray())
        var sentKey = false
        var tries = 0
        while (true) {
            val wait = if (sentKey) 60000 else 8000
            val m = recv(wait)
            when (m.cmd) {
                A_CNXN -> {
                    banner = String(m.data).trimEnd('\u0000')
                    maxData = m.a1.coerceIn(4096, MAX_PAYLOAD)
                    return
                }
                A_AUTH -> {
                    if (m.a0 != 1) continue
                    if (tries++ == 0) {
                        val sig = Signature.getInstance("NONEwithRSA")
                        sig.initSign(key)
                        sig.update(SHA1_PREFIX + m.data)
                        send(A_AUTH, 2, 0, sig.sign())
                    } else if (!sentKey) {
                        log("Allow USB debugging on the phone screen (tick \"Always allow\")")
                        send(A_AUTH, 3, 0, publicKeyBlob(key))
                        sentKey = true
                    } else {
                        throw AdbException("USB debugging was not allowed on the phone")
                    }
                }
                else -> { /* ignore */ }
            }
        }
    }

    // ----- streams -----

    /** Run a service (for example "shell:ls" or "reboot:recovery") and stream its output. */
    fun service(name: String, onData: (ByteArray) -> Unit, timeoutMs: Int = 30000) {
        val local = nextId++
        send(A_OPEN, local, 0, (name + "\u0000").toByteArray())
        var remote = 0
        while (true) {
            val m = try {
                recv(timeoutMs)
            } catch (e: AdbException) {
                if (name.startsWith("reboot")) return   // phone often drops off before answering
                throw e
            }
            when (m.cmd) {
                A_OKAY -> if (m.a1 == local) remote = m.a0
                A_WRTE -> {
                    if (m.a1 == local) {
                        onData(m.data)
                        send(A_OKAY, local, m.a0)
                    }
                }
                A_CLSE -> {
                    if (remote == 0 || m.a1 == local) {
                        if (remote != 0) send(A_CLSE, local, remote)
                        return
                    }
                }
            }
        }
    }

    fun shell(cmd: String, timeoutMs: Int = 120000, onText: (String) -> Unit) {
        service("shell:$cmd", { onText(String(it)) }, timeoutMs)
    }

    fun close() {
        try { conn.close() } catch (_: Exception) {}
    }

    /**
     * ROM sideload (what `adb sideload file.zip` does). The phone must already be in
     * recovery "Apply update from ADB" mode.
     */
    fun sideload(ch: FileChannel, progress: (Long, Long) -> Unit) {
        val size = ch.size()
        val block = 64 * 1024
        val local = nextId++
        send(A_OPEN, local, 0, "sideload-host:$size:$block\u0000".toByteArray())
        var remote = 0
        val buf = ByteArray(block)
        var lastBlock = -1L
        var done = false
        while (!done) {
            val m = recv(60000)
            when (m.cmd) {
                A_OKAY -> if (m.a1 == local && remote == 0) remote = m.a0
                A_CLSE -> { if (remote != 0) send(A_CLSE, local, remote); done = true }
                A_WRTE -> {
                    if (m.a1 != local) continue
                    send(A_OKAY, local, m.a0)
                    val txt = String(m.data).trim()
                    if (txt.startsWith("DONEDONE")) { done = true; continue }
                    if (txt.startsWith("FAIL")) throw AdbException("Phone refused the package: $txt")
                    val idx = txt.toLongOrNull() ?: throw AdbException("Unexpected reply from phone: $txt")
                    val off = idx * block
                    if (off >= size) throw AdbException("Phone asked for a block outside the file")
                    java.util.Arrays.fill(buf, 0)
                    val want = minOf(block.toLong(), size - off).toInt()
                    val bb = ByteBuffer.wrap(buf, 0, want)
                    var pos = off
                    while (bb.hasRemaining()) {
                        val r = ch.read(bb, pos)
                        if (r < 0) break
                        pos += r
                    }
                    // send in chunks of at most the phone's max payload, waiting for OKAY each time
                    var sent = 0
                    while (sent < block) {
                        val n = minOf(maxData, block - sent)
                        send(A_WRTE, local, remote, buf.copyOfRange(sent, sent + n))
                        sent += n
                        waitOkay(local)
                    }
                    if (idx != lastBlock) {
                        lastBlock = idx
                        progress(minOf(off + block, size), size)
                    }
                }
            }
        }
        progress(size, size)
    }

    private fun waitOkay(local: Int) {
        while (true) {
            val m = recv(60000)
            if (m.cmd == A_OKAY && m.a1 == local) return
            if (m.cmd == A_CLSE && m.a1 == local) throw AdbException("Phone closed the sideload")
            // anything else is ignored; the next block request is read again by the main loop
            // only after this chunk is acknowledged, so this is rare
        }
    }
}
