package com.mitoolapp

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbManager
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

class FastbootException(message: String) : Exception(message)

// ---------------------------------------------------------------------------
// Data sources (streamed to the device, never fully held in memory)
// ---------------------------------------------------------------------------

typealias Sink = (ByteArray, Int, Int) -> Unit

interface DataSource {
    val size: Long
    fun writeTo(sink: Sink)
}

sealed interface Segment {
    val length: Long
    fun writeTo(sink: Sink)
}

class BytesSeg(private val data: ByteArray) : Segment {
    override val length get() = data.size.toLong()
    override fun writeTo(sink: Sink) = sink(data, 0, data.size)
}

/** Bytes [off, off+length) of a file; anything at or beyond fileLen is sent as zeros. */
class FileSeg(
    private val ch: FileChannel,
    private val off: Long,
    override val length: Long,
    private val fileLen: Long
) : Segment {
    override fun writeTo(sink: Sink) {
        val buf = ByteArray(1 shl 20)
        var done = 0L
        while (done < length) {
            val n = minOf(buf.size.toLong(), length - done).toInt()
            val pos = off + done
            val want = minOf(n.toLong(), maxOf(0L, fileLen - pos)).toInt()
            var got = 0
            while (got < want) {
                val bb = ByteBuffer.wrap(buf, got, want - got)
                val r = ch.read(bb, pos + got)
                if (r < 0) throw IOException("Unexpected end of file")
                got += r
            }
            if (want < n) java.util.Arrays.fill(buf, want, n, 0.toByte())
            sink(buf, 0, n)
            done += n
        }
    }
}

class SegSource(private val segs: List<Segment>) : DataSource {
    override val size: Long = segs.sumOf { it.length }
    override fun writeTo(sink: Sink) = segs.forEach { it.writeTo(sink) }
}

// ---------------------------------------------------------------------------
// Android sparse image support (parse + re-split to fit max-download-size)
// ---------------------------------------------------------------------------

object Sparse {
    private const val MAGIC = 0xED26FF3A.toInt()
    private const val RAW = 0xCAC1
    private const val FILL = 0xCAC2
    private const val DONT = 0xCAC3
    private const val CRC = 0xCAC4
    private const val BLK_DEFAULT = 4096

    class Chunk(val type: Int, val blocks: Long, val dataOff: Long, val fill: ByteArray?)
    class Info(val blkSz: Int, val totalBlks: Long, val chunks: List<Chunk>)

    private fun readAt(ch: FileChannel, pos: Long, len: Int): ByteBuffer {
        val bb = ByteBuffer.allocate(len).order(ByteOrder.LITTLE_ENDIAN)
        var p = pos
        while (bb.hasRemaining()) {
            val r = ch.read(bb, p)
            if (r < 0) throw IOException("Unexpected end of sparse file")
            p += r
        }
        bb.flip()
        return bb
    }

    fun isSparse(ch: FileChannel): Boolean =
        ch.size() >= 28 && readAt(ch, 0, 4).int == MAGIC

    fun parse(ch: FileChannel): Info {
        val h = readAt(ch, 0, 28)
        if (h.getInt(0) != MAGIC) throw IOException("Not a sparse image")
        val fileHdr = h.getShort(8).toInt() and 0xFFFF
        val chunkHdr = h.getShort(10).toInt() and 0xFFFF
        val blk = h.getInt(12)
        val totalBlks = h.getInt(16).toLong() and 0xFFFFFFFFL
        val totalChunks = h.getInt(20).toLong() and 0xFFFFFFFFL
        var pos = fileHdr.toLong()
        val chunks = ArrayList<Chunk>()
        for (i in 0 until totalChunks) {
            val c = readAt(ch, pos, 12)
            val type = c.getShort(0).toInt() and 0xFFFF
            val blocks = c.getInt(4).toLong() and 0xFFFFFFFFL
            val total = c.getInt(8).toLong() and 0xFFFFFFFFL
            val dataOff = pos + chunkHdr
            val fill = if (type == FILL) readAt(ch, dataOff, 4).array() else null
            chunks.add(Chunk(type, blocks, dataOff, fill))
            pos += total
        }
        return Info(blk, totalBlks, chunks)
    }

    /** Treat a raw image as a sparse image with one RAW chunk (last block zero padded). */
    fun fromRaw(size: Long): Info {
        val blocks = (size + BLK_DEFAULT - 1) / BLK_DEFAULT
        return Info(BLK_DEFAULT, blocks, listOf(Chunk(RAW, blocks, 0, null)))
    }

    private fun header(blk: Int, totalBlks: Long, chunks: Int): ByteArray =
        ByteBuffer.allocate(28).order(ByteOrder.LITTLE_ENDIAN).apply {
            putInt(MAGIC); putShort(1); putShort(0); putShort(28); putShort(12)
            putInt(blk); putInt(totalBlks.toInt()); putInt(chunks); putInt(0)
        }.array()

    private fun chunkHdr(type: Int, blocks: Long, total: Long): ByteArray =
        ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(type.toShort()); putShort(0); putInt(blocks.toInt()); putInt(total.toInt())
        }.array()

    /**
     * Split into valid sparse images, each no larger than [limit] bytes.
     * Every piece describes the whole image (unused ranges are DONT_CARE chunks).
     */
    fun split(info: Info, ch: FileChannel, fileLen: Long, limit: Long): List<DataSource> {
        require(limit > (1 shl 20)) { "max-download-size is too small" }
        val blk = info.blkSz.toLong()
        val pieces = ArrayList<DataSource>()
        val overhead = 28L + 36L

        var segs = ArrayList<Segment>()
        var bytes = overhead
        var count = 0
        var firstBlk = 0L
        var endBlk = 0L

        fun reset() { segs = ArrayList(); bytes = overhead; count = 0; firstBlk = 0; endBlk = 0 }

        fun flush() {
            if (count == 0) return
            val lead = firstBlk
            val trail = info.totalBlks - endBlk
            var total = count
            if (lead > 0) total++
            if (trail > 0) total++
            val out = ArrayList<Segment>()
            out.add(BytesSeg(header(info.blkSz, info.totalBlks, total)))
            if (lead > 0) out.add(BytesSeg(chunkHdr(DONT, lead, 12)))
            out.addAll(segs)
            if (trail > 0) out.add(BytesSeg(chunkHdr(DONT, trail, 12)))
            pieces.add(SegSource(out))
            reset()
        }

        fun gapTo(startBlk: Long) {
            if (count == 0) { firstBlk = startBlk; endBlk = startBlk; return }
            if (startBlk > endBlk) {
                segs.add(BytesSeg(chunkHdr(DONT, startBlk - endBlk, 12)))
                bytes += 12; count++; endBlk = startBlk
            }
        }

        var pos = 0L
        for (c in info.chunks) {
            when (c.type) {
                DONT -> pos += c.blocks
                CRC -> {}
                FILL -> {
                    if (bytes + 16 + 12 > limit) flush()
                    gapTo(pos)
                    val hdr = chunkHdr(FILL, c.blocks, 16)
                    segs.add(BytesSeg(hdr + c.fill!!))
                    bytes += 16; count++
                    pos += c.blocks; endBlk = pos
                }
                RAW -> {
                    var done = 0L
                    while (done < c.blocks) {
                        val avail = limit - bytes - 24
                        val n = minOf(c.blocks - done, avail / blk)
                        if (n <= 0) { flush(); continue }
                        gapTo(pos + done)
                        segs.add(BytesSeg(chunkHdr(RAW, n, 12 + n * blk)))
                        segs.add(FileSeg(ch, c.dataOff + done * blk, n * blk, fileLen - 0L))
                        bytes += 12 + n * blk; count++
                        done += n
                        endBlk = pos + done
                    }
                    pos += c.blocks
                }
                else -> throw IOException("Unknown sparse chunk type 0x%x".format(c.type))
            }
        }
        flush()
        return pieces
    }
}

// ---------------------------------------------------------------------------
// Fastboot protocol over Android USB host
// ---------------------------------------------------------------------------

class Fastboot(
    private val conn: UsbDeviceConnection,
    private val epIn: UsbEndpoint,
    private val epOut: UsbEndpoint,
    private val log: (String) -> Unit
) {
    class Reply(val info: List<String>, val okay: String)

    private val chunk = 16384

    private fun send(data: ByteArray, off: Int, len: Int) {
        var sent = 0
        while (sent < len) {
            val n = minOf(chunk, len - sent)
            val r = conn.bulkTransfer(epOut, data, off + sent, n, 30000)
            if (r < 0) throw FastbootException("USB write failed (is the cable connected?)")
            sent += r
        }
    }

    private fun readReply(timeoutMs: Long): Pair<String, String> {
        val buf = ByteArray(512)
        val deadline = System.currentTimeMillis() + timeoutMs
        while (true) {
            val r = conn.bulkTransfer(epIn, buf, buf.size, 5000)
            if (r >= 4) {
                val s = String(buf, 0, r, Charsets.UTF_8)
                return s.substring(0, 4) to s.substring(4)
            }
            if (System.currentTimeMillis() > deadline) throw FastbootException("Timed out waiting for the device")
        }
    }

    fun command(cmd: String, timeoutMs: Long = 60000): Reply {
        val b = cmd.toByteArray(Charsets.UTF_8)
        if (b.size > 64) throw FastbootException("Command too long")
        send(b, 0, b.size)
        val info = ArrayList<String>()
        while (true) {
            val (t, m) = readReply(timeoutMs)
            when (t) {
                "INFO" -> { info.add(m); log(m) }
                "OKAY" -> return Reply(info, m)
                "FAIL" -> throw FastbootException(m)
                else -> throw FastbootException("Unexpected reply: $t$m")
            }
        }
    }

    fun getvar(name: String): String? = try {
        command("getvar:$name", 10000).okay.ifBlank { null }
    } catch (e: FastbootException) {
        null
    }

    fun download(src: DataSource, onProgress: (Long) -> Unit) {
        send("download:%08x".format(src.size).toByteArray(), 0, 17)
        while (true) {
            val (t, m) = readReply(30000)
            when (t) {
                "INFO" -> log(m)
                "DATA" -> {
                    if (m.trim().toLong(16) != src.size) throw FastbootException("Device rejected download size")
                    break
                }
                "FAIL" -> throw FastbootException(m)
                else -> throw FastbootException("Unexpected reply: $t$m")
            }
        }
        var sent = 0L
        src.writeTo { b, o, l -> send(b, o, l); sent += l; onProgress(sent) }
        while (true) {
            val (t, m) = readReply(120000)
            when (t) {
                "INFO" -> log(m)
                "OKAY" -> return
                "FAIL" -> throw FastbootException(m)
                else -> throw FastbootException("Unexpected reply: $t$m")
            }
        }
    }

    private fun maxDownload(): Long {
        val s = getvar("max-download-size") ?: return 256L shl 20
        val v = try {
            if (s.startsWith("0x", true)) s.substring(2).toLong(16) else s.trim().toLong()
        } catch (e: NumberFormatException) {
            256L shl 20
        }
        return minOf(v, 512L shl 20)
    }

    /** Flash an image file (raw or sparse), splitting it when larger than max-download-size. */
    fun flashImage(part: String, ch: FileChannel, report: (Long, Long) -> Unit) {
        val fileLen = ch.size()
        val maxDl = maxDownload()
        val pieces: List<DataSource> =
            if (fileLen <= maxDl) {
                listOf(SegSource(listOf(FileSeg(ch, 0, fileLen, fileLen))))
            } else {
                val info = if (Sparse.isSparse(ch)) Sparse.parse(ch) else Sparse.fromRaw(fileLen)
                Sparse.split(info, ch, fileLen, maxDl)
            }
        val totalAll = pieces.sumOf { it.size }
        var base = 0L
        pieces.forEachIndexed { i, p ->
            if (pieces.size > 1) log("  part ${i + 1}/${pieces.size}")
            download(p) { report(base + it, totalAll) }
            command("flash:$part", 600000)
            base += p.size
        }
    }

    fun close() = try { conn.close() } catch (_: Exception) {}
}

object Connector {
    const val ACTION = "com.mitoolapp.USB_PERMISSION"

    private fun isFastboot(d: UsbDevice, idx: Int): Boolean {
        val i = d.getInterface(idx)
        return i.interfaceClass == 0xFF && i.interfaceSubclass == 0x42 && i.interfaceProtocol == 0x03
    }

    fun find(m: UsbManager): UsbDevice? =
        m.deviceList.values.firstOrNull { d -> (0 until d.interfaceCount).any { isFastboot(d, it) } }

    fun open(m: UsbManager, d: UsbDevice, log: (String) -> Unit): Fastboot {
        val idx = (0 until d.interfaceCount).firstOrNull { isFastboot(d, it) }
            ?: throw FastbootException("Device has no fastboot interface")
        val iface = d.getInterface(idx)
        val conn = m.openDevice(d) ?: throw FastbootException("Could not open the USB device")
        if (!conn.claimInterface(iface, true)) {
            conn.close()
            throw FastbootException("Could not claim the fastboot interface")
        }
        var inEp: UsbEndpoint? = null
        var outEp: UsbEndpoint? = null
        for (e in 0 until iface.endpointCount) {
            val ep = iface.getEndpoint(e)
            if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
            if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
        }
        if (inEp == null || outEp == null) {
            conn.close()
            throw FastbootException("Fastboot endpoints not found")
        }
        return Fastboot(conn, inEp, outEp, log)
    }
}
