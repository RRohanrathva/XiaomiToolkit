package com.mitoolapp

import com.github.junrar.Junrar
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.progress.ProgressMonitor
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

/** Extracts zip (also password protected), 7z, rar (RAR4) and tgz / tar.gz archives. */
object Extractor {

    fun extract(
        src: File, name: String, dest: File, password: String,
        log: (String) -> Unit, progress: (Float) -> Unit
    ) {
        val n = name.lowercase()
        dest.mkdirs()
        when {
            n.endsWith(".zip") -> zip(src, dest, password, progress)
            n.endsWith(".7z") -> sevenZ(src, dest, password, log, progress)
            n.endsWith(".rar") -> rar(src, dest, password, progress)
            n.endsWith(".tgz") || n.endsWith(".tar.gz") || n.endsWith(".gz") -> tgz(src, dest, log, progress)
            else -> throw IOException("Unsupported archive type. Use zip, 7z, rar, tgz or tar.gz")
        }
    }

    private fun zip(src: File, dest: File, pw: String, progress: (Float) -> Unit) {
        val zf = if (pw.isEmpty()) ZipFile(src) else ZipFile(src, pw.toCharArray())
        if (!zf.isValidZipFile) throw IOException("Not a valid zip file")
        if (zf.isEncrypted && pw.isEmpty()) throw IOException("This zip is password protected. Enter the password first.")
        zf.isRunInThread = true
        val pm = zf.progressMonitor
        zf.extractAll(dest.absolutePath)
        while (pm.state != ProgressMonitor.State.READY) {
            progress(pm.percentDone / 100f)
            Thread.sleep(250)
        }
        if (pm.result == ProgressMonitor.Result.ERROR) {
            val e = pm.exception
            throw IOException(e?.message ?: "Extraction failed (wrong password?)")
        }
        progress(1f)
    }

    private fun sevenZ(src: File, dest: File, pw: String, log: (String) -> Unit, progress: (Float) -> Unit) {
        val sz = try {
            if (pw.isEmpty()) SevenZFile(src) else SevenZFile(src, pw.toCharArray())
        } catch (e: Exception) {
            throw IOException("Cannot open 7z (wrong password?): ${e.message}")
        }
        sz.use {
            val total = it.entries.sumOf { e -> if (e.hasStream()) e.size else 0L }.coerceAtLeast(1L)
            val root = dest.canonicalPath + File.separator
            val buf = ByteArray(1 shl 16)
            var done = 0L
            var count = 0
            while (true) {
                val e = it.nextEntry ?: break
                val target = File(dest, e.name)
                if (!target.canonicalPath.startsWith(root)) continue
                if (e.isDirectory) {
                    target.mkdirs()
                    continue
                }
                target.parentFile?.mkdirs()
                FileOutputStream(target).use { out ->
                    while (true) {
                        val r = it.read(buf)
                        if (r < 0) break
                        out.write(buf, 0, r)
                        done += r
                        progress((done.toFloat() / total).coerceAtMost(1f))
                    }
                }
                count++
                if (count % 5 == 0) log("Extracted $count files... (${e.name})")
            }
            log("Extracted $count files")
        }
        progress(1f)
    }

    private fun rar(src: File, dest: File, pw: String, progress: (Float) -> Unit) {
        progress(-1f)
        try {
            if (pw.isEmpty()) Junrar.extract(src, dest) else Junrar.extract(src, dest, pw)
        } catch (e: Exception) {
            throw IOException("RAR failed: ${e.message ?: "unknown error"} (wrong password, or RAR5 which is not supported)")
        }
        progress(1f)
    }

    private fun tgz(src: File, dest: File, log: (String) -> Unit, progress: (Float) -> Unit) {
        val total = src.length().coerceAtLeast(1L)
        FileInputStream(src).use { fis ->
            val counting = CountingInputStream(fis) { progress((it.toFloat() / total).coerceAtMost(1f)) }
            Rom.extractTarGz(counting, dest, log)
        }
        progress(1f)
    }
}

/** Reports how many bytes were read so far. */
class CountingInputStream(
    input: java.io.InputStream,
    private val onBytes: (Long) -> Unit
) : java.io.FilterInputStream(input) {
    private var count = 0L
    private var lastReport = 0L

    private fun add(n: Int) {
        if (n <= 0) return
        count += n
        if (count - lastReport >= (1L shl 20)) {
            lastReport = count
            onBytes(count)
        }
    }

    override fun read(): Int {
        val r = super.read()
        if (r >= 0) add(1)
        return r
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val r = super.read(b, off, len)
        add(r)
        return r
    }
}
