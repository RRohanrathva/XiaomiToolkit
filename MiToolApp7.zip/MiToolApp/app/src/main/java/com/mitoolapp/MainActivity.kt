package com.mitoolapp

import android.app.DownloadManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.CountDownLatch

class MainActivity : ComponentActivity() {

    private lateinit var usb: UsbManager
    @Volatile private var fb: Fastboot? = null
    @Volatile private var adb: Adb? = null
    private var romRoot: File? = null

    private val prefs by lazy { getSharedPreferences("mitool", Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var askedFor: String? = null
    @Volatile private var autoBlockUntil = 0L

    // ----- auto scan: runs all the time -----

    private val scanner = object : Runnable {
        override fun run() {
            try {
                val d = findTarget()
                if (d == null) {
                    askedFor = null
                    if (Ui.connected && !Ui.busy) markDisconnected()
                } else if (!Ui.connected && !Ui.busy && System.currentTimeMillis() > autoBlockUntil) {
                    if (usb.hasPermission(d)) startConnect()
                    else if (askedFor != d.deviceName) {
                        askedFor = d.deviceName
                        requestUsb(d)
                    }
                }
                pollDownloads()
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 1500)
        }
    }

    private fun findTarget(): UsbDevice? = Connector.find(usb) ?: Adb.find(usb)

    private fun pollDownloads() {
        val running = Downloads.list(this).filter {
            it.status == DownloadManager.STATUS_RUNNING || it.status == DownloadManager.STATUS_PENDING
        }
        Ui.downloading = running.isNotEmpty()
        val withTotal = running.filter { it.total > 0 }
        Ui.downloadPct =
            if (withTotal.isEmpty()) -1f
            else withTotal.sumOf { it.done }.toFloat() / withTotal.sumOf { it.total }
    }

    private fun markDisconnected() {
        fb?.close(); fb = null; Dev.fb = null
        adb?.close(); adb = null; Dev.adb = null
        Ui.connected = false
        Ui.transport = ""
        Ui.deviceName = "No device"
        Ui.product = ""
        Ui.mode = ""
        Ui.battery = ""
        Ui.info = emptyMap()
    }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Connector.ACTION ->
                    if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) startConnect()
                    else Ui.log("USB permission denied")
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    markDisconnected()
                    Ui.log("Device disconnected")
                }
            }
        }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) askFlashImage(uri, Ui.partition.trim())
    }
    private val pickRom = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) prepareRom(uri)
    }
    private val pickSideload = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) askSideload(uri)
    }
    private val pickArchive = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) extractArchive(uri)
    }
    private val pickTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) saveSelected(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        window.statusBarColor = CardBg.toArgb()
        window.navigationBarColor = CardBg.toArgb()
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        val f = IntentFilter().apply {
            addAction(Connector.ACTION)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(this, usbReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)

        loadPass()?.let { Ui.userId = it["userId"] }

        val actions = Actions(
            connect = ::connect,
            reboot = ::askReboot,
            login = ::miLogin,
            logout = ::miLogout,
            unlock = ::startUnlock,
            pickImage = { pickImage.launch(arrayOf("*/*")) },
            pickRom = { pickRom.launch(arrayOf("*/*")) },
            flashNow = ::askFlashNow,
            pickArchive = { pickArchive.launch(arrayOf("*/*")) },
            runTerm = ::runTerm,
            pickSideload = { pickSideload.launch(arrayOf("*/*")) },
            flashExtracted = ::askFlashExtracted,
            deleteExtracted = ::deleteExtracted,
            saveSelected = { pickTree.launch(null) }
        )
        setContent {
            MiToolTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Root(actions)
                }
            }
        }
        handler.post(scanner)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(scanner)
        unregisterReceiver(usbReceiver)
    }

    // ----- helpers -----

    private fun launchTask(section: String?, name: String, block: () -> Unit) {
        if (Ui.busy) { toast("Another task is running"); return }
        Ui.busy = true
        Ui.progress = -1f
        Ui.taskName = name
        Ui.activeSection = section
        Thread {
            try {
                block()
            } catch (e: Exception) {
                Ui.log("ERROR: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                Ui.busy = false
                Ui.progress = -1f
                Ui.taskName = ""
                Ui.activeSection = null
            }
        }.start()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun requireFb(): Fastboot = fb ?: throw FastbootException("No device connected")

    private fun askBlocking(title: String, text: String): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        Ui.confirm = Ui.Confirm(title, text, cancel = { latch.countDown() }) { ok = true; latch.countDown() }
        latch.await()
        return ok
    }

    private fun loadPass(): Map<String, String>? {
        val s = prefs.getString("passToken", null) ?: return null
        return try {
            val j = JSONObject(s)
            mapOf("deviceId" to j.getString("deviceId"), "passToken" to j.getString("passToken"), "userId" to j.getString("userId"))
        } catch (e: Exception) {
            null
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0).replace('/', '_')
        }
        return (uri.lastPathSegment ?: "file").replace('/', '_')
    }

    private fun querySize(uri: Uri): Long {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
        }
        return -1L
    }

    private fun formatBattery(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val n = raw.filter { it.isDigit() }.toLongOrNull() ?: return "Bat $raw"
        return when {
            raw.contains("%") -> "Bat $n%"
            n > 1000 -> "Bat %.2fV".format(n / 1000.0)
            else -> "Bat $n"
        }
    }

    // ----- connect -----

    private fun requestUsb(d: UsbDevice) {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(this, 0, Intent(Connector.ACTION).setPackage(packageName), flags)
        usb.requestPermission(d, pi)
    }

    private fun connect() {
        val d = findTarget()
        if (d == null) {
            toast("No device found. Connect the phone with an OTG cable (fastboot mode, or USB debugging on).")
            return
        }
        autoBlockUntil = 0L
        if (usb.hasPermission(d)) startConnect() else requestUsb(d)
    }

    private fun startConnect() = launchTask("device", "Connecting") {
        try {
            if (Connector.find(usb) != null) connectFastboot() else connectAdb()
        } catch (e: Exception) {
            autoBlockUntil = System.currentTimeMillis() + 10000   // do not retry in a loop
            throw e
        }
    }

    private fun connectFastboot() {
        val d = Connector.find(usb) ?: throw FastbootException("No fastboot device found")
        fb?.close(); adb?.close(); adb = null; Dev.adb = null
        val f = Connector.open(usb, d) { Ui.log("(device) $it") }
        fb = f
        Dev.fb = f
        val vars = linkedMapOf<String, String>()
        listOf(
            "unlocked" to "Unlocked", "current-slot" to "Slot",
            "max-download-size" to "Max download", "serialno" to "Serial", "version-bootloader" to "Bootloader"
        ).forEach { (k, label) -> f.getvar(k)?.let { vars[label] = it } }
        val product = f.getvar("product") ?: ""
        val userspace = f.getvar("is-userspace") == "yes"
        Ui.info = vars
        Ui.product = product
        Ui.deviceName = product.ifEmpty { "Fastboot device" }
        Ui.mode = if (userspace) "FastbootD" else "Fastboot"
        Ui.battery = formatBattery(f.getvar("battery-voltage"))
        Ui.transport = "fastboot"
        Ui.connected = true
        Ui.log("Connected to ${Ui.deviceName} (${Ui.mode})")
    }

    private fun connectAdb() {
        val d = Adb.find(usb) ?: throw AdbException("No device found")
        fb?.close(); fb = null; Dev.fb = null
        adb?.close()
        Ui.log("ADB: connecting (allow USB debugging on the phone if asked)...")
        val a = Adb.open(this, usb, d) { Ui.log(it) }
        adb = a
        Dev.adb = a
        val kind = a.banner.substringBefore("::").ifEmpty { "device" }
        fun prop(p: String): String = try {
            val sb = StringBuilder()
            a.shell("getprop $p", 6000) { sb.append(it) }
            sb.toString().trim()
        } catch (e: Exception) { "" }
        val vars = linkedMapOf<String, String>()
        var model = ""
        if (kind == "device") {
            model = prop("ro.product.model")
            prop("ro.product.device").takeIf { it.isNotEmpty() }?.let { vars["Codename"] = it }
            prop("ro.build.version.release").takeIf { it.isNotEmpty() }?.let { vars["Android"] = it }
            prop("ro.build.version.incremental").takeIf { it.isNotEmpty() }?.let { vars["Build"] = it }
            prop("ro.serialno").takeIf { it.isNotEmpty() }?.let { vars["Serial"] = it }
            try {
                val sb = StringBuilder()
                a.shell("dumpsys battery", 6000) { sb.append(it) }
                Regex("level:\\s*(\\d+)").find(sb)?.groupValues?.get(1)?.let { Ui.battery = "Bat $it%" }
            } catch (_: Exception) { }
        } else {
            Ui.battery = ""
        }
        Ui.info = vars
        Ui.product = model
        Ui.deviceName = model.ifEmpty { "Android device" }
        Ui.mode = when (kind) {
            "device" -> "ADB"
            "sideload" -> "ADB Sideload"
            "recovery" -> "ADB Recovery"
            else -> "ADB " + kind.replaceFirstChar { it.uppercase() }
        }
        Ui.transport = "adb"
        Ui.connected = true
        Ui.log("Connected to ${Ui.deviceName} (${Ui.mode})")
    }

    // ----- Mi account + unlock -----

    private fun miLogin() = launchTask("unlock", "Xiaomi login") {
        val http = MiHttp()
        val pt = MiAccount.loginBrowser(http, { url ->
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        }) { Ui.log(it) }
        prefs.edit().putString("passToken", JSONObject(pt).toString()).apply()
        Ui.userId = pt["userId"]
        Ui.log("Logged in. Account ID: ${pt["userId"]}")
        detectZone(pt)
    }

    private fun detectZone(pt: Map<String, String>) {
        val http = MiHttp()
        val region = MiAccount.region(http, pt)
        val zone = if (region != null) {
            Ui.log("Account region: $region")
            MiAccount.zoneForRegion(region)
        } else {
            MiAccount.zoneByUserId(http, pt["userId"]?.toLongOrNull() ?: 0L)
        }
        if (zone != null) {
            Ui.zone = zone
            Ui.log("Data center zone: $zone")
        } else {
            Ui.log("Could not detect the server region. Please select it.")
        }
    }

    private fun miLogout() {
        prefs.edit().remove("passToken").apply()
        Ui.userId = null
        Ui.zone = null
        Ui.log("Logged out")
    }

    private fun startUnlock() = launchTask("unlock", "Unlocking bootloader") {
        val f = requireFb()
        val pt = loadPass() ?: throw IOException("Please log in with your Xiaomi account first")
        if (Ui.zone == null) detectZone(pt)
        val zone = Ui.zone ?: throw IOException("Select the server region first")
        val domain = MiServer.DOMAINS[zone] ?: throw IOException("Unknown region")
        val service = try {
            MiAccount.getService(MiHttp(), pt)
        } catch (e: IOException) {
            if (e.message?.contains("expired") == true) miLogout()
            throw e
        }
        MiServer.unlock(f, domain, service, { Ui.log(it) }) { t, x -> askBlocking(t, x) }
    }

    // ----- flashing -----

    private fun askFlashImage(uri: Uri, part: String) {
        if (part.isBlank()) { toast("Enter a partition name first"); return }
        Ui.confirm = Ui.Confirm(
            "Flash to \"$part\"?",
            "The selected file will be written to the $part partition. A wrong image or partition can " +
                "make the phone unbootable."
        ) {
            launchTask("flash", "Flashing $part") {
                val f = requireFb()
                contentResolver.openFileDescriptor(uri, "r")!!.use { pfd ->
                    val ch = FileInputStream(pfd.fileDescriptor).channel
                    Ui.log("Flashing $part (${ch.size() / 1024 / 1024} MB)...")
                    f.flashImage(part, ch) { d, t -> Ui.progress = d.toFloat() / t }
                }
                Ui.log("Flashed $part")
            }
        }
    }

    private fun prepareRom(uri: Uri) = launchTask("flash", "Extracting ROM") {
        val name = displayName(uri)
        Ui.romName = name
        Ui.romOk = false
        Ui.romScripts = emptyList()
        Ui.romInfo = emptyMap()
        Ui.romState = "Extracting..."
        try {
            val size = querySize(uri)
            val base = getExternalFilesDir("rom") ?: File(cacheDir, "rom")
            base.deleteRecursively()
            Ui.log("Extracting ROM (this can take several minutes, needs free storage)...")
            contentResolver.openInputStream(uri)!!.use { ins ->
                val counting = CountingInputStream(ins) { n -> if (size > 0) Ui.progress = (n.toFloat() / size).coerceAtMost(1f) }
                Rom.extractTarGz(counting, base) { m -> Ui.log(m) }
            }
            val root = Rom.findRoot(base) ?: throw FastbootException("No images folder found in this ROM")
            val scripts = Rom.scripts(root)
            if (scripts.isEmpty()) throw FastbootException("No flash_all script found in this ROM")
            romRoot = root
            Ui.romScripts = scripts.map { it.name }
            Ui.romInfo = linkedMapOf(
                "Build" to (Regex("(OS\\d[\\w.]*|V\\d[\\w.]*)").find(name)?.value ?: "-"),
                "Android" to (Regex("_(\\d{1,2}\\.\\d)_").find(name)?.groupValues?.get(1) ?: "-"),
                "Scripts" to scripts.size.toString()
            )
            Ui.flashMode = listOf("clean", "save", "lock").firstOrNull { Ui.scriptFor(it) != null } ?: "clean"
            Ui.romState = "Ready"
            Ui.romOk = true
            Ui.log("ROM ready. Choose a flashing mode.")
        } catch (e: Exception) {
            Ui.romState = "Failed"
            throw e
        }
    }

    private fun askFlashNow() {
        val name = Ui.scriptFor(Ui.flashMode)
        if (name == null) { toast("This ROM has no script for the selected mode"); return }
        val lock = Ui.flashMode == "lock"
        val wipes = Ui.flashMode != "save"
        val extras = listOfNotNull(
            if (Ui.wipeMeta) "erase metadata" else null,
            if (Ui.wipeData) "erase userdata" else null
        )
        Ui.confirm = Ui.Confirm(
            "Flash now ($name)?",
            (if (lock) "This ERASES ALL DATA and RE-LOCKS the bootloader. Only do this with the official " +
                "stock ROM made for exactly this phone and a matching Xiaomi/MIUI/HyperOS version. " +
                "A wrong or older ROM with a locked bootloader can brick the phone. "
            else if (wipes) "This is a clean flash and ERASES ALL DATA. "
            else "This keeps your data where possible. ") +
                (if (extras.isNotEmpty()) "Extra: ${extras.joinToString(" + ")}. " else "") +
                "Do not disconnect the cable or close the app while flashing. The phone will reboot at the end."
        ) {
            val wipeMeta = Ui.wipeMeta
            val wipeData = Ui.wipeData
            launchTask("flash", "Flashing ROM") {
                val f = requireFb()
                val root = romRoot ?: throw FastbootException("ROM not prepared")
                var steps = Rom.parse(File(root, name))
                if (steps.isEmpty()) throw FastbootException("Could not read any fastboot steps from $name")
                val extra = ArrayList<Rom.Step>()
                if (wipeMeta) extra.add(Rom.Step.Erase("metadata"))
                if (wipeData) extra.add(Rom.Step.Erase("userdata"))
                if (extra.isNotEmpty()) {
                    val idx = steps.indexOfFirst { it is Rom.Step.Reboot }
                    steps = if (idx < 0) steps + extra else steps.take(idx) + extra + steps.drop(idx)
                }
                Ui.log("Running $name (${steps.size} steps)")
                Rom.run(f, root, steps, lock, { Ui.log(it) }) { Ui.progress = it }
                Ui.log("Flash script finished")
                (getExternalFilesDir("rom") ?: File(cacheDir, "rom")).deleteRecursively()
            }
        }
    }

    // ----- reboot (floating reboot manager) -----

    private fun askReboot(target: String) {
        val isAdb = Ui.transport == "adb"
        val cmd = when (target) {
            "system" -> "reboot"
            "edl" -> "oem edl"
            else -> "reboot-$target"
        }
        Ui.confirm = Ui.Confirm(
            "Reboot ${Ui.deviceName} ($target)?",
            if (target == "edl") "The phone will go to EDL mode (black screen). This only works on some Xiaomi Qualcomm phones. Hold the power button about 15 seconds to leave it."
            else "The phone will restart."
        ) {
            launchTask("device", "Rebooting") {
                if (isAdb) {
                    val a = adb ?: throw AdbException("No device connected")
                    val svc = if (target == "system") "reboot:" else "reboot:$target"
                    try { a.service(svc, { }, 8000) } catch (e: Exception) { Ui.log("(device) ${e.message}") }
                } else {
                    val f = requireFb()
                    try {
                        f.command(cmd, 10000)
                    } catch (e: Exception) {
                        // the phone often disconnects before it answers
                        Ui.log("(device) ${e.message}")
                    }
                }
                Ui.log("Reboot sent ($target)")
            }
        }
    }

    // ----- terminal: fastboot + adb commands -----

    private fun toFastbootCommand(t: List<String>): String? {
        val head = t[0]
        val rest = t.drop(1).joinToString(" ")
        return when (head) {
            "getvar", "erase", "set_active" -> if (rest.isBlank()) null else "$head:$rest"
            "oem", "flashing" -> if (rest.isBlank()) null else "$head $rest"
            "reboot" -> if (rest.isBlank()) "reboot" else "reboot-$rest"
            "reboot-bootloader", "reboot-recovery", "reboot-fastboot", "continue" -> head
            else -> null
        }
    }

    private val helpText = """
Commands (the "fastboot" / "adb" word is optional when a device is connected):
  fastboot getvar <name|all>      fastboot oem <x>       fastboot flashing <x>
  fastboot erase <partition>      fastboot set_active <a|b>
  fastboot reboot [bootloader|recovery|fastboot]   fastboot devices
  adb devices                     adb shell <command>    adb getprop [name]
  adb reboot [bootloader|recovery|sideload|fastboot]
  adb logcat -d                   adb root / unroot      adb sideload
  clear                           help
Flashing files: use "Flash Image" / "Stock ROM Flash". ROM zip: press the Sideload button.""".trimIndent()

    private fun runTerm(line: String) {
        val t = line.trim()
        if (t.isEmpty()) return
        Ui.termPrint("$ $t")
        when (t) {
            "clear", "cls" -> { Ui.term.clear(); return }
            "help", "?" -> { Ui.termPrint(helpText); return }
        }
        val toks = t.split(Regex("\\s+"))
        val args: List<String>
        val kind: String
        when (toks[0]) {
            "adb" -> { kind = "adb"; args = toks.drop(1) }
            "fastboot" -> { kind = "fastboot"; args = toks.drop(1) }
            else -> { kind = Ui.transport; args = toks }
        }
        if (kind.isEmpty()) { Ui.termPrint("No device connected. Start with \"adb\" or \"fastboot\" (type help)."); return }
        if (args.isEmpty()) { Ui.termPrint("Missing command (type help)"); return }
        if (kind == "adb") adbCommand(args) else fastbootCommand(args)
    }

    private fun fastbootCommand(toks: List<String>) {
        if (toks[0] == "devices") {
            Ui.termPrint(if (Ui.transport == "fastboot") "${Ui.info["Serial"] ?: Ui.deviceName}\tfastboot" else "(no fastboot device)")
            return
        }
        if (Ui.transport != "fastboot") { Ui.termPrint("No fastboot device connected."); return }
        val cmd = toFastbootCommand(toks)
        if (cmd == null) {
            Ui.termPrint("Unsupported command. Use \"Flash Image\" or \"Stock ROM Flash\" to flash files (type help).")
            return
        }
        val rest = toks.drop(1).joinToString(" ")
        val risky = toks[0] == "erase" ||
            (toks[0] in listOf("oem", "flashing") && rest.contains("lock", true) && !rest.contains("unlock", true)) ||
            rest.contains("unlock", true) || rest.contains("edl", true)
        val go = {
            launchTask("terminal", "Fastboot command") {
                val f = requireFb()
                try {
                    val r = f.command(cmd, 120000)
                    r.info.forEach { Ui.termPrint(it) }
                    if (r.okay.isNotBlank()) Ui.termPrint(r.okay)
                    Ui.termPrint("OKAY")
                } catch (e: FastbootException) {
                    Ui.termPrint("FAIL: ${e.message}")
                }
            }
        }
        if (risky) {
            Ui.confirm = Ui.Confirm(
                "Run this command?",
                "fastboot ${toks.joinToString(" ")}\n\nThis can erase data, change the bootloader state or make the phone unbootable."
            ) { go() }
        } else go()
    }

    private fun adbCommand(toks: List<String>) {
        val head = toks[0]
        val rest = toks.drop(1)
        when (head) {
            "devices" -> {
                Ui.termPrint("List of devices attached")
                if (Ui.transport == "adb") Ui.termPrint("${Ui.info["Serial"] ?: Ui.deviceName}\t${Ui.mode}")
                return
            }
            "version" -> { Ui.termPrint("MiTool built-in ADB client (USB, protocol 0x01000001)"); return }
            "start-server", "kill-server" -> { Ui.termPrint("Not needed: MiTool talks to the phone directly."); return }
            "sideload" -> {
                if (Ui.transport != "adb") Ui.termPrint("No ADB device. On the phone open Recovery > Apply update from ADB.")
                else pickSideload.launch(arrayOf("*/*"))
                return
            }
        }
        if (Ui.transport != "adb") { Ui.termPrint("No ADB device connected. Enable USB debugging and allow this computer."); return }
        val service = when (head) {
            "shell" -> if (rest.isEmpty()) { Ui.termPrint("Interactive shell is not supported. Use: adb shell <command>"); return } else "shell:${rest.joinToString(" ")}"
            "getprop" -> "shell:getprop ${rest.joinToString(" ")}".trim()
            "logcat" -> "shell:logcat ${rest.joinToString(" ")}".trim()
            "root" -> "root:"
            "unroot" -> "unroot:"
            "get-state" -> { Ui.termPrint(Ui.mode); return }
            "get-serialno" -> { Ui.termPrint(Ui.info["Serial"] ?: "unknown"); return }
            "reboot" -> "reboot:${rest.firstOrNull() ?: ""}"
            else -> { Ui.termPrint("Unsupported adb command. Type help."); return }
        }
        if (head == "logcat" && !rest.contains("-d")) {
            Ui.termPrint("Use: adb logcat -d (dump and exit)")
            return
        }
        val risky = head == "reboot" || (head == "shell" && Regex("\\b(rm|dd|wipe|format|mkfs)\\b").containsMatchIn(rest.joinToString(" ")))
        val go = {
            launchTask("terminal", "ADB command") {
                val a = adb ?: throw AdbException("No device connected")
                val sb = StringBuilder()
                try {
                    a.service(service, { b ->
                        val txt = String(b)
                        sb.append(txt)
                    }, 120000)
                } catch (e: Exception) {
                    Ui.termPrint("error: ${e.message}")
                }
                val out = sb.toString().replace("\r\n", "\n").trimEnd()
                if (out.isNotEmpty()) Ui.termPrint(out)
                else if (head != "shell" && head != "getprop" && head != "logcat") Ui.termPrint("done")
            }
        }
        if (risky) {
            Ui.confirm = Ui.Confirm("Run this command?", "adb ${toks.joinToString(" ")}\n\nThis can restart the phone or delete data.") { go() }
        } else go()
    }

    // ----- ROM sideload (adb sideload) -----

    private fun askSideload(uri: Uri) {
        val name = displayName(uri)
        Ui.sideloadName = name
        if (Ui.transport != "adb") { toast("Connect the phone over ADB first"); return }
        val inSideload = Ui.mode == "ADB Sideload"
        Ui.confirm = Ui.Confirm(
            "Sideload $name?",
            (if (inSideload) "" else "The phone is not in sideload mode. In recovery choose \"Apply update from ADB\" first, or press \"Reboot to sideload\". ") +
                "The package is sent to the phone and installed by its recovery. Do not disconnect the cable. Wrong or unsigned packages are rejected or can leave the phone unbootable."
        ) {
            launchTask("terminal", "Sideloading $name") {
                val a = adb ?: throw AdbException("No device connected")
                Ui.termPrint("$ adb sideload $name")
                contentResolver.openFileDescriptor(uri, "r")!!.use { pfd ->
                    val ch = FileInputStream(pfd.fileDescriptor).channel
                    Ui.termPrint("Sending ${ch.size() / 1024 / 1024} MB ...")
                    try {
                        a.sideload(ch) { d, t -> Ui.progress = d.toFloat() / t }
                        Ui.termPrint("Sideload finished. Check the phone screen for the result.")
                    } catch (e: Exception) {
                        Ui.termPrint("Sideload failed: ${e.message}")
                        throw e
                    }
                }
            }
        }
    }

    // ----- extract archives -----

    private fun extractArchive(uri: Uri) = launchTask("extract", "Extracting archive") {
        val name = displayName(uri)
        val base = File(getExternalFilesDir(null) ?: cacheDir, "extracted")
        val src = File(cacheDir, "archive_src_$name")
        Ui.extractFiles = emptyList()
        Ui.selected = emptySet()
        Ui.extractRoot = base
        Ui.extractState = "Extracting $name..."
        try {
            base.deleteRecursively()
            base.mkdirs()
            // copy to cache so zip / 7z / rar can seek in it
            val size = querySize(uri)
            contentResolver.openInputStream(uri)!!.use { ins ->
                FileOutputStream(src).use { out ->
                    val buf = ByteArray(1 shl 16)
                    var done = 0L
                    while (true) {
                        val r = ins.read(buf)
                        if (r < 0) break
                        out.write(buf, 0, r)
                        done += r
                        if (size > 0) Ui.progress = (done.toFloat() / size).coerceAtMost(1f)
                    }
                }
            }
            Ui.progress = -1f
            Extractor.extract(src, name, base, Ui.archivePassword, { Ui.log(it) }) { Ui.progress = it }
            Ui.extractFiles = base.walkTopDown().filter { it.isFile }.sortedBy { it.path }.toList()
            Ui.extractState = "Done: ${Ui.extractFiles.size} files from $name"
            Ui.log(Ui.extractState)
        } catch (e: Exception) {
            Ui.extractState = "Failed: ${e.message ?: "unsupported archive"}"
            throw e
        } finally {
            src.delete()
        }
    }

    private fun saveSelected(tree: Uri) = launchTask("extract", "Saving files") {
        val dir = DocumentFile.fromTreeUri(this, tree) ?: throw IOException("Cannot open the chosen folder")
        val files = Ui.extractFiles.filter { it.absolutePath in Ui.selected }
        if (files.isEmpty()) throw IOException("No files selected")
        val total = files.sumOf { it.length() }.coerceAtLeast(1L)
        var done = 0L
        val buf = ByteArray(1 shl 16)
        for (f in files) {
            dir.findFile(f.name)?.delete()
            val target = dir.createFile("application/octet-stream", f.name)
                ?: throw IOException("Cannot create ${f.name} in the chosen folder")
            contentResolver.openOutputStream(target.uri)!!.use { out ->
                f.inputStream().use { ins ->
                    while (true) {
                        val r = ins.read(buf)
                        if (r < 0) break
                        out.write(buf, 0, r)
                        done += r
                        Ui.progress = (done.toFloat() / total).coerceAtMost(1f)
                    }
                }
            }
            Ui.log("Saved ${f.name}")
        }
        Ui.log("Saved ${files.size} files")
    }

    private fun askFlashExtracted(file: File) {
        val part = file.name.removeSuffix(".img").removeSuffix(".IMG").substringBefore('.')
        Ui.confirm = Ui.Confirm(
            "Flash ${file.name}?",
            "This writes the image to the \"$part\" partition. A wrong image or partition can make the phone unbootable."
        ) {
            launchTask("flash", "Flashing $part") {
                val f = requireFb()
                Ui.log("Flashing $part from ${file.name}...")
                RandomAccessFile(file, "r").use { raf ->
                    f.flashImage(part, raf.channel) { d, t -> Ui.progress = d.toFloat() / t }
                }
                Ui.log("Flashed $part")
            }
        }
    }

    private fun deleteExtracted() {
        File(getExternalFilesDir(null) ?: cacheDir, "extracted").deleteRecursively()
        Ui.extractFiles = emptyList()
        Ui.selected = emptySet()
        Ui.extractState = "Nothing selected"
        Ui.log("Extracted files deleted")
    }
}
