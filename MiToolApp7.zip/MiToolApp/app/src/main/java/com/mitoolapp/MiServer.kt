package com.mitoolapp

import android.util.Base64
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.TreeMap
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/*
 * Kotlin port of the Xiaomi account login + unlock server protocol used by
 *   - MiForge/MiUnlockTool (miunlock, Apache-2.0)
 *   - MiForge/migate (MIT)
 */

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
private fun sha1(b: ByteArray) = MessageDigest.getInstance("SHA-1").digest(b)
private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

// ---------------------------------------------------------------------------
// HTTP with a simple cookie jar (Xiaomi hosts only)
// ---------------------------------------------------------------------------

class MiHttp {
    val jar = LinkedHashMap<String, String>()

    /** Cookies set by the most recent request (like requests' response.cookies). */
    val lastSet = LinkedHashMap<String, String>()

    class Resp(val code: Int, val body: String)

    private fun qs(p: Map<String, String>) = p.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }

    private fun store(setCookie: String) {
        val nv = setCookie.substringBefore(';')
        val name = nv.substringBefore('=').trim()
        val value = nv.substringAfter('=', "").trim()
        if (name.isEmpty()) return
        val expired = value.isEmpty() || value.equals("EXPIRED", true) ||
            setCookie.contains("Max-Age=0", true)
        if (expired) jar.remove(name) else { jar[name] = value; lastSet[name] = value }
    }

    fun get(url: String, params: Map<String, String>? = null, follow: Boolean = true, timeoutMs: Int = 30000) =
        request("GET", url, params, null, follow, timeoutMs)

    fun post(url: String, form: Map<String, String>? = null, timeoutMs: Int = 30000) =
        request("POST", url, null, form, true, timeoutMs)

    private fun request(
        method: String, url0: String, params: Map<String, String>?, form: Map<String, String>?,
        follow: Boolean, timeoutMs: Int
    ): Resp {
        lastSet.clear()
        var url = if (params.isNullOrEmpty()) url0 else url0 + (if ('?' in url0) "&" else "?") + qs(params)
        var m = method
        var body: Map<String, String>? = form
        for (hop in 0 until 10) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.requestMethod = m
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("User-Agent", "offici5l/migate")
            c.setRequestProperty("Accept", "application/json;charset=UTF-8")
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            if (jar.isNotEmpty()) c.setRequestProperty("Cookie", jar.entries.joinToString("; ") { "${it.key}=${it.value}" })
            if (m == "POST") {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                c.outputStream.use { it.write(body?.let { b -> qs(b).toByteArray() } ?: ByteArray(0)) }
            }
            val code = c.responseCode
            c.headerFields.entries.firstOrNull { it.key.equals("Set-Cookie", true) }?.value?.forEach { store(it) }
            val text = (if (code >= 400) c.errorStream else c.inputStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (follow && (code in 301..303 || code == 307 || code == 308)) {
                val loc = c.getHeaderField("Location")
                if (loc != null) {
                    url = URL(URL(url), loc).toString()
                    m = "GET"; body = null
                    continue
                }
            }
            if (code == 403) throw IOException("Access denied")
            if (code >= 400) throw IOException("HTTP error: $code")
            return Resp(code, text)
        }
        throw IOException("Too many redirects")
    }
}

// ---------------------------------------------------------------------------
// Xiaomi account (migate)
// ---------------------------------------------------------------------------

class Service(val cookies: Map<String, String>, val ssecurity: String, val deviceId: String)

object MiAccount {
    private const val SERVICELOGIN = "https://account.xiaomi.com/pass/serviceLogin"
    private const val LONGPOLLING = "https://account.xiaomi.com/longPolling/loginUrl"
    private const val REGION_URL = "https://account.xiaomi.com/pass/user/login/region"
    private const val CONFIGURATION_URL = "https://api.account.xiaomi.com/pass/configuration"

    private val EUROPE = setOf(
        "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "EL", "HU", "IS", "IE", "IT",
        "LV", "LI", "LT", "LU", "MT", "NL", "NO", "PL", "PT", "RO", "SK", "SI", "ES", "SE", "UK"
    )

    private fun strip(body: String) = body.removePrefix("&&&START&&&")

    private fun baseParams() = linkedMapOf("sid" to "unlockApi", "checkSafeAddress" to "True", "_json" to "True")

    /**
     * Browser login: opens Xiaomi's own login page (captcha / 2FA handled by Xiaomi) and waits.
     * Returns the passToken cookies {deviceId, passToken, userId}.
     */
    fun loginBrowser(http: MiHttp, openUrl: (String) -> Unit, log: (String) -> Unit): Map<String, String> {
        http.jar.clear()
        val first = JSONObject(strip(http.get(SERVICELOGIN, baseParams()).body))
        val auth = baseParams()
        auth["serviceParam"] = first.getString("serviceParam")
        auth["qs"] = first.getString("qs")
        auth["callback"] = first.getString("callback")
        auth["_sign"] = first.getString("_sign")
        auth["_json"] = "False"

        while (true) {
            val lpInfo = JSONObject(strip(http.get(LONGPOLLING, auth).body))
            val timeout = lpInfo.optInt("timeout", 300)
            val url = lpInfo.getString("loginUrl")
            val lp = lpInfo.getString("lp")
            log("Opening Xiaomi login page. Log in there, then come back to this app.")
            openUrl(url)
            try {
                http.get(lp, timeoutMs = timeout * 1000 + 5000)
                break
            } catch (e: SocketTimeoutException) {
                log("Login timed out, retrying...")
            }
        }
        val need = listOf("deviceId", "passToken", "userId")
        val missing = need.filter { http.jar[it].isNullOrEmpty() }
        if (missing.isNotEmpty()) throw IOException("Login incomplete (missing ${missing.joinToString()})")
        return need.associateWith { http.jar[it]!! }
    }

    fun getService(http: MiHttp, pt: Map<String, String>): Service {
        http.jar.clear(); http.jar.putAll(pt)
        val j = JSONObject(strip(http.get(SERVICELOGIN, baseParams()).body))
        val nonce = j.optString("nonce")
        val ssecurity = j.optString("ssecurity")
        val location = j.optString("location")
        if (nonce.isEmpty() || ssecurity.isEmpty() || location.isEmpty())
            throw IOException("Login expired. Please log in again.")
        val clientSign = enc(b64(sha1("nonce=$nonce&$ssecurity".toByteArray())))
        http.get("$location&clientSign=$clientSign")
        return Service(http.lastSet.toMap(), ssecurity, pt["deviceId"] ?: "")
    }

    fun region(http: MiHttp, pt: Map<String, String>): String? = try {
        http.jar.clear(); http.jar.putAll(pt)
        val j = JSONObject(strip(http.get(REGION_URL).body))
        j.optJSONObject("data")?.optString("region")?.takeIf { it.isNotBlank() }
    } catch (e: Exception) {
        null
    }

    fun zoneForRegion(region: String): String = when {
        region == "CN" -> "China"
        region == "IN" -> "India"
        region == "RU" -> "Russia"
        region in EUROPE -> "Europe"
        else -> "Singapore"
    }

    fun zoneByUserId(http: MiHttp, userId: Long): String? = try {
        http.jar.clear()
        val idc = JSONObject(http.get(CONFIGURATION_URL, mapOf("keys" to "idc")).body)
            .getJSONObject("data").getJSONObject("idc")
        var found: String? = null
        for (name in idc.keys()) {
            val info = idc.getJSONObject(name)
            val ranges = ArrayList<Pair<Long, Long>>()
            ranges.add(info.getLong("userId.min") to info.getLong("userId.max"))
            info.optJSONArray("extend.idRange")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    ranges.add(e.getLong("userId.min") to e.getLong("userId.max"))
                }
            }
            if (ranges.any { userId >= it.first && userId <= it.second }) { found = name; break }
        }
        found
    } catch (e: Exception) {
        null
    }
}

// ---------------------------------------------------------------------------
// Unlock server (miunlock)
// ---------------------------------------------------------------------------

object MiServer {
    val DOMAINS = linkedMapOf(
        "Singapore" to "https://unlock.update.intl.miui.com",
        "China" to "https://unlock.update.miui.com",
        "India" to "https://in-unlock.update.intl.miui.com",
        "Russia" to "https://ru-unlock.update.intl.miui.com",
        "Europe" to "https://eu-unlock.update.intl.miui.com"
    )

    private val IV = "0102030405060708".toByteArray()
    private val KEY = "2tBeoEyJTunmWUGq7bQH2Abn0k2NhhurOaqBfyxCuLVgn4AVj7swcawe53uDUno".toByteArray()

    private fun aes(mode: Int, key: ByteArray, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(mode, SecretKeySpec(key, "AES"), IvParameterSpec(IV))
        return c.doFinal(data)
    }

    private fun err(msg: String) = JSONObject().put("error", msg)

    private fun send(
        path: String, params: Map<String, String>, data: JSONObject?,
        domain: String, ssecurity: String, cookies: Map<String, String>
    ): JSONObject {
        val key = Base64.decode(ssecurity, Base64.DEFAULT)
        val p = TreeMap<String, String>(params)
        p["sid"] = "miui_unlocktool_client"
        if (data != null) p["data"] = b64(data.toString().toByteArray())
        val order = p.keys.toList()

        val signStr = "POST\n$path\n" + order.joinToString("&") { "$it=${p[it]}" }
        val mac = Mac.getInstance("HmacSHA1").apply { init(SecretKeySpec(KEY, "HmacSHA1")) }
        val signHex = hex(mac.doFinal(signStr.toByteArray())).toByteArray()
        val currentSign = b64(aes(Cipher.ENCRYPT_MODE, key, signHex))

        val encrypted = LinkedHashMap<String, String>()
        for (k in order) encrypted[k] = b64(aes(Cipher.ENCRYPT_MODE, key, p[k]!!.toByteArray()))

        val encoded = order.map { "$it=${encrypted[it]}" } + "sign=$currentSign" + ssecurity
        val signature = b64(sha1("POST&$path&${encoded.joinToString("&")}".toByteArray()))

        val query = LinkedHashMap(encrypted)
        query["sign"] = currentSign
        query["signature"] = signature
        val url = "$domain$path?" + query.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }

        val text: String = try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 30000; c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "XiaomiPCSuite")
            c.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
            c.doOutput = true
            c.outputStream.use { }
            if (c.responseCode >= 400) return err("network request failed (HTTP ${c.responseCode})")
            c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: IOException) {
            return err("network request failed")
        }

        if (text.isEmpty()) return err("empty response")
        return try {
            val dec = aes(Cipher.DECRYPT_MODE, key, Base64.decode(text.trim(), Base64.DEFAULT))
            val inner = Base64.decode(String(dec), Base64.DEFAULT)
            val j = JSONObject(String(inner))
            if (j.has("code")) j else err(j.toString())
        } catch (e: Exception) {
            err("could not read the server response")
        }
    }

    private fun check(j: JSONObject): JSONObject {
        if (j.has("error")) throw IOException(j.getString("error"))
        if (j.optInt("code", -1) != 0) {
            val d = j.optString("descEN")
            throw IOException(if (d.isNotEmpty()) "code ${j.optInt("code")}: $d" else j.toString())
        }
        return j
    }

    private fun rnd() = (1..16).map { ('a'..'z').random() }.joinToString("")

    private fun nonce(domain: String, s: Service) =
        check(send("/api/v2/nonce", mapOf("r" to rnd()), null, domain, s.ssecurity, s.cookies)).getString("nonce")

    private fun deviceToken(fb: Fastboot): String {
        val fromOem = try {
            fb.command("oem get_token").info.filter { "token:" in it }.joinToString("") { it.substringAfter("token:").trim() }
        } catch (e: FastbootException) {
            ""
        }
        if (fromOem.isNotEmpty()) return fromOem
        return fb.getvar("token") ?: throw IOException("Could not read the device token")
    }

    private fun fromHex(s: String): ByteArray =
        ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    /**
     * Full official unlock flow. [confirm] is called with a title and text and must return true to continue.
     */
    fun unlock(
        fb: Fastboot, domain: String, s: Service, log: (String) -> Unit,
        confirm: (String, String) -> Boolean
    ) {
        log("Getting nonce from Xiaomi...")
        val n1 = nonce(domain, s)

        val product = fb.getvar("product") ?: throw IOException("Could not read the device codename")
        log("Device codename: $product")

        val clear = check(
            send(
                "/api/v2/unlock/device/clear",
                mapOf("appId" to "1", "nonce" to n1), JSONObject().put("product", product),
                domain, s.ssecurity, s.cookies
            )
        )
        val notice = clear.optString("notice")
        val wipes = clear.optInt("cleanOrNot") == 1
        if (notice.isNotEmpty()) log("notice: $notice")
        log(if (wipes) "The device will clear user data when unlocked" else "Unlocking will not erase user data")

        val ok = confirm(
            "Unlock now?",
            (if (notice.isNotEmpty()) "$notice\n\n" else "") +
                (if (wipes) "ALL DATA on the phone will be erased." else "User data will not be erased.") +
                "\n\nDevice: $product"
        )
        if (!ok) { log("Cancelled"); return }

        log("Reading device token...")
        val token = deviceToken(fb)

        val info = JSONObject().put("boardVersion", "").put("deviceName", "").put("product", product).put("socId", "")
        val data = JSONObject()
            .put("clientId", "2")
            .put("clientVersion", "7.6.727.43")
            .put("deviceInfo", info)
            .put("deviceToken", token)
            .put("language", "en")
            .put("operate", "unlock")
            .put("pcId", hex(MessageDigest.getInstance("MD5").digest(s.deviceId.toByteArray())))
            .put("region", "")
            .put("uid", s.cookies["userId"] ?: "")

        // nonce is single use, so request a fresh one
        val n2 = nonce(domain, s)
        log("Requesting unlock data from Xiaomi...")
        val res = check(
            send("/api/v3/ahaUnlock", mapOf("appId" to "1", "nonce" to n2), data, domain, s.ssecurity, s.cookies)
        )
        val encryptData = fromHex(res.getString("encryptData"))

        log("Sending unlock data to the phone...")
        fb.download(SegSource(listOf(BytesSeg(encryptData)))) { }
        fb.command("oem unlock", 120000)
        log("Unlock successful")
    }
}
