# MiToolApp (standalone)

Material 3 Android app, no Termux needed. Fastboot runs over USB OTG inside the app.

## Features

- **Fixed header** — the MiTool title (small + orange) and the round, always-scanning device
  badge stay pinned at the top on every screen and never scroll. When a fastboot device is
  connected the badge turns green and pulses/glows; the device name, battery % and connection
  mode are shown on its left.
- **Floating Reboot Manager** — a floating button at the top-right of every screen opens
  Reboot System / Bootloader / Recovery / Fastboot(D) / EDL for the USB-connected device.
- **Flash** — stock ROM flash (fastboot `flash_all` script, .tgz), single `.img` flash, and the
  fastboot command console are all in the same section.
- **ROMs** — "Stock ROM Xiaomi" (firmware finder, renamed) and Official AOSP ROMs in one
  section, with a Download Manager link. Downloads are also available as their own section.
- **Extract** — ZIP (including **encrypted ZIP**), RAR, 7z, TGZ / TAR.GZ and plain TAR.
  Tick `.img` files (or all files) and **Save selected** copies them to
  `Downloads/MiTool/Extracted`. An optional password field is provided for encrypted archives.
- **Glow + progress** — the section that is working pulses on/off like a bulb, and a glowing
  percentage bar reports flash / extract / download / reboot progress.
- Bootloader Unlock: Xiaomi account login (browser) + official unlock server flow
  (port of MiForge/MiUnlockTool, Apache-2.0 and MiForge/migate, MIT)

Build: GitHub -> Actions -> "Build APK" -> Run workflow -> artifact `MiTool-apk`.
