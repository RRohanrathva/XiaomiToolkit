package com.mitoolapp

import android.app.Activity
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

/**
 * Minimal in-app browser. Any file download started on a page is handed to Android's
 * DownloadManager (saved in Downloads/MiTool, visible in the Download Manager screen).
 */
class BrowserActivity : Activity() {

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val close = Button(this).apply {
            text = "Close"
            isAllCaps = false
            setOnClickListener { finish() }
        }
        val dl = Button(this).apply {
            text = "Download Manager"
            isAllCaps = false
            setOnClickListener { Ui.screen = "downloads"; finish() }
        }
        bar.addView(close)
        bar.addView(dl)
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.setDownloadListener { url, userAgent, contentDisposition, mime, _ ->
            val cookie = CookieManager.getInstance().getCookie(url)
            val err = Downloads.enqueue(this, url, userAgent, contentDisposition, mime, cookie)
            if (err == null) {
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
                Ui.screen = "downloads"   // MiTool shows the Download Manager when we return
                finish()
            } else {
                Toast.makeText(this, err, Toast.LENGTH_LONG).show()
            }
        }
        web.loadUrl(intent.getStringExtra("url") ?: "about:blank")
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        web.destroy()
    }
}
