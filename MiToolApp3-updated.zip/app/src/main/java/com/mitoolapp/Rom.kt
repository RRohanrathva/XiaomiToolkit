package com.mitoolapp

import com.github.junrar.Archive
import net.lingala.zip4j.io.inputstream.ZipInputStream
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.io.BufferedInputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.util.zip.GZIPInputStream

object Rom {

    // ----- generic helpers -----

    /** Counts compressed bytes read so a percentage can be reported. */
    private class CountingInputStream(
        src: InputStream,
        private val total: Long,
        private val onProgress: (Float) -> Unit
    ) : FilterInputStream(src) {
        private var count = 0L
        private var last = 0L

        override fun read(): Int {
            val r = super.read()
            if (r >= 0) tick(1)
            return r
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = super.read(b, off, len)
            if (r > 0) tick(r.toLong())
            return r
        }

        private fun tick(n: Long) {
            count += n
            if (total > 0 && count - last > (1 shl 18)) {
                last = count
                onProgress((count.toFloat() / total).coerceIn(0f, 1f))
            }
        }
    }

    /** Blocks path-traversal entries such as ../.. */
    private fun safeTarget(dest: File, rawName: String): File {
        val name = rawName.replace('\\', '/').trimStart('/')
        val f = File(dest, name)
        val root = dest.canonicalPath + File.separator
        if (!f.canonicalPath.startsWith(root)) throw IOException("Unsafe archive path: $rawName")
        return f
    }

    // ----- tar / tar.gz extraction (own minimal reader, no external libs) -----

    private fun readFully(i: InputStream, b: ByteArray, len: Int): Boolean {
        var n = 0
        while (n < len) {
            val r = i.read(b, n, len - n)
            if (r < 0) return if (n == 0) false else throw EOFException("Truncated archive")
            n += r
        }
        return true
    }

    private fun skipFully(i: InputStream, count: Long) {
        var left = count
        val tmp = ByteArray(65536)
        while (left > 0) {
            val r = i.read(tmp, 0, minOf(tmp.size.toLong(), left).toInt())
            if (r < 0) throw EOFException("Truncated archive")
            left -= r
        }
    }

    private fun str(h: ByteArray, off: Int, len: Int): String {
        var e = off
        while (e < off + len && h[e] != 0.toByte()) e++
        return String(h, off, e - off, Charsets.UTF_8)
    }

    private fun num(h: ByteArray, off: Int, len: Int): Long {
        if (h[off].toInt() and 0x80 != 0) { // base-256 for very large files
            var v = 0L
            for (k in 1 until len) v = (v shl 8) or (h[off + k].toLong() and 0xFF)
            return v
        }
        val s = str(h, off, len).trim()
        return if (s.isEmpty()) 0 else s.toLong(8)
    }

    private fun readTar(tar: InputStream, dest: File, log: (String) -> Unit) {
        val root = dest.canonicalPath + File.separator
        val h = ByteArray(512)
        var longName: String? = null
        val buf = ByteArray(1 shl 16)
        var files = 0

        while (readFully(tar, h, 512)) {
            if (h.all { it == 0.toByte() }) break
            val size = num(h, 124, 12)
            val type = h[156].toInt().toChar()
            val padded = (size + 511) / 512 * 512

            when (type) {
                'L' -> {
                    val b = ByteArray(size.toInt())
                    readFully(tar, b, b.size)
                    longName = String(b, Charsets.UTF_8).trimEnd('\u0000')
                    skipFully(tar, padded - size)
                    continue
                }
                'x', 'g' -> {
                    val b = ByteArray(size.toInt())
                    readFully(tar, b, b.size)
                    skipFully(tar, padded - size)
                    if (type == 'x') {
                        String(b, Charsets.UTF_8).lineSequence().forEach { line ->
                            val p = line.indexOf("path=")
                            if (p >= 0) longName = line.substring(p + 5).trim()
                        }
                    }
                    continue
                }
            }

            var name = longName ?: run {
                val n = str(h, 0, 100)
                val prefix = if (str(h, 257, 5) == "ustar") str(h, 345, 155) else ""
                if (prefix.isNotEmpty()) "$prefix/$n" else n
            }
            longName = null
            name = name.trimStart('/')

            val target = File(dest, name)
            if (!target.canonicalPath.startsWith(root) && target.canonicalPath + File.separator != root) {
                skipFully(tar, padded)
                continue
            }

            if (type == '5') {
                target.mkdirs()
            } else if (type == '0' || type == '\u0000') {
                target.parentFile?.mkdirs()
                FileOutputStream(target).use { out ->
                    var left = size
                    while (left > 0) {
                        val r = tar.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (r < 0) throw EOFException("Truncated archive")
                        out.write(buf, 0, r)
                        left -= r
                    }
                }
                skipFully(tar, padded - size)
                files++
                if (files % 5 == 0) log("Extracted $files files... ($name)")
            } else {
                skipFully(tar, padded)
            }
        }
        log("Extracted $files files")
    }

    fun extractTarGz(
        input: InputStream,
        dest: File,
        log: (String) -> Unit,
        progress: (Float) -> Unit = {},
        total: Long = -1L
    ) {
        dest.mkdirs()
        val counted = if (total > 0) CountingInputStream(input, total, progress) else input
        GZIPInputStream(BufferedInputStream(counted, 1 shl 16), 1 shl 16).use { gz ->
            readTar(gz, dest, log)
        }
        progress(1f)
    }

    fun extractTar(
        input: InputStream,
        dest: File,
        log: (String) -> Unit,
        progress: (Float) -> Unit = {},
        total: Long = -1L
    ) {
        dest.mkdirs()
        val counted = if (total > 0) CountingInputStream(input, total, progress) else input
        readTar(BufferedInputStream(counted, 1 shl 16), dest, log)
        progress(1f)
    }

    // ----- ZIP (standard and encrypted, via zip4j) -----

    private fun extractZipSmart(
        input: InputStream,
        dest: File,
        password: String?,
        log: (String) -> Unit,
        progress: (Float) -> Unit,
        total: Long
    ) {
        val counted = if (total > 0) CountingInputStream(input, total, progress) else input
        val pw = password?.takeIf { it.isNotEmpty() }?.toCharArray()
        var n = 0
        val zin = if (pw != null) ZipInputStream(counted, pw) else ZipInputStream(counted)
        zin.use { z ->
            var e = z.nextEntry
            while (e != null) {
                val target = safeTarget(dest, e.fileName)
                if (e.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { out -> z.copyTo(out, 1 shl 16) }
                    n++
                    if (n % 5 == 0) log("Extracted $n files... (${e.fileName})")
                }
                e = z.nextEntry
            }
        }
        log("Extracted $n files")
        progress(1f)
    }

    // ----- 7z (via commons-compress) -----

    private fun extract7z(
        file: File,
        dest: File,
        password: String?,
        log: (String) -> Unit,
        progress: (Float) -> Unit
    ) {
        val builder = SevenZFile.builder().setFile(file)
        if (!password.isNullOrEmpty()) builder.setPassword(password.toCharArray())
        builder.get().use { sz ->
            val total = runCatching { sz.entries.sumOf { it.size } }.getOrDefault(-1L)
            var done = 0L
            var e = sz.nextEntry
            val buf = ByteArray(1 shl 16)
            while (e != null) {
                if (!e.isDirectory) {
                    val target = safeTarget(dest, e.name)
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { out ->
                        var left = e.size
                        while (left > 0) {
                            val r = sz.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                            if (r < 0) break
                            out.write(buf, 0, r)
                            left -= r
                            done += r
                        }
                    }
                    if (total > 0) progress((done.toFloat() / total).coerceIn(0f, 1f))
                    log("Extracted ${e.name}")
                }
                e = sz.nextEntry
            }
            progress(1f)
        }
    }

    // ----- RAR (via junrar) -----

    private fun extractRar(
        file: File,
        dest: File,
        password: String?,
        log: (String) -> Unit,
        progress: (Float) -> Unit
    ) {
        val pw = password?.takeIf { it.isNotEmpty() }
        val archive = if (pw != null) Archive(file, pw) else Archive(file)
        archive.use { ar ->
            val total = runCatching { ar.fileHeaders.sumOf { it.fullUnpackSize } }.getOrDefault(-1L)
            var done = 0L
            var h = ar.nextFileHeader()
            while (h != null) {
                if (!h.isDirectory) {
                    val target = safeTarget(dest, h.fileName)
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { out -> ar.extractFile(h, out) }
                    done += h.fullUnpackSize
                    if (total > 0) progress((done.toFloat() / total).coerceIn(0f, 1f))
                    log("Extracted ${h.fileName}")
                }
                h = ar.nextFileHeader()
            }
            progress(1f)
        }
    }

    /**
     * Entry point used by the Extract screen. Buffers the archive to a temp file so
     * every format (including ones that need random access such as 7z/RAR) works,
     * then dispatches to the right reader.
     */
    fun extractArchive(
        input: InputStream,
        name: String,
        dest: File,
        password: String?,
        log: (String) -> Unit,
        progress: (Float) -> Unit
    ) {
        dest.mkdirs()
        val lower = name.lowercase()
        val kind = when {
            lower.endsWith(".7z") -> "7z"
            lower.endsWith(".rar") -> "rar"
            lower.endsWith(".tar.gz") || lower.endsWith(".tgz") || lower.endsWith(".tar") -> "tar"
            else -> "zip"
        }
        val tmp = File.createTempFile("mitool_arc_", ".$kind", dest.parentFile ?: dest)
        try {
            FileOutputStream(tmp).use { out -> input.use { it.copyTo(out, 1 shl 16) } }
            val total = tmp.length()
            log("Archive size: ${total / 1048576} MB")
            when (kind) {
                "7z" -> extract7z(tmp, dest, password, log, progress)
                "rar" -> extractRar(tmp, dest, password, log, progress)
                "tar" -> FileInputStream(tmp).use { ins ->
                    if (lower.endsWith(".tar")) extractTar(ins, dest, log, progress, total)
                    else extractTarGz(ins, dest, log, progress, total)
                }
                else -> FileInputStream(tmp).use { ins ->
                    extractZipSmart(ins, dest, password, log, progress, total)
                }
            }
        } finally {
            tmp.delete()
        }
    }

    // ----- flash script parsing -----

    sealed class Step {
        data class Flash(val part: String, val path: String) : Step()
        data class Erase(val part: String) : Step()
        data class SetActive(val slot: String) : Step()
        data class Oem(val arg: String) : Step()
        data class Flashing(val arg: String) : Step()
        data class Reboot(val target: String?) : Step()
    }

    /** Folder that contains a flash_all*.sh script (root or one level down). */
    fun findRoot(dir: File): File? {
        if (File(dir, "images").isDirectory) return dir
        dir.listFiles()?.filter { it.isDirectory }?.forEach { sub ->
            if (File(sub, "images").isDirectory) return sub
        }
        return null
    }

    /** All flash_all*.sh scripts. The *_lock one re-locks the bootloader at the end. */
    fun scripts(root: File): List<File> =
        root.listFiles { f -> f.isFile && f.name.startsWith("flash_all") && f.name.endsWith(".sh") }
            ?.sortedBy { it.name } ?: emptyList()

    fun parse(script: File): List<Step> {
        val steps = ArrayList<Step>()
        for (raw in script.readLines()) {
            val line = raw.trim()
            if (line.startsWith("#") || !line.contains("fastboot")) continue
            if (line.contains("|") || line.contains("getvar")) continue
            val toks = line.replace("\"", "").replace("'", "").split(Regex("\\s+"))
            val idx = toks.indexOfFirst { it == "fastboot" || it.endsWith("/fastboot") }
            if (idx < 0) continue
            val rest = toks.drop(idx + 1).filter { it != "\$*" && it != "%*" && it != "\$@" && it.isNotBlank() }
            if (rest.isEmpty()) continue
            when (rest[0]) {
                "flash" -> if (rest.size >= 3) steps.add(Step.Flash(rest[1], rest.last()))
                "erase" -> if (rest.size >= 2) steps.add(Step.Erase(rest[1]))
                "set_active" -> if (rest.size >= 2) steps.add(Step.SetActive(rest[1]))
                "oem" -> if (rest.size >= 2) steps.add(Step.Oem(rest.drop(1).joinToString(" ")))
                "flashing" -> if (rest.size >= 2) steps.add(Step.Flashing(rest.drop(1).joinToString(" ")))
                "reboot" -> steps.add(Step.Reboot(null))
                "reboot-bootloader" -> steps.add(Step.Reboot("bootloader"))
            }
        }
        return steps
    }

    private fun isLock(arg: String) = arg.contains("lock", true) && !arg.contains("unlock", true)

    private fun resolve(root: File, path: String): File? {
        val p = path.replace('\\', '/')
        val i = p.indexOf("images/")
        if (i >= 0) File(root, p.substring(i)).takeIf { it.isFile }?.let { return it }
        val name = p.substringAfterLast('/')
        return root.walkTopDown().firstOrNull { it.isFile && it.name == name }
    }

    /** Runs a parsed script. Locking is only allowed when [allowLock] is true (flash_all_lock script). */
    fun run(
        fb: Fastboot,
        root: File,
        steps: List<Step>,
        allowLock: Boolean,
        log: (String) -> Unit,
        progress: (Float) -> Unit
    ) {
        steps.forEachIndexed { i, s ->
            val base = i.toFloat() / steps.size
            progress(base)
            when (s) {
                is Step.Flash -> {
                    val f = resolve(root, s.path)
                        ?: throw FastbootException("Missing image for ${s.part}: ${s.path}")
                    log("[${i + 1}/${steps.size}] flash ${s.part}  (${f.name})")
                    RandomAccessFile(f, "r").use { raf ->
                        fb.flashImage(s.part, raf.channel) { done, total ->
                            progress(base + (done.toFloat() / total) / steps.size)
                        }
                    }
                }
                is Step.Erase -> {
                    log("[${i + 1}/${steps.size}] erase ${s.part}")
                    fb.command("erase:${s.part}", 300000)
                }
                is Step.SetActive -> {
                    log("[${i + 1}/${steps.size}] set_active ${s.slot}")
                    fb.command("set_active:${s.slot}")
                }
                is Step.Oem -> {
                    if (isLock(s.arg) && !allowLock)
                        throw FastbootException("Refusing to run 'oem ${s.arg}' (would re-lock the bootloader)")
                    log("[${i + 1}/${steps.size}] oem ${s.arg}")
                    fb.command("oem ${s.arg}", 120000)
                }
                is Step.Flashing -> {
                    if (isLock(s.arg) && !allowLock)
                        throw FastbootException("Refusing to run 'flashing ${s.arg}' (would re-lock the bootloader)")
                    log("[${i + 1}/${steps.size}] flashing ${s.arg}")
                    fb.command("flashing ${s.arg}", 120000)
                }
                is Step.Reboot -> {
                    log("[${i + 1}/${steps.size}] reboot ${s.target ?: ""}")
                    try {
                        fb.command(if (s.target == null) "reboot" else "reboot-${s.target}", 10000)
                    } catch (_: Exception) { /* device disconnects while rebooting */ }
                }
            }
        }
        progress(1f)
    }
}
