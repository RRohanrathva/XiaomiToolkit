package com.xiaomi.toolkit.ui.screens.home

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.xiaomi.toolkit.ui.components.UsbStatusDot
import com.xiaomi.toolkit.ui.navigation.Screen
import com.xiaomi.toolkit.usb.UsbConnectionRepository
import com.xiaomi.toolkit.usb.UsbConnectionState

data class FeatureCard(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val route: String,
    val gradient: Brush
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    val features = listOf(
        FeatureCard(
            title = "Bootloader Unlock",
            description = "Unlock your device bootloader",
            icon = Icons.Default.LockOpen,
            route = Screen.BootloaderUnlock.route,
            gradient = Brush.linearGradient(
                colors = listOf(Color(0xFFFF6B6B), Color(0xFFFF8E53))
            )
        ),
        FeatureCard(
            title = "Fastboot Flash",
            description = "Flash ROM via fastboot",
            icon = Icons.Default.FlashOn,
            route = Screen.FastbootFlash.route,
            gradient = Brush.linearGradient(
                colors = listOf(Color(0xFF4E54C8), Color(0xFF8F94FB))
            )
        ),
        FeatureCard(
            title = "Device Info",
            description = "View device details",
            icon = Icons.Default.PhoneAndroid,
            route = Screen.DeviceInfo.route,
            gradient = Brush.linearGradient(
                colors = listOf(Color(0xFF06BEB6), Color(0xFF48B1BF))
            )
        ),
        FeatureCard(
            title = "Reboot Mode",
            description = "Switch between bootloader, fastbootd, recovery",
            icon = Icons.Default.RestartAlt,
            route = Screen.RebootMode.route,
            gradient = Brush.linearGradient(
                colors = listOf(Color(0xFF8E54E9), Color(0xFF4776E6))
            )
        ),
        FeatureCard(
            title = "Settings",
            description = "App configuration",
            icon = Icons.Default.Settings,
            route = Screen.Settings.route,
            gradient = Brush.linearGradient(
                colors = listOf(Color(0xFFFF9A56), Color(0xFFFFCB69))
            )
        )
    )

    val context = LocalContext.current
    val repository = remember { UsbConnectionRepository.getInstance(context) }
    val connectionState by repository.state.collectAsState()
    val isConnected = connectionState is UsbConnectionState.Connected

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Xiaomi Toolkit",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Complete solution for Xiaomi devices",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { LiveUsbStatusCard(isConnected = isConnected, state = connectionState) }
            item { DemoBanner() }
            items(features) { feature ->
                AnimatedFeatureCard(
                    feature = feature,
                    onClick = { navController.navigate(feature.route) }
                )
            }
        }
    }
}

@Composable
fun AnimatedFeatureCard(
    feature: FeatureCard,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "scale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .scale(scale)
            .clickable {
                isPressed = true
                onClick()
            },
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(feature.gradient)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = feature.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = feature.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
                
                Icon(
                    imageVector = feature.icon,
                    contentDescription = feature.title,
                    modifier = Modifier.size(56.dp),
                    tint = Color.White.copy(alpha = 0.8f)
                )
            }
        }
    }
    
    LaunchedEffect(isPressed) {
        if (isPressed) {
            kotlinx.coroutines.delay(100)
            isPressed = false
        }
    }
}

@Composable
fun LiveUsbStatusCard(isConnected: Boolean, state: UsbConnectionState) {
    val containerColor = when {
        isConnected -> MaterialTheme.colorScheme.primaryContainer
        state is UsbConnectionState.PermissionNeeded -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val label = when {
        state is UsbConnectionState.Connected ->
            "Connected: ${state.info.productName} (${"%04x".format(state.info.vendorId)}:${"%04x".format(state.info.productId)})"
        state is UsbConnectionState.PermissionNeeded -> "Device attached - grant USB permission to continue"
        else -> "No device connected"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UsbStatusDot(connected = isConnected)
            Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun DemoBanner() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Info, contentDescription = null)
            Text(
                "USB connection, device info, reboot-mode switching and image flashing above all use " +
                    "the real, standard fastboot protocol. Bootloader unlock still requires Xiaomi's own " +
                    "Mi Unlock tool and Mi-account token, so that one step stays simulated here.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
