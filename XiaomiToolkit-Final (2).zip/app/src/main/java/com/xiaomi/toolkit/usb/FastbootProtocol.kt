package com.xiaomi.toolkit.usb

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import java.io.File
import java.io.IOException

/**
 * Minimal implementation of the standard Android fastboot wire protocol
 * (as published by the Android Open Source Project:
 * https://android.googlesource.com/platform/system/core/+/master/fastboot/).
 *
 * This talks to a device that is ALREADY sitting in fastboot mode over raw
 * USB bulk transfers. It does not implement, bypass, or reverse-engineer any
 * vendor-specific unlock/authentication handshake (e.g. Xiaomi's Mi-Account
 * unlock token exchange) - those flows stay out of scope and should go
 * through Xiaomi's own official "Mi Unlock" tool.
 */
class FastbootProtocol(
    private val connection: UsbDeviceConnection,
    private val usbInterface: UsbInterface,
    private val endpointIn: UsbEndpoint,
    private val endpointOut: UsbEndpoint,
) {
    sealed class Response {
        data class Okay(val message: String) : Response()
        data class Fail(val message: String) : Response()
        data class DataPhase(val size: Int) : Response()
    }

    class FastbootException(message: String) : IOException(message)

    private val timeoutMs = 10_000
    private val maxPacket = max(endpointIn.maxPacketSize, endpointOut.maxPacketSize)

    private fun max(a: Int, b: Int) = if (a > b) a else b

    @Synchronized
    private fun sendCommand(command: String): Response {
        val bytes = command.toByteArray(Charsets.US_ASCII)
        require(bytes.size <= 64) { "fastboot command too long: $command" }
        val sent = connection.bulkTransfer(endpointOut, bytes, bytes.size, timeoutMs)
        if (sent < 0) throw FastbootException("USB write failed for '$command'")
        return readResponse()
    }

    private fun readResponse(): Response {
        val buffer = ByteArray(maxPacket.coerceAtLeast(256))
        while (true) {
            val read = connection.bulkTransfer(endpointIn, buffer, buffer.size, timeoutMs)
            if (read < 4) throw FastbootException("USB read failed or short response ($read bytes)")
            val header = String(buffer, 0, 4, Charsets.US_ASCII)
            val payload = String(buffer, 4, read - 4, Charsets.US_ASCII)
            when (header) {
                "OKAY" -> return Response.Okay(payload)
                "FAIL" -> return Response.Fail(payload)
                "INFO" -> continue // informational line, keep reading for the final status
                "DATA" -> {
                    val size = payload.trim().toIntOrNull(16)
                        ?: throw FastbootException("Malformed DATA size: $payload")
                    return Response.DataPhase(size)
                }
                else -> throw FastbootException("Unknown fastboot response header: $header")
            }
        }
    }

    /** Sends `getvar:<name>` and returns the value, or null if the device reports FAIL. */
    fun getVar(name: String): String? {
        return when (val r = sendCommand("getvar:$name")) {
            is Response.Okay -> r.message
            is Response.Fail -> null
            is Response.DataPhase -> null
        }
    }

    /** Low-level reboot-style command (e.g. "reboot", "reboot-bootloader", "reboot-fastboot", "continue"). */
    fun rebootCommand(command: String) {
        when (val r = sendCommand(command)) {
            is Response.Okay -> Unit
            is Response.Fail -> throw FastbootException(r.message)
            is Response.DataPhase -> Unit
        }
    }

    /** Sends `erase:<partition>` (standard fastboot wipe, e.g. "userdata" or "cache"). */
    fun erase(partition: String) {
        when (val r = sendCommand("erase:$partition")) {
            is Response.Okay -> Unit
            is Response.Fail -> throw FastbootException(r.message)
            is Response.DataPhase -> throw FastbootException("unexpected data phase on erase:$partition")
        }
    }

    /**
     * Flashes [imageFile] to [partition]. Standard two-step fastboot flash:
     * `download:<hex size>` followed by the raw bytes, then `flash:<partition>`.
     * Requires the device to already be unlocked (flashing a locked bootloader
     * is refused by the device itself, as intended).
     */
    fun flash(partition: String, imageFile: File, onProgress: (sentBytes: Long, totalBytes: Long) -> Unit) {
        val size = imageFile.length()
        if (size <= 0L) throw FastbootException("Image file is empty: ${imageFile.name}")

        val downloadCmd = "download:%08x".format(size)
        val downloadResponse = sendCommand(downloadCmd)
        if (downloadResponse !is Response.DataPhase) {
            val msg = (downloadResponse as? Response.Fail)?.message ?: "device refused download phase"
            throw FastbootException("download rejected: $msg")
        }

        imageFile.inputStream().use { input ->
            val chunk = ByteArray(maxPacket.coerceAtLeast(16 * 1024))
            var sent = 0L
            while (sent < size) {
                val n = input.read(chunk)
                if (n <= 0) break
                val written = connection.bulkTransfer(endpointOut, chunk, n, timeoutMs)
                if (written < 0) throw FastbootException("USB write failed during flash at offset $sent")
                sent += written
                onProgress(sent, size)
            }
        }

        when (val finalResponse = readResponse()) {
            is Response.Okay -> Unit
            is Response.Fail -> throw FastbootException(finalResponse.message)
            is Response.DataPhase -> throw FastbootException("unexpected extra data phase after upload")
        }

        when (val flashResponse = sendCommand("flash:$partition")) {
            is Response.Okay -> Unit
            is Response.Fail -> throw FastbootException(flashResponse.message)
            is Response.DataPhase -> throw FastbootException("unexpected data phase on flash:$partition")
        }
    }
}
