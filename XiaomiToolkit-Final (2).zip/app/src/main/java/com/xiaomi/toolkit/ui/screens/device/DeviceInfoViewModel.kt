package com.xiaomi.toolkit.ui.screens.device

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xiaomi.toolkit.usb.FastbootProtocol
import com.xiaomi.toolkit.usb.UsbConnectionRepository
import com.xiaomi.toolkit.usb.UsbConnectionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class DeviceInfoUiState(
    val isLoading: Boolean = true,
    val isConnected: Boolean = false,
    val needsPermission: Boolean = false,
    val deviceModel: String = "N/A",
    val deviceCodename: String = "N/A",
    val bootloaderLocked: Boolean? = null,
    val bootloaderVersion: String = "N/A",
    val serialNumber: String = "N/A",
    val secureBoot: String = "N/A",
)

/**
 * Reads device info via the standard fastboot `getvar` protocol from whatever
 * is really plugged in. No field here is simulated - if the device (or the
 * variable it doesn't support) isn't there, we show "N/A" rather than a fake
 * value.
 */
class DeviceInfoViewModel(
    private val repository: UsbConnectionRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(DeviceInfoUiState())
    val uiState: StateFlow<DeviceInfoUiState> = _uiState.asStateFlow()

    init {
        observeConnection()
    }

    private fun observeConnection() {
        viewModelScope.launch {
            repository.state.collectLatest { state ->
                when (state) {
                    is UsbConnectionState.Disconnected -> _uiState.value = DeviceInfoUiState(isLoading = false)
                    is UsbConnectionState.PermissionNeeded -> _uiState.value = DeviceInfoUiState(
                        isLoading = false,
                        needsPermission = true,
                    )
                    is UsbConnectionState.Connected -> refreshDeviceInfo()
                }
            }
        }
    }

    fun refreshDeviceInfo() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, needsPermission = false)
            val protocol = repository.currentProtocol()
            if (protocol == null) {
                _uiState.value = DeviceInfoUiState(isLoading = false)
                return@launch
            }
            val info = withContext(Dispatchers.IO) { readInfo(protocol) }
            _uiState.value = info
        }
    }

    private fun readInfo(protocol: FastbootProtocol): DeviceInfoUiState {
        fun v(name: String) = runCatching { protocol.getVar(name) }.getOrNull() ?: "N/A"

        val unlockedVar = runCatching { protocol.getVar("unlocked") }.getOrNull()
        val locked = when (unlockedVar?.lowercase()) {
            "yes" -> false
            "no" -> true
            else -> null // device doesn't expose this getvar - we don't guess
        }

        return DeviceInfoUiState(
            isLoading = false,
            isConnected = true,
            deviceModel = v("product"),
            deviceCodename = v("product"),
            bootloaderLocked = locked,
            bootloaderVersion = v("version-bootloader"),
            serialNumber = v("serialno"),
            secureBoot = v("secure"),
        )
    }

    companion object {
        fun factory(repository: UsbConnectionRepository) = object : androidx.lifecycle.ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                DeviceInfoViewModel(repository) as T
        }
    }
}
