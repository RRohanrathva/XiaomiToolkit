package com.xiaomi.toolkit.ui.screens.reboot

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.xiaomi.toolkit.ui.components.UsbStatusDot
import com.xiaomi.toolkit.usb.UsbConnectionRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RebootModeScreen(navController: NavController) {
    val context = LocalContext.current
    val repository = remember { UsbConnectionRepository.getInstance(context) }
    val viewModel: RebootViewModel = viewModel(factory = RebootViewModel.factory(repository))
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reboot Mode") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (uiState.isConnected) MaterialTheme.colorScheme.primaryContainer
                                     else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UsbStatusDot(connected = uiState.isConnected)
                    Text(
                        if (uiState.isConnected) "Device connected - sends real fastboot commands"
                        else "Connect a device in fastboot mode to send reboot commands",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            uiState.lastResult?.let { message ->
                Text(
                    message,
                    color = if (uiState.lastResultWasError) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            RebootMode.entries.forEach { mode ->
                RebootModeCard(
                    mode = mode,
                    enabled = uiState.isConnected && uiState.busyMode == null,
                    isBusy = uiState.busyMode == mode,
                    onClick = { viewModel.sendReboot(mode) }
                )
            }
        }
    }
}

@Composable
private fun RebootModeCard(
    mode: RebootMode,
    enabled: Boolean,
    isBusy: Boolean,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(mode.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    mode.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            Button(onClick = onClick, enabled = enabled) {
                if (isBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Text("Reboot")
                }
            }
        }
    }
}
