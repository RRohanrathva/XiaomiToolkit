package com.xiaomi.toolkit.ui.screens.fastboot

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xiaomi.toolkit.usb.UsbConnectionRepository
import com.xiaomi.toolkit.usb.UsbConnectionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class FlashStatus {
    IDLE, IN_PROGRESS, SUCCESS, FAILED
}

data class FastbootUiState(
    val romUri: Uri? = null,
    val romName: String? = null,
    val romSize: String? = null,
    val partitionName: String = "boot",
    val wipeData: Boolean = false,
    val wipeCache: Boolean = true,
    val isDeviceConnected: Boolean = false,
    val deviceInfo: String? = null,
    val isFlashing: Boolean = false,
    val flashProgress: Float = 0f,
    val flashStep: String = "",
    val flashStatus: FlashStatus = FlashStatus.IDLE,
    val errorMessage: String? = null,
)

/**
 * Flashing here uses the real, standard AOSP fastboot wire protocol
 * (download -> flash, erase for wipes) against whatever image file the user
 * picks. It only works on a device that is already unlocked - this app does
 * not perform or bypass the unlock itself (see BootloaderViewModel).
 */
class FastbootViewModel(
    private val repository: UsbConnectionRepository,
    private val appContext: Context,
) : ViewModel() {
    private val _uiState = MutableStateFlow(FastbootUiState())
    val uiState: StateFlow<FastbootUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.state.collectLatest { state ->
                val connected = state is UsbConnectionState.Connected
                val info = (state as? UsbConnectionState.Connected)?.info
                _uiState.value = _uiState.value.copy(
                    isDeviceConnected = connected,
                    deviceInfo = info?.let { "${it.productName} (${"%04x".format(it.vendorId)}:${"%04x".format(it.productId)})" },
                )
            }
        }
    }

    fun onRomPicked(uri: Uri) {
        val resolver = appContext.contentResolver
        var name = uri.lastPathSegment ?: "selected.img"
        var sizeBytes = -1L
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            val sizeIdx = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                if (sizeIdx >= 0) sizeBytes = cursor.getLong(sizeIdx)
            }
        }
        val sizeLabel = if (sizeBytes > 0) "%.1f MB".format(sizeBytes / 1_048_576.0) else null
        _uiState.value = _uiState.value.copy(
            romUri = uri,
            romName = name,
            romSize = sizeLabel,
            flashStatus = FlashStatus.IDLE,
            errorMessage = null,
        )
    }

    fun updatePartitionName(value: String) {
        _uiState.value = _uiState.value.copy(partitionName = value)
    }

    fun updateWipeData(value: Boolean) {
        _uiState.value = _uiState.value.copy(wipeData = value)
    }

    fun updateWipeCache(value: Boolean) {
        _uiState.value = _uiState.value.copy(wipeCache = value)
    }

    fun checkDevice() {
        // No-op: connection state comes live from the USB broadcast receiver.
    }

    fun startFlashing() {
        val state = _uiState.value
        val uri = state.romUri
        if (uri == null) {
            _uiState.value = state.copy(errorMessage = "Pick an image file first")
            return
        }
        if (state.partitionName.isBlank()) {
            _uiState.value = state.copy(errorMessage = "Enter a target partition name (e.g. boot, recovery)")
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isFlashing = true,
                flashStatus = FlashStatus.IN_PROGRESS,
                flashProgress = 0f,
                flashStep = "Preparing...",
                errorMessage = null,
            )

            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val protocol = repository.currentProtocol()
                        ?: throw IllegalStateException("No device connected")

                    val cacheFile = File(appContext.cacheDir, "flash_image.tmp")
                    appContext.contentResolver.openInputStream(uri)?.use { input ->
                        cacheFile.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalStateException("Could not open selected file")

                    if (state.wipeCache) {
                        runCatching { protocol.erase("cache") }
                    }
                    if (state.wipeData) {
                        runCatching { protocol.erase("userdata") }
                    }

                    protocol.flash(state.partitionName.trim(), cacheFile) { sent, total ->
                        viewModelScope.launch {
                            _uiState.value = _uiState.value.copy(
                                flashProgress = if (total > 0) sent.toFloat() / total else 0f,
                                flashStep = "Flashing ${state.partitionName}... (${sent / 1024}KB / ${total / 1024}KB)",
                            )
                        }
                    }
                    cacheFile.delete()
                }
            }

            _uiState.value = _uiState.value.copy(
                isFlashing = false,
                flashStatus = if (result.isSuccess) FlashStatus.SUCCESS else FlashStatus.FAILED,
                errorMessage = result.exceptionOrNull()?.message,
            )
        }
    }

    companion object {
        fun factory(repository: UsbConnectionRepository, appContext: Context) =
            object : androidx.lifecycle.ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    FastbootViewModel(repository, appContext) as T
            }
    }
}
