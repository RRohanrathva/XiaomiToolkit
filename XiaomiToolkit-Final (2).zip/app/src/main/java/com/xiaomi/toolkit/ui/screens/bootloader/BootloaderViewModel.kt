package com.xiaomi.toolkit.ui.screens.bootloader

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xiaomi.toolkit.usb.UsbConnectionRepository
import com.xiaomi.toolkit.usb.UsbConnectionState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class UnlockStatus {
    IDLE, IN_PROGRESS, SUCCESS, FAILED
}

data class BootloaderUiState(
    val currentStep: Int = 1,
    val username: String = "",
    val password: String = "",
    val isLoggedIn: Boolean = false,
    val isLoggingIn: Boolean = false,
    val isDeviceConnected: Boolean = false,
    val deviceInfo: String? = null,
    val isCheckingDevice: Boolean = false,
    val isUnlocking: Boolean = false,
    val unlockProgress: Float = 0f,
    val unlockStatus: UnlockStatus = UnlockStatus.IDLE
)

/**
 * Device connection (step 2) now reflects the real USB fastboot link via
 * [UsbConnectionRepository]. Mi-account login and the actual unlock call
 * (step 1 and step 3) stay simulated: Xiaomi's unlock token exchange is a
 * private, signed protocol between the Mi Unlock app and Xiaomi's servers
 * that this project does not reverse-engineer - use the official Mi Unlock
 * tool for the real unlock.
 */
class BootloaderViewModel(private val repository: UsbConnectionRepository) : ViewModel() {
    private val _uiState = MutableStateFlow(BootloaderUiState())
    val uiState: StateFlow<BootloaderUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.state.collectLatest { state ->
                val connected = state is UsbConnectionState.Connected
                val info = (state as? UsbConnectionState.Connected)?.info
                _uiState.value = _uiState.value.copy(
                    isDeviceConnected = connected,
                    deviceInfo = info?.let { "${it.productName} (${"%04x".format(it.vendorId)}:${"%04x".format(it.productId)})" },
                    currentStep = if (connected && _uiState.value.isLoggedIn) 3
                        else if (_uiState.value.isLoggedIn) 2
                        else _uiState.value.currentStep,
                )
            }
        }
    }

    fun updateUsername(username: String) {
        _uiState.value = _uiState.value.copy(username = username)
    }

    fun updatePassword(password: String) {
        _uiState.value = _uiState.value.copy(password = password)
    }

    fun login() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoggingIn = true)

            // Simulated: real Mi-account login is a signed, private API this
            // project intentionally does not replicate.
            delay(2000)

            _uiState.value = _uiState.value.copy(
                isLoggingIn = false,
                isLoggedIn = true,
                currentStep = 2
            )
        }
    }

    fun logout() {
        _uiState.value = BootloaderUiState(username = _uiState.value.username)
    }

    fun checkDevice() {
        // Device presence is driven by the repository's real USB broadcast
        // receiver; this just nudges the UI in case the user wants an
        // explicit "refresh" affordance while nothing has changed yet.
        _uiState.value = _uiState.value.copy(isCheckingDevice = false)
    }

    fun unlockBootloader() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isUnlocking = true,
                unlockStatus = UnlockStatus.IN_PROGRESS,
                unlockProgress = 0f
            )

            // Simulated: the actual unlock step requires Xiaomi's signed
            // unlock token obtained via the official Mi Unlock tool.
            for (i in 1..100) {
                delay(50)
                _uiState.value = _uiState.value.copy(unlockProgress = i / 100f)
            }

            delay(500)

            _uiState.value = _uiState.value.copy(
                isUnlocking = false,
                unlockStatus = UnlockStatus.FAILED,
                unlockProgress = 0f
            )
        }
    }

    companion object {
        fun factory(repository: UsbConnectionRepository) = object : androidx.lifecycle.ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                BootloaderViewModel(repository) as T
        }
    }
}
