package com.xiaomi.toolkit.usb

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private const val ACTION_USB_PERMISSION = "com.xiaomi.toolkit.USB_PERMISSION"

/** Xiaomi-known fastboot vendor IDs (also declared in res/xml/device_filter.xml). */
private val KNOWN_VENDOR_IDS = setOf(0x18D1, 0x2717) // Google (AOSP fastboot) + Xiaomi

data class ConnectedDevice(
    val device: UsbDevice,
    val productName: String,
    val vendorId: Int,
    val productId: Int,
)

sealed class UsbConnectionState {
    data object Disconnected : UsbConnectionState()
    data object PermissionNeeded : UsbConnectionState()
    data class Connected(val info: ConnectedDevice) : UsbConnectionState()
}

/**
 * Watches real USB attach/detach broadcasts and holds the live connection to a
 * device sitting in fastboot mode. Exposes a [StateFlow] so every screen reflects
 * actual hardware state instead of a simulated timer.
 */
class UsbConnectionRepository(private val appContext: Context) {

    private val usbManager = appContext.getSystemService(Context.USB_SERVICE) as UsbManager

    private val _state = MutableStateFlow<UsbConnectionState>(UsbConnectionState.Disconnected)
    val state: StateFlow<UsbConnectionState> = _state.asStateFlow()

    private var activeConnection: UsbDeviceConnection? = null
    private var activeInterface: UsbInterface? = null
    private var pendingDevice: UsbDevice? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    getDeviceFromIntent(intent)?.let { onDeviceAttached(it) }
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    getDeviceFromIntent(intent)?.let { onDeviceDetached(it) }
                }
                ACTION_USB_PERMISSION -> {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    val device = getDeviceFromIntent(intent)
                    if (granted && device != null) {
                        onDeviceAttached(device)
                    } else {
                        _state.value = UsbConnectionState.Disconnected
                    }
                }
            }
        }
    }

    private fun getDeviceFromIntent(intent: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }

    fun start() {
        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(ACTION_USB_PERMISSION)
        }
        ContextCompat.registerReceiver(appContext, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        // Pick up a device that was already plugged in before the app launched.
        usbManager.deviceList.values.firstOrNull { isRelevantDevice(it) }?.let { onDeviceAttached(it) }
    }

    fun stop() {
        closeConnection()
        runCatching { appContext.unregisterReceiver(receiver) }
    }

    private fun isRelevantDevice(device: UsbDevice): Boolean =
        device.vendorId in KNOWN_VENDOR_IDS || device.deviceClass == UsbConstants.USB_CLASS_VENDOR_SPEC

    private fun onDeviceAttached(device: UsbDevice) {
        if (!isRelevantDevice(device)) return

        if (!usbManager.hasPermission(device)) {
            pendingDevice = device
            _state.value = UsbConnectionState.PermissionNeeded
            val flags = if (Build.VERSION.SDK_INT >= 31) android.app.PendingIntent.FLAG_MUTABLE else 0
            val permissionIntent = android.app.PendingIntent.getBroadcast(
                appContext, 0, Intent(ACTION_USB_PERMISSION), flags
            )
            usbManager.requestPermission(device, permissionIntent)
            return
        }

        val opened = openFastbootInterface(device)
        _state.value = if (opened != null) {
            UsbConnectionState.Connected(
                ConnectedDevice(
                    device = device,
                    productName = device.productName ?: "Unknown device",
                    vendorId = device.vendorId,
                    productId = device.productId,
                )
            )
        } else {
            UsbConnectionState.Disconnected
        }
    }

    private fun onDeviceDetached(device: UsbDevice) {
        val current = (_state.value as? UsbConnectionState.Connected)?.info?.device
        if (current != null && current.deviceName == device.deviceName) {
            closeConnection()
            _state.value = UsbConnectionState.Disconnected
        }
    }

    /** Finds the bulk-in/bulk-out interface and opens a connection; returns a ready [FastbootProtocol]. */
    private fun openFastbootInterface(device: UsbDevice): FastbootProtocol? {
        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            var bulkIn: UsbEndpoint? = null
            var bulkOut: UsbEndpoint? = null
            for (e in 0 until iface.endpointCount) {
                val endpoint = iface.getEndpoint(e)
                if (endpoint.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (endpoint.direction == UsbConstants.USB_DIR_IN) bulkIn = endpoint
                if (endpoint.direction == UsbConstants.USB_DIR_OUT) bulkOut = endpoint
            }
            if (bulkIn != null && bulkOut != null) {
                val connection = usbManager.openDevice(device) ?: continue
                if (!connection.claimInterface(iface, true)) {
                    connection.close()
                    continue
                }
                closeConnection()
                activeConnection = connection
                activeInterface = iface
                return FastbootProtocol(connection, iface, bulkIn, bulkOut)
            }
        }
        return null
    }

    /** Returns a protocol handle for the currently connected device, or null if nothing is connected. */
    fun currentProtocol(): FastbootProtocol? {
        val connected = _state.value as? UsbConnectionState.Connected ?: return null
        val connection = activeConnection ?: return null
        val iface = activeInterface ?: return null
        var bulkIn: UsbEndpoint? = null
        var bulkOut: UsbEndpoint? = null
        for (e in 0 until iface.endpointCount) {
            val endpoint = iface.getEndpoint(e)
            if (endpoint.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
            if (endpoint.direction == UsbConstants.USB_DIR_IN) bulkIn = endpoint
            if (endpoint.direction == UsbConstants.USB_DIR_OUT) bulkOut = endpoint
        }
        if (bulkIn == null || bulkOut == null) return null
        return FastbootProtocol(connection, iface, bulkIn, bulkOut)
    }

    private fun closeConnection() {
        activeInterface?.let { activeConnection?.releaseInterface(it) }
        activeConnection?.close()
        activeConnection = null
        activeInterface = null
    }

    companion object {
        @Volatile private var instance: UsbConnectionRepository? = null

        fun getInstance(context: Context): UsbConnectionRepository =
            instance ?: synchronized(this) {
                instance ?: UsbConnectionRepository(context.applicationContext).also {
                    instance = it
                    it.start()
                }
            }
    }
}
