package com.xiaomi.toolkit.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * A small pulsing dot: solid, gently breathing glow when [connected] is true
 * (a real device is attached and talking fastboot), flat/dim grey when it
 * isn't. Drive this from [com.xiaomi.toolkit.usb.UsbConnectionState], never
 * from a timer.
 */
@Composable
fun UsbStatusDot(
    connected: Boolean,
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 14.dp,
) {
    val onColor = MaterialTheme.colorScheme.primary
    val offColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
    val targetColor = if (connected) onColor else offColor
    val color by animateColorAsState(targetValue = targetColor, label = "usbDotColor")

    val infinite = rememberInfiniteTransition(label = "usbGlow")
    val pulse by infinite.animateFloat(
        initialValue = if (connected) 0.35f else 0f,
        targetValue = if (connected) 1f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "usbGlowPulse"
    )

    Modifier // no-op anchor for readability
    androidx.compose.foundation.layout.Box(
        modifier = modifier.size(size * 2.2f),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.foundation.Canvas(modifier = Modifier.size(size * 2.2f)) {
            if (connected) {
                // soft outer glow halo that breathes
                drawCircle(
                    color = color.copy(alpha = 0.35f * pulse),
                    radius = this.size.minDimension / 2f
                )
                drawCircle(
                    color = color.copy(alpha = 0.6f * pulse + 0.4f),
                    radius = this.size.minDimension / 2f * 0.55f
                )
            } else {
                drawCircle(
                    color = color,
                    radius = this.size.minDimension / 2f * 0.45f,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }
}

/** Border that glows along the edge of a card/surface when a device is connected. */
fun Modifier.usbConnectionGlow(connected: Boolean, color: Color, cornerRadiusDp: Float = 20f): Modifier =
    this.drawBehind {
        if (!connected) return@drawBehind
        val stroke = 3.dp.toPx()
        drawRoundRect(
            color = color.copy(alpha = 0.55f),
            style = Stroke(width = stroke),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(cornerRadiusDp.dp.toPx())
        )
    }
