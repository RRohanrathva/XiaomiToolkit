package com.xiaomi.toolkit.ui.screens.reboot

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xiaomi.toolkit.usb.UsbConnectionRepository
import com.xiaomi.toolkit.usb.UsbConnectionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class RebootMode(
    val label: String,
    val description: String,
    /** Standard AOSP fastboot command string - no vendor-specific auth involved. */
    val fastbootCommand: String,
) {
    SYSTEM("System", "Reboot normally back into Android", "reboot"),
    BOOTLOADER("Bootloader", "Stay in fastboot mode", "reboot-bootloader"),
    FASTBOOTD("Fastbootd (userspace)", "Needed to flash dynamic partitions", "reboot-fastboot"),
    RECOVERY("Recovery", "Boot into recovery - not every bootloader supports this fastboot command; a FAIL response just means this device doesn't", "reboot-recovery"),
}

data class RebootUiState(
    val isConnected: Boolean = false,
    val busyMode: RebootMode? = null,
    val lastResult: String? = null,
    val lastResultWasError: Boolean = false,
)

class RebootViewModel(private val repository: UsbConnectionRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(RebootUiState())
    val uiState: StateFlow<RebootUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.state.collectLatest { state ->
                _uiState.value = _uiState.value.copy(isConnected = state is UsbConnectionState.Connected)
            }
        }
    }

    fun sendReboot(mode: RebootMode) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(busyMode = mode, lastResult = null)
            val protocol = repository.currentProtocol()
            if (protocol == null) {
                _uiState.value = _uiState.value.copy(
                    busyMode = null,
                    lastResult = "No device connected",
                    lastResultWasError = true,
                )
                return@launch
            }
            val result = withContext(Dispatchers.IO) {
                runCatching { protocol.rebootCommand(mode.fastbootCommand) }
            }
            _uiState.value = _uiState.value.copy(
                busyMode = null,
                lastResult = result.fold(
                    onSuccess = { "Sent '${mode.fastbootCommand}'" },
                    onFailure = { "Failed: ${it.message}" }
                ),
                lastResultWasError = result.isFailure,
            )
        }
    }

    companion object {
        fun factory(repository: UsbConnectionRepository) = object : androidx.lifecycle.ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                RebootViewModel(repository) as T
        }
    }
}
