package com.xiaomi.toolkit.ui.screens.device

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.xiaomi.toolkit.ui.components.UsbStatusDot
import com.xiaomi.toolkit.ui.components.usbConnectionGlow
import com.xiaomi.toolkit.usb.UsbConnectionRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceInfoScreen(
    navController: NavController,
) {
    val context = LocalContext.current
    val repository = remember { UsbConnectionRepository.getInstance(context) }
    val viewModel: DeviceInfoViewModel = viewModel(factory = DeviceInfoViewModel.factory(repository))
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Device Information") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.refreshDeviceInfo() }) {
                        Icon(Icons.Default.Refresh, "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ConnectionStatusCard(
                    isConnected = uiState.isConnected,
                    needsPermission = uiState.needsPermission
                )

                if (uiState.isConnected) {
                    InfoSection(
                        title = "Device Information",
                        icon = Icons.Default.PhoneAndroid,
                        items = listOf(
                            InfoItem("Product", uiState.deviceModel),
                            InfoItem("Serial Number", uiState.serialNumber),
                        )
                    )

                    InfoSection(
                        title = "Bootloader",
                        icon = Icons.Default.Lock,
                        items = listOf(
                            InfoItem(
                                "Status",
                                when (uiState.bootloaderLocked) {
                                    true -> "Locked"
                                    false -> "Unlocked"
                                    null -> "Not reported by device"
                                },
                                statusColor = when (uiState.bootloaderLocked) {
                                    true -> MaterialTheme.colorScheme.error
                                    false -> MaterialTheme.colorScheme.primary
                                    null -> null
                                }
                            ),
                            InfoItem("Bootloader Version", uiState.bootloaderVersion),
                            InfoItem("Secure Boot", uiState.secureBoot),
                        )
                    )
                } else if (!uiState.needsPermission) {
                    Text(
                        "Connect your device in fastboot mode (power off, then hold Volume Down + Power) " +
                            "to read its real getvar info.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

@Composable
fun ConnectionStatusCard(isConnected: Boolean, needsPermission: Boolean = false) {
    val color = if (isConnected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .usbConnectionGlow(connected = isConnected, color = color),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isConnected) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UsbStatusDot(connected = isConnected)
            Text(
                when {
                    isConnected -> "Device Connected in Fastboot Mode"
                    needsPermission -> "Device Attached - USB Permission Needed"
                    else -> "No Device Connected"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun InfoSection(
    title: String,
    icon: ImageVector,
    items: List<InfoItem>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    icon,
                    null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items.forEach { item ->
                    InfoRow(item)
                }
            }
        }
    }
}

data class InfoItem(
    val label: String,
    val value: String,
    val statusColor: androidx.compose.ui.graphics.Color? = null
)

@Composable
fun InfoRow(item: InfoItem) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            item.label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )
        Text(
            item.value,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
            color = item.statusColor ?: MaterialTheme.colorScheme.onSurface
        )
    }
}
