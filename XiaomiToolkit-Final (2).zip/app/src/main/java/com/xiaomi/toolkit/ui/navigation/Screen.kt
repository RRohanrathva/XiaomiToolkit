package com.xiaomi.toolkit.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object BootloaderUnlock : Screen("bootloader_unlock")
    object FastbootFlash : Screen("fastboot_flash")
    object DeviceInfo : Screen("device_info")
    object RebootMode : Screen("reboot_mode")
    object Settings : Screen("settings")
}
