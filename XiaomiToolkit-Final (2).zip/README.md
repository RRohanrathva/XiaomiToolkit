# Xiaomi Toolkit

Kotlin + Jetpack Compose (Material 3) app for Xiaomi devices over USB fastboot.

## What's real vs. simulated

**Real** (standard, publicly documented AOSP fastboot wire protocol over raw USB):
- USB attach/detach detection and permission handling - the glow indicator on Home,
  Device Info and Reboot Mode reflects an actual plugged-in device, not a timer.
- Device Info: reads `getvar` fields (product, serial number, bootloader version,
  secure boot, unlocked state) from whatever is really connected.
- Reboot Mode: sends real `reboot`, `reboot-bootloader`, `reboot-fastboot`,
  `reboot-recovery` commands.
- Fastboot Flash: lets you pick a real image file and flash it to a partition you
  name, using the real `download` + `flash` fastboot commands, with optional
  `erase:cache` / `erase:userdata` wipes first. This only works once the device's
  bootloader is **already unlocked**.

**Simulated** (intentionally, not implemented):
- Mi-account login and the actual bootloader *unlock* step. Xiaomi's unlock flow
  is a private, signed handshake between the official "Mi Unlock" desktop tool,
  your Mi account, and Xiaomi's servers. This project does not reverse-engineer
  or replicate that protocol - use Xiaomi's own Mi Unlock tool to unlock the
  device, then this app's Fastboot Flash / Reboot Mode screens work against it
  for real.

## Build the APK on GitHub (no extraction needed)
1. Create a repo, upload `XiaomiToolkit.zip` as-is (or the extracted files).
2. Add `.github/workflows/build-apk.yml` (code is in this repo's workflow file).
3. Actions tab -> "Build APK" -> download **XiaomiToolkit-APK** artifact.

The release APK is signed with the debug key, so both APKs install directly.
