package com.mitoolapp

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.webkit.URLUtil
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fun openBrowser(ctx: Context, url: String) {
    ctx.startActivity(Intent(ctx, BrowserActivity::class.java).putExtra("url", url))
}

object Downloads {
    class Item(val id: Long, val title: String, val status: Int, val total: Long, val done: Long)

    /** Returns null on success, or an error message. */
    fun enqueue(
        ctx: Context, url: String, userAgent: String? = null, contentDisposition: String? = null,
        mime: String? = null, cookie: String? = null
    ): String? {
        val uri = try { Uri.parse(url.trim()) } catch (e: Exception) { return "Invalid link" }
        if (uri.scheme != "http" && uri.scheme != "https") return "Only http/https links are supported"
        return try {
            val name = URLUtil.guessFileName(url.trim(), contentDisposition, mime)
            val req = DownloadManager.Request(uri)
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "MiTool/$name")
            if (!cookie.isNullOrEmpty()) req.addRequestHeader("Cookie", cookie)
            if (!userAgent.isNullOrEmpty()) req.addRequestHeader("User-Agent", userAgent)
            (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            null
        } catch (e: Exception) {
            e.message ?: "Could not start the download"
        }
    }

    fun list(ctx: Context): List<Item> {
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val out = ArrayList<Item>()
        try {
            dm.query(DownloadManager.Query())?.use { c ->
                val iId = c.getColumnIndex(DownloadManager.COLUMN_ID)
                val iTitle = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
                val iStatus = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val iTotal = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val iDone = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                while (c.moveToNext()) {
                    out.add(
                        Item(c.getLong(iId), c.getString(iTitle) ?: "download", c.getInt(iStatus), c.getLong(iTotal), c.getLong(iDone))
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out.sortedByDescending { it.id }
    }

    fun remove(ctx: Context, id: Long) {
        (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id)
    }

    fun statusText(s: Int) = when (s) {
        DownloadManager.STATUS_PENDING -> "Pending"
        DownloadManager.STATUS_RUNNING -> "Downloading"
        DownloadManager.STATUS_PAUSED -> "Paused"
        DownloadManager.STATUS_SUCCESSFUL -> "Done"
        DownloadManager.STATUS_FAILED -> "Failed"
        else -> "?"
    }
}

internal fun mb(n: Long) = "%.1f MB".format(n / 1048576.0)

// ---------------------------------------------------------------------------
// Stock ROM Xiaomi (firmware finder)
// ---------------------------------------------------------------------------

internal fun LazyListScope.stockRomItems() {
    item {
        Appear(0) {
            val ctx = LocalContext.current
            var code by remember { mutableStateOf(Ui.product.lowercase()) }
            val clean = code.trim().lowercase().filter { it.isLetterOrDigit() || it == '_' }
            Panel(
                "Stock ROM Xiaomi",
                "Find official Xiaomi fastboot (.tgz) and recovery (.zip) ROMs. Enter your device codename (example: onyx, marble, gauguin). A connected phone fills it automatically."
            ) {
                OutlinedTextField(
                    value = code, onValueChange = { code = it }, singleLine = true,
                    label = { Text("Codename") }, modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { openBrowser(ctx, "https://xmfirmwareupdater.com/hyperos/$clean/") },
                    enabled = clean.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
                ) {
                    Icon(Icons.Filled.Search, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Search stock ROMs")
                }
                OutlinedButton(
                    onClick = { openBrowser(ctx, "https://miuirom.org") },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Open miuirom.org") }
            }
        }
    }
    item {
        Appear(1) {
            Text(
                "The page opens inside MiTool. Tap a ROM's download link and it starts in the Downloads tab " +
                    "(saved in Downloads/MiTool). Then use Flash > Stock ROM > Browse TGZ. Always pick the exact " +
                    "region and codename of your phone.",
                fontSize = 12.sp, color = TextDim
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Official AOSP ROMs
// ---------------------------------------------------------------------------

private class AospRom(val name: String, val note: String, val url: String)

private val aospRoms = listOf(
    AospRom("LineageOS", "Official builds by device", "https://download.lineageos.org/devices"),
    AospRom("crDroid", "Official downloads", "https://crdroid.net/downloads"),
    AospRom("PixelOS", "Official device downloads", "https://pixelos.net/download"),
    AospRom("Evolution X", "Official build CDN", "https://cdn.evolution-x.org/"),
    AospRom("Paranoid Android (AOSPA)", "Official site", "https://paranoidandroid.co/"),
    AospRom("Lunaris AOSP", "Official GitHub", "https://github.com/Lunaris-AOSP")
)

internal fun LazyListScope.aospItems() {
    aospRoms.forEachIndexed { i, r ->
        item {
            Appear(i) {
                val ctx = LocalContext.current
                Panel(r.name, r.note) {
                    Text(r.url, fontSize = 11.sp, color = TextDim)
                    Button(
                        onClick = { openBrowser(ctx, r.url) },
                        modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(22.dp)
                    ) { Text("Open website") }
                }
            }
        }
    }
    item {
        Appear(7) {
            Text(
                "Custom ROMs need an unlocked bootloader and a build made for your exact device. " +
                    "Follow each ROM's own install guide. Downloads start in the Downloads tab.",
                fontSize = 12.sp, color = TextDim
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Download Manager
// ---------------------------------------------------------------------------

internal fun LazyListScope.downloadItems() {
    item {
        Appear(0) {
            val ctx = LocalContext.current
            var link by remember { mutableStateOf("") }
            var msg by remember { mutableStateOf<String?>(null) }
            Panel("New download", "Direct link downloads. Files are saved in Downloads/MiTool.") {
                OutlinedTextField(
                    value = link, onValueChange = { link = it; msg = null }, singleLine = true,
                    label = { Text("Direct link (https://...)") }, modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        val err = Downloads.enqueue(ctx, link)
                        msg = err ?: "Download started"
                        if (err == null) link = ""
                    },
                    enabled = link.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
                ) { Text("Download") }
                msg?.let { Text(it, fontSize = 12.sp, color = Accent) }
            }
        }
    }
    item {
        Appear(1) {
            val ctx = LocalContext.current
            var items by remember { mutableStateOf<List<Downloads.Item>>(emptyList()) }
            var speeds by remember { mutableStateOf<Map<Long, Double>>(emptyMap()) }
            LaunchedEffect(Unit) {
                var prev = emptyMap<Long, Long>()
                var prevT = System.currentTimeMillis()
                while (true) {
                    val now = Downloads.list(ctx)
                    val t = System.currentTimeMillis()
                    val dt = (t - prevT) / 1000.0
                    if (dt > 0) {
                        speeds = now.filter { it.status == DownloadManager.STATUS_RUNNING }.associate { d ->
                            d.id to maxOf(0.0, (d.done - (prev[d.id] ?: d.done)) / dt)
                        }
                    }
                    prev = now.associate { it.id to it.done }
                    prevT = t
                    items = now
                    delay(1000)
                }
            }
            Panel("Downloads", if (items.isEmpty()) "No downloads yet." else "Saved in Downloads/MiTool") {
                items.take(30).forEach { d ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(d.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        val active = d.status == DownloadManager.STATUS_RUNNING || d.status == DownloadManager.STATUS_PENDING
                        val pct = if (d.total > 0) d.done.toFloat() / d.total else -1f
                        if (active) GlowBar(pct, color = Accent2)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val sp = speeds[d.id]
                            val speedText = if (sp != null && sp > 0) "  ${"%.1f".format(sp / 1048576.0)} MB/s" else ""
                            Text(
                                Downloads.statusText(d.status) +
                                    (if (d.total > 0) "  ${mb(d.done)} / ${mb(d.total)}" else if (d.done > 0) "  ${mb(d.done)}" else "") +
                                    speedText,
                                fontSize = 11.sp, color = if (d.status == DownloadManager.STATUS_FAILED) Danger else TextDim,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { Downloads.remove(ctx, d.id) }) {
                                Text(
                                    if (d.status == DownloadManager.STATUS_SUCCESSFUL || d.status == DownloadManager.STATUS_FAILED) "Remove" else "Cancel",
                                    color = Danger
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Fastboot commands (Flash > Commands tab)
// ---------------------------------------------------------------------------

private fun loadSaved(ctx: Context): List<String> =
    ctx.getSharedPreferences("mitool", Context.MODE_PRIVATE).getStringSet("saved_cmds", emptySet())!!.sorted()

private fun storeSaved(ctx: Context, list: List<String>) {
    ctx.getSharedPreferences("mitool", Context.MODE_PRIVATE).edit().putStringSet("saved_cmds", list.toSet()).apply()
}

internal fun LazyListScope.commandItems(a: Actions) {
    item {
        Appear(0) {
            val ctx = LocalContext.current
            var cmd by remember { mutableStateOf("fastboot getvar product") }
            var saved by remember { mutableStateOf(loadSaved(ctx)) }
            Panel(
                "Fastboot command",
                "Supported: getvar, oem, flashing, erase, set_active, reboot. Use the Stock ROM and Image tabs to flash files. ADB commands are not supported."
            ) {
                OutlinedTextField(
                    value = cmd, onValueChange = { cmd = it }, singleLine = true,
                    label = { Text("fastboot getvar product") }, modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { a.runCommand(cmd) }, enabled = Ui.connected && !Ui.busy && cmd.isNotBlank(),
                        modifier = Modifier.weight(1f).height(46.dp), shape = RoundedCornerShape(23.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF00382B))
                    ) { Text("Run", fontWeight = FontWeight.Bold) }
                    OutlinedButton(
                        onClick = {
                            val c = cmd.trim()
                            if (c.isNotEmpty() && c !in saved) { saved = (saved + c).sorted(); storeSaved(ctx, saved) }
                        },
                        enabled = cmd.isNotBlank()
                    ) { Text("Save") }
                }
                Text("Quick commands", fontSize = 12.sp, color = TextDim)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "getvar product", "getvar all", "getvar unlocked", "getvar current-slot",
                        "getvar max-download-size", "oem device-info"
                    ).forEach { q -> AssistChip(onClick = { cmd = "fastboot $q" }, label = { Text(q) }) }
                }
                if (saved.isNotEmpty()) {
                    Text("Saved commands", fontSize = 12.sp, color = TextDim)
                    saved.forEach { s ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { cmd = s }, modifier = Modifier.weight(1f)) { Text(s, maxLines = 1) }
                            TextButton(onClick = { saved = saved - s; storeSaved(ctx, saved) }) { Text("X", color = Danger) }
                        }
                    }
                }
            }
        }
    }
}
