package com.mitoolapp

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---------------------------------------------------------------------------
// Palette (change these to re-colour the whole app)
// ---------------------------------------------------------------------------

internal val Bg = Color(0xFF060A10)
internal val CardBg = Color(0xFF0E1620)
internal val CardHi = Color(0xFF142131)
internal val Accent = Color(0xFF22D3A6)      // teal / emerald
internal val Accent2 = Color(0xFFA78BFA)     // violet
internal val Warn = Color(0xFFFBBF24)        // amber
internal val Danger = Color(0xFFF87171)
internal val Green = Color(0xFF39E26E)       // "connected" green
internal val MiOrange = Color(0xFFFF6900)
internal val TextMain = Color(0xFFE6EDF5)
internal val TextDim = Color(0xFF8DA2B8)

private val Scheme = darkColorScheme(
    primary = Accent, onPrimary = Color(0xFF00382B),
    primaryContainer = Color(0xFF0B3B33), onPrimaryContainer = Color(0xFFB7F5E4),
    secondary = Accent2, secondaryContainer = CardHi, onSecondaryContainer = TextMain,
    background = Bg, onBackground = TextMain,
    surface = CardBg, onSurface = TextMain,
    surfaceVariant = CardHi, onSurfaceVariant = TextDim,
    error = Danger, outline = Color(0xFF2A3B4F)
)

@Composable
fun MiToolTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}

// ---------------------------------------------------------------------------
// Glow helpers
// ---------------------------------------------------------------------------

/** 0..1 value that keeps pulsing (bulb on / off style). */
@Composable
internal fun pulse(ms: Int = 1000, min: Float = 0.15f): State<Float> {
    val t = rememberInfiniteTransition(label = "pulse")
    return t.animateFloat(
        initialValue = min, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(ms, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue"
    )
}

/** Soft glow drawn behind a composable. [intensity] 0 = off. */
internal fun Modifier.glow(color: Color, intensity: Float, corner: Dp = 20.dp, spread: Dp = 12.dp): Modifier =
    if (intensity <= 0f) this else this.drawBehind {
        val c = corner.toPx()
        val s = spread.toPx()
        val steps = 6
        for (i in steps downTo 1) {
            val g = s * i / steps
            drawRoundRect(
                color = color.copy(alpha = (intensity * 0.09f).coerceIn(0f, 1f)),
                topLeft = Offset(-g, -g),
                size = Size(size.width + g * 2, size.height + g * 2),
                cornerRadius = CornerRadius(c + g)
            )
        }
    }

/**
 * Progress line with percentage. progress < 0 means "working, unknown amount".
 * The filled part glows on and off.
 */
@Composable
internal fun GlowBar(progress: Float, label: String? = null, color: Color = Accent, modifier: Modifier = Modifier) {
    val p by pulse(900)
    val known = progress >= 0f
    val shown by animateFloatAsState(progress.coerceIn(0f, 1f), spring(stiffness = Spring.StiffnessLow), label = "bar")
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (label != null || known) {
            Row {
                Text(label ?: "", fontSize = 11.sp, color = TextDim, modifier = Modifier.weight(1f), maxLines = 1)
                if (known) Text("${(progress.coerceIn(0f, 1f) * 100).toInt()}%", fontSize = 11.sp, color = color, fontWeight = FontWeight.Bold)
            }
        }
        Box(Modifier.fillMaxWidth().height(10.dp)) {
            Box(Modifier.fillMaxSize().clip(RoundedCornerShape(5.dp)).background(CardHi))
            Box(
                Modifier.fillMaxWidth(if (known) shown else 1f).fillMaxHeight()
                    .glow(color, p, corner = 5.dp, spread = 8.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(if (known) color else color.copy(alpha = 0.25f + 0.5f * p))
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Small building blocks
// ---------------------------------------------------------------------------

@Composable
internal fun Appear(index: Int, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(40L * index); visible = true }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(spring(stiffness = Spring.StiffnessLow)) +
            slideInVertically(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) { it / 3 }
    ) { content() }
}

@Composable
internal fun Pill(text: String, color: Color, glowAmount: Float = 0f) {
    Text(
        text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = color,
        modifier = Modifier.glow(color, glowAmount, corner = 50.dp, spread = 8.dp)
            .clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
internal fun SectionHeader(title: String, tag: String, color: Color, active: Boolean = false) {
    val p by pulse(900)
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = color)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f).height(1.dp).background(color.copy(alpha = 0.35f)))
        Spacer(Modifier.width(10.dp))
        Pill(tag, color, if (active) p else 0f)
    }
}

internal class Tile(
    val label: String, val icon: ImageVector, val color: Color,
    val key: String? = null, val onClick: () -> Unit
)

@Composable
internal fun TileRow(vararg tiles: Tile) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        tiles.forEach { t -> ToolTile(t, Modifier.weight(1f)) }
        repeat(3 - tiles.size) { Spacer(Modifier.weight(1f)) }
    }
}

@Composable
internal fun ToolTile(t: Tile, modifier: Modifier) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.94f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium), label = "tile"
    )
    val p by pulse(850)
    val active = Ui.isActive(t.key)
    Card(
        modifier = modifier.height(96.dp).scale(scale).glow(t.color, if (active) p else 0f, corner = 20.dp, spread = 12.dp)
            .clickable(interactionSource = source, indication = null, onClick = t.onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardHi),
        border = BorderStroke(if (active) 2.dp else 1.dp, t.color.copy(alpha = if (active) 0.5f + 0.5f * p else 0.35f))
    ) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(
                Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(t.color.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) { Icon(t.icon, null, tint = t.color, modifier = Modifier.size(20.dp)) }
            Text(t.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
        }
    }
}

@Composable
internal fun InfoChip(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(CardHi).padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(label, fontSize = 10.sp, color = TextDim)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
internal fun Panel(title: String, subtitle: String? = null, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, Color(0xFF223246))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = TextDim)
            content()
        }
    }
}

@Composable
internal fun StepCard(
    n: Int, title: String, subtitle: String, trailing: @Composable () -> Unit = {},
    body: (@Composable () -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, Color(0xFF223246))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(28.dp).clip(CircleShape).background(Accent.copy(alpha = 0.2f))
                        .border(1.dp, Accent, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("$n", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Accent) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, fontSize = 12.sp, color = TextDim)
                }
                trailing()
            }
            body?.invoke()
        }
    }
}

@Composable
internal fun Tabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    TabRow(selectedTabIndex = selected, containerColor = CardBg, contentColor = Accent) {
        labels.forEachIndexed { i, l ->
            Tab(selected = i == selected, onClick = { onSelect(i) }, text = { Text(l, fontSize = 12.sp, maxLines = 1) })
        }
    }
}

@Composable
internal fun ScreenHeader(title: String, subtitle: String) {
    Column {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, fontSize = 12.sp, color = TextDim)
    }
}

@Composable
internal fun LogCard(maxLines: Int) {
    val clipboard = LocalClipboardManager.current
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, Color(0xFF223246))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Info, null, tint = Accent, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Log / Progress", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                TextButton(onClick = { clipboard.setText(AnnotatedString(Ui.logs.joinToString("\n"))) }) { Text("Copy") }
                TextButton(onClick = { Ui.logs.clear() }) { Text("Clear") }
            }
            if (Ui.busy) GlowBar(Ui.progress, Ui.taskName.ifEmpty { "Working" })
            Text(
                if (Ui.logs.isEmpty()) "Nothing yet." else Ui.logs.takeLast(maxLines).joinToString("\n"),
                fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextMain,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CardHi).padding(10.dp)
            )
        }
    }
}
