package com.mitoolapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** Shared handle to the connected fastboot device (set by MainActivity). */
object Dev {
    @Volatile var fb: Fastboot? = null
}

object Ui {
    val logs = mutableStateListOf<String>()

    // navigation
    var screen by mutableStateOf("home")
    var romTab by mutableIntStateOf(0)    // 0 stock rom, 1 aosp, 2 downloads
    var flashTab by mutableIntStateOf(0)  // 0 stock rom flash, 1 image, 2 commands

    // running task
    var busy by mutableStateOf(false)
    var progress by mutableFloatStateOf(-1f)
    var taskName by mutableStateOf("")
    var activeSection by mutableStateOf<String?>(null)
    var downloading by mutableStateOf(false)
    var downloadPct by mutableFloatStateOf(-1f)

    // device
    var connected by mutableStateOf(false)
    var product by mutableStateOf("")
    var deviceName by mutableStateOf("No device")
    var mode by mutableStateOf("")
    var battery by mutableStateOf("")
    var info by mutableStateOf<Map<String, String>>(emptyMap())

    // flash
    var partition by mutableStateOf("boot")
    var romName by mutableStateOf<String?>(null)
    var romState by mutableStateOf("Not selected")
    var romOk by mutableStateOf(false)
    var romInfo by mutableStateOf<Map<String, String>>(emptyMap())
    var romScripts by mutableStateOf<List<String>>(emptyList())
    var flashMode by mutableStateOf("clean")
    var wipeMeta by mutableStateOf(false)
    var wipeData by mutableStateOf(false)

    // extract
    var extractFiles by mutableStateOf<List<File>>(emptyList())
    var extractRoot by mutableStateOf<File?>(null)
    var extractState by mutableStateOf("Nothing selected")
    var selected by mutableStateOf<Set<String>>(emptySet())
    var archivePassword by mutableStateOf("")

    // unlock
    var confirm by mutableStateOf<Confirm?>(null)
    var userId by mutableStateOf<String?>(null)
    var zone by mutableStateOf<String?>(null)

    class Confirm(
        val title: String,
        val text: String,
        val cancel: (() -> Unit)? = null,
        val action: () -> Unit
    )

    fun log(s: String) {
        logs.add(s)
        while (logs.size > 400) logs.removeAt(0)
    }

    /** Is the section with this key currently doing work? (used for glow) */
    fun isActive(key: String?): Boolean = when (key) {
        null -> false
        "download" -> downloading
        else -> busy && activeSection == key
    }

    /** Script of the ROM that matches a flashing mode: clean, save or lock. */
    fun scriptFor(m: String): String? = romScripts.firstOrNull {
        when (m) {
            "lock" -> it.contains("lock")
            "save" -> it.contains("except_storage") && !it.contains("lock")
            else -> !it.contains("lock") && !it.contains("except_storage")
        }
    }
}

class Actions(
    val connect: () -> Unit,
    val reboot: (String) -> Unit,
    val login: () -> Unit,
    val logout: () -> Unit,
    val unlock: () -> Unit,
    val pickImage: () -> Unit,
    val pickRom: () -> Unit,
    val flashNow: () -> Unit,
    val pickArchive: () -> Unit,
    val runCommand: (String) -> Unit,
    val flashExtracted: (File) -> Unit,
    val deleteExtracted: () -> Unit,
    val saveSelected: () -> Unit
)
