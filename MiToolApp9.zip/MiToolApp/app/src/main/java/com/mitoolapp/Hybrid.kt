package com.mitoolapp

import java.io.File
import java.io.RandomAccessFile

/**
 * Runs the ORIGINAL installer script (.bat / .cmd) of a modified ROM zip on Android.
 * Android has no cmd.exe, so the script's own lines are interpreted one by one: echo, set, set /p,
 * choice, if, goto, labels, pause, timeout and every `fastboot ...` line. The script is never
 * rewritten. Lines MiTool cannot run are reported before starting and block the run.
 * Bootloader lock lines are never executed.
 */
object Bat {

    class Info(
        val steps: Int,
        val issues: List<String>,
        val product: String?,
        val wipes: Boolean,
        val locks: Int,
        val prompts: Boolean
    )

    sealed class Op {
        object Skip : Op()
        class Echo(val text: String) : Op()
        class Label(val name: String) : Op()
        class Goto(val name: String) : Op()
        object Exit : Op()
        class Set(val name: String, val value: String) : Op()
        class SetP(val name: String, val prompt: String) : Op()
        class Choice(val letters: String, val prompt: String) : Op()
        object Pause : Op()
        class Wait(val sec: Int) : Op()
        class If(val kind: String, val not: Boolean, val ci: Boolean, val a: String, val b: String, val then: Op) : Op()
        class Fastboot(val args: List<String>) : Op()
        class Unsupported(val why: String) : Op()
    }

    sealed class Fb {
        class Flash(val part: String, val file: String) : Fb()
        class Cmd(val cmd: String, val timeout: Long = 120000) : Fb()
        class Reboot(val target: String?) : Fb()
        class Lock(val text: String) : Fb()
        object Wipe : Fb()
        object Devices : Fb()
    }

    // ----- parsing -----

    fun splitArgs(s: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        var has = false
        for (c in s) {
            if (c == '"') {
                quoted = !quoted
                has = true
            } else if (c.isWhitespace() && !quoted) {
                if (has || sb.isNotEmpty()) { out.add(sb.toString()); sb.setLength(0); has = false }
            } else {
                sb.append(c)
            }
        }
        if (has || sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    private fun isFastbootToken(tok: String, fbVars: Set<String>): Boolean {
        val base = tok.lowercase().replace('\\', '/').substringAfterLast('/')
        if (base == "fastboot" || base == "fastboot.exe") return true
        val t = tok.trim()
        return t.length > 2 && t.startsWith("%") && t.endsWith("%") && fbVars.contains(t.trim('%').uppercase())
    }

    /** Variables that hold the fastboot program, e.g. set fastboot=%~dp0platform-tools\fastboot.exe */
    fun fastbootVars(lines: List<String>): Set<String> {
        val out = HashSet<String>()
        val re = Regex("^@?set\\s+\"?([A-Za-z0-9_]+)=(.*?)\"?$", RegexOption.IGNORE_CASE)
        for (l in lines) {
            val m = re.find(l.trim()) ?: continue
            val v = m.groupValues[2].lowercase().replace('\\', '/').substringAfterLast('/')
            if (v == "fastboot" || v == "fastboot.exe") out.add(m.groupValues[1].uppercase())
        }
        return out
    }

    private val redirect = Regex("\\s*(2>&1|\\d?>>?\\s*[^\\s&|]+)")

    fun parse(raw: String, fbVars: Set<String>): Op {
        val l = raw.trim().removePrefix("@").trim()
        if (l.isEmpty()) return Op.Skip
        val low = l.lowercase()
        if (l.startsWith("::") || low == "rem" || low.startsWith("rem ")) return Op.Skip
        if (l.startsWith(":")) return Op.Label(l.substring(1).trim().split(Regex("\\s+"))[0].lowercase())
        if (low.startsWith("echo.") || low.startsWith("echo(")) return Op.Echo(l.substring(5))
        if (low == "echo") return Op.Skip
        if (low.startsWith("echo ")) {
            val t = l.substring(5).trim()
            return if (t.lowercase() == "off" || t.lowercase() == "on") Op.Skip else Op.Echo(t)
        }
        val head = low.split(Regex("\\s+"))[0]
        if (head == "set") return parseSet(l)
        if (l.contains('|')) {
            return if (low.contains("fastboot") && low.contains("getvar")) Op.Skip   // product check: done by MiTool
            else Op.Unsupported("pipe |")
        }
        if (head == "if") return parseIf(l.substring(2).trim(), fbVars)
        val toks = splitArgs(l)
        return when (head) {
            "goto" -> {
                val t = toks.getOrNull(1)?.removePrefix(":")?.lowercase() ?: return Op.Unsupported("goto")
                if (t == "eof") Op.Exit else Op.Goto(t)
            }
            "exit" -> Op.Exit
            "pause" -> Op.Pause
            "timeout" -> {
                val i = toks.indexOfFirst { it.lowercase() == "/t" }
                val n = (if (i >= 0) toks.getOrNull(i + 1) else toks.getOrNull(1))?.toIntOrNull() ?: 1
                Op.Wait(n.coerceIn(0, 10))
            }
            "cls", "color", "title", "setlocal", "endlocal", "chcp", "mode", "cd", "pushd", "popd" -> Op.Skip
            "choice" -> {
                var letters = "YN"
                var prompt = ""
                for ((i, t) in toks.withIndex()) {
                    val lt = t.lowercase()
                    if (lt == "/c") toks.getOrNull(i + 1)?.let { letters = it }
                    else if (lt.startsWith("/c:")) letters = t.substring(3)
                    else if (lt == "/m") toks.getOrNull(i + 1)?.let { prompt = it }
                    else if (lt.startsWith("/m:")) prompt = t.substring(3)
                }
                Op.Choice(letters.uppercase(), prompt)
            }
            else -> {
                if (toks.isNotEmpty() && isFastbootToken(toks[0], fbVars)) {
                    val args = splitArgs(redirect.replace(l, "")).drop(1)
                    if (parseFb(args) == null) Op.Unsupported("fastboot ${args.joinToString(" ")}")
                    else Op.Fastboot(args)
                } else Op.Unsupported(toks.firstOrNull() ?: l)
            }
        }
    }

    private fun parseSet(l: String): Op {
        Regex("^set\\s+/p\\s+\"?([^=\"]+)=(.*?)\"?$", RegexOption.IGNORE_CASE).find(l)?.let {
            return Op.SetP(it.groupValues[1].trim().uppercase(), it.groupValues[2])
        }
        if (Regex("^set\\s+/a\\b", RegexOption.IGNORE_CASE).containsMatchIn(l)) return Op.Unsupported("set /a")
        Regex("^set\\s+\"?([^=\"/][^=\"]*)=(.*?)\"?$", RegexOption.IGNORE_CASE).find(l)?.let {
            return Op.Set(it.groupValues[1].trim().uppercase(), it.groupValues[2])
        }
        return Op.Unsupported("set")
    }

    private fun parseIf(rest: String, fbVars: Set<String>): Op {
        var r = rest
        var not = false
        var ci = false
        while (true) {
            if (r.startsWith("/i ", true)) { ci = true; r = r.substring(3).trim() }
            else if (r.startsWith("not ", true)) { not = true; r = r.substring(4).trim() }
            else break
        }
        val ic = RegexOption.IGNORE_CASE
        val kind: String
        val a: String
        var b = ""
        val tail: String
        val m1 = Regex("^errorlevel\\s+(\\d+)\\s+(.*)$", ic).find(r)
        val m2 = Regex("^exist\\s+(\"[^\"]*\"|\\S+)\\s+(.*)$", ic).find(r)
        val m3 = Regex("^defined\\s+(\\S+)\\s+(.*)$", ic).find(r)
        val m4 = Regex("^(\"[^\"]*\"|[^\\s=]+)==(\"[^\"]*\"|\\S+)\\s+(.*)$").find(r)
        when {
            m1 != null -> { kind = "errorlevel"; a = m1.groupValues[1]; tail = m1.groupValues[2] }
            m2 != null -> { kind = "exist"; a = m2.groupValues[1]; tail = m2.groupValues[2] }
            m3 != null -> { kind = "defined"; a = m3.groupValues[1]; tail = m3.groupValues[2] }
            m4 != null -> { kind = "eq"; a = m4.groupValues[1]; b = m4.groupValues[2]; tail = m4.groupValues[3] }
            else -> return Op.Unsupported("if")
        }
        if (tail.trim().startsWith("(")) return Op.Unsupported("if ( ) block")
        val then = parse(tail, fbVars)
        if (then is Op.Unsupported) return then
        return Op.If(kind, not, ci, a, b, then)
    }

    fun parseFb(args: List<String>): Fb? {
        var wipe = false
        var activeSlot: String? = null
        var i = 0
        while (i < args.size && args[i].startsWith("-")) {
            val a = args[i]
            when {
                a == "-w" -> wipe = true
                a.startsWith("--set-active=") -> activeSlot = a.substringAfter('=')
                a == "-s" -> i++
            }
            i++
        }
        val v = args.drop(i)
        if (v.isEmpty()) {
            if (wipe) return Fb.Wipe
            return activeSlot?.let { Fb.Cmd("set_active:$it") }
        }
        val rest = v.drop(1).filter { !it.startsWith("--") }
        val verb = v[0].lowercase()
        fun lockish(s: String) = s.contains("lock", true) && !s.contains("unlock", true)
        return when (verb) {
            "flash" -> if (rest.size >= 2) Fb.Flash(rest[0], rest.last()) else null
            "erase" -> if (rest.isNotEmpty()) Fb.Cmd("erase:${rest[0]}", 300000) else null
            "set_active" -> if (rest.isNotEmpty()) Fb.Cmd("set_active:${rest[0]}") else null
            "oem" -> if (rest.isEmpty()) null else if (lockish(rest.joinToString(" "))) Fb.Lock("oem ${rest.joinToString(" ")}")
                else Fb.Cmd("oem ${rest.joinToString(" ")}")
            "flashing" -> if (rest.isEmpty()) null else if (lockish(rest.joinToString(" "))) Fb.Lock("flashing ${rest.joinToString(" ")}")
                else Fb.Cmd("flashing ${rest.joinToString(" ")}")
            "getvar" -> if (rest.isNotEmpty()) Fb.Cmd("getvar:${rest[0]}", 10000) else null
            "reboot" -> Fb.Reboot(rest.firstOrNull())
            "reboot-bootloader" -> Fb.Reboot("bootloader")
            "reboot-recovery" -> Fb.Reboot("recovery")
            "reboot-fastboot" -> Fb.Reboot("fastboot")
            "continue" -> Fb.Cmd("continue")
            "devices" -> Fb.Devices
            "snapshot-update" -> if (rest.isNotEmpty()) Fb.Cmd("snapshot-update:${rest[0]}") else null
            "delete-logical-partition" -> if (rest.isNotEmpty()) Fb.Cmd("delete-logical-partition:${rest[0]}") else null
            "create-logical-partition" -> if (rest.size >= 2) Fb.Cmd("create-logical-partition:${rest[0]}:${rest[1]}") else null
            "resize-logical-partition" -> if (rest.size >= 2) Fb.Cmd("resize-logical-partition:${rest[0]}:${rest[1]}") else null
            else -> null
        }
    }

    private fun unwrap(op: Op): Op = if (op is Op.If) unwrap(op.then) else op

    // ----- inspection (before running) -----

    fun label(name: String): String {
        val n = name.lowercase()
        return when {
            n.contains("except_storage") || n.contains("save") -> "Save user data"
            n.contains("lock") && !n.contains("unlock") -> "Clean + Lock (lock line is never executed)"
            n.contains("recovery") -> "Recovery"
            n.contains("flash_all") || n.contains("clean") -> "Clean"
            else -> "Custom"
        }
    }

    fun inspect(file: File): Info {
        val lines = file.readLines()
        val fbv = fastbootVars(lines)
        val issues = ArrayList<String>()
        var steps = 0
        var wipes = false
        var locks = 0
        var prompts = false
        for ((i, raw) in lines.withIndex()) {
            val op = parse(raw, fbv)
            val u = unwrap(op)
            when (u) {
                is Op.Unsupported -> if (issues.size < 12) issues.add("line ${i + 1}: ${u.why}")
                is Op.SetP, is Op.Choice, is Op.Pause -> prompts = true
                is Op.Fastboot -> {
                    when (val fb = parseFb(u.args)) {
                        is Fb.Flash -> steps++
                        is Fb.Cmd -> { steps++; if (fb.cmd == "erase:userdata" || fb.cmd == "erase:metadata") wipes = true }
                        is Fb.Reboot -> steps++
                        is Fb.Wipe -> { steps++; wipes = true }
                        is Fb.Lock -> locks++
                        else -> {}
                    }
                }
                else -> {}
            }
        }
        val text = lines.joinToString("\n")
        val product = Regex("getvar\\s+product[^\\n]*findstr\\s+(?:/\\w+\\s+)*\"?([A-Za-z0-9_]+)\"?", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.get(1)
        return Info(steps, issues, product, wipes, locks, prompts)
    }

    // ----- running -----

    class Runner(
        private val dir: File,
        private var fb: Fastboot?,
        private val reconnect: () -> Fastboot,
        private val ask: (String) -> String?,
        private val log: (String) -> Unit,
        private val progress: (Float) -> Unit,
        private val cancelled: () -> Boolean
    ) {
        private val env = HashMap<String, String>()
        private val dirPath = dir.absolutePath.trimEnd('/') + "/"

        private fun expand(s: String): String {
            val r = s.replace("%~dp0", dirPath)
            return Regex("%([^%\\s]+)%").replace(r) { m -> env[m.groupValues[1].uppercase()] ?: "" }
        }

        private fun resolve(path: String): File? {
            val p = path.replace('\\', '/')
            File(p).takeIf { it.isFile }?.let { return it }
            val name = p.substringAfterLast('/')
            val all = dir.walkTopDown().filter { it.isFile && it.name == name }.toList()
            return all.firstOrNull { it.path.contains("images") } ?: all.firstOrNull()
        }

        private fun stop(): Nothing = throw FastbootException("Stopped")

        fun run(script: File) {
            val lines = script.readLines()
            val fbv = fastbootVars(lines)
            val ops = lines.map { parse(it, fbv) }
            val labels = HashMap<String, Int>()
            ops.forEachIndexed { i, op -> if (op is Op.Label) labels[op.name] = i }
            val total = ops.count { unwrap(it) is Op.Fastboot }.coerceAtLeast(1)
            var done = 0
            var stepNo = 0
            env["ERRORLEVEL"] = "0"
            var pc = 0
            var guard = 0
            while (pc < ops.size) {
                if (cancelled()) stop()
                if (++guard > 20000) throw FastbootException("Script loop limit reached")
                var op = ops[pc]
                pc++
                if (op is Op.Unsupported) throw FastbootException("Unsupported line ${pc}: ${op.why}")
                var jump: Int? = null
                var exit = false
                // resolve nested if
                while (op is Op.If) {
                    val c = cond(op)
                    if (!c) { op = Op.Skip; break }
                    op = op.then
                }
                when (op) {
                    is Op.Echo -> log(expand(op.text))
                    is Op.Set -> env[op.name] = expand(op.value)
                    is Op.SetP -> {
                        val q = expand(op.prompt)
                        log("PROMPT: $q")
                        val r = ask(q) ?: stop()
                        log("> $r")
                        env[op.name] = r
                    }
                    is Op.Choice -> {
                        val q = expand(op.prompt).ifEmpty { "Choose" } + " [" + op.letters.toCharArray().joinToString(",") + "]"
                        log("PROMPT: $q")
                        while (true) {
                            val r = (ask(q) ?: stop()).trim().uppercase()
                            val idx = if (r.isEmpty()) -1 else op.letters.indexOf(r[0])
                            if (idx >= 0) { env["ERRORLEVEL"] = (idx + 1).toString(); log("> ${r[0]}"); break }
                            log("Invalid choice")
                        }
                    }
                    is Op.Pause -> { log("PROMPT: Press Send Reply to continue"); ask("Press Send Reply to continue") ?: stop() }
                    is Op.Wait -> {
                        var ms = op.sec * 1000
                        while (ms > 0) { if (cancelled()) stop(); Thread.sleep(200); ms -= 200 }
                    }
                    is Op.Goto -> jump = labels[op.name] ?: throw FastbootException("Missing label :${op.name}")
                    is Op.Exit -> exit = true
                    is Op.Fastboot -> {
                        stepNo++
                        runFastboot(op.args.map { expand(it) }, stepNo, total)
                        done++
                        progress((done.toFloat() / total).coerceAtMost(1f))
                    }
                    else -> {}
                }
                if (exit) break
                if (jump != null) pc = jump
            }
            progress(1f)
        }

        private fun cond(c: Op.If): Boolean {
            val r = when (c.kind) {
                "errorlevel" -> (env["ERRORLEVEL"]?.toIntOrNull() ?: 0) >= (c.a.toIntOrNull() ?: 0)
                "exist" -> resolve(expand(c.a).trim('"')) != null || File(expand(c.a).trim('"').replace('\\', '/')).exists()
                "defined" -> !env[c.a.uppercase()].isNullOrEmpty()
                else -> {
                    val x = expand(c.a).trim('"')
                    val y = expand(c.b).trim('"')
                    if (c.ci) x.equals(y, true) else x == y
                }
            }
            return if (c.not) !r else r
        }

        private fun runFastboot(args: List<String>, n: Int, total: Int) {
            val cmd = parseFb(args) ?: throw FastbootException("Unsupported fastboot line: ${args.joinToString(" ")}")
            val f = fb ?: throw FastbootException("No fastboot device connected")
            try {
                when (cmd) {
                    is Fb.Flash -> {
                        val file = resolve(cmd.file) ?: throw FastbootException("Missing image for ${cmd.part}: ${cmd.file}")
                        log("[$n/$total] Flashing ${file.name} -> ${cmd.part} ...")
                        RandomAccessFile(file, "r").use { raf ->
                            f.flashImage(cmd.part, raf.channel) { d, t ->
                                progress(((n - 1).toFloat() + d.toFloat() / t) / total)
                            }
                        }
                        log("      OK")
                    }
                    is Fb.Cmd -> {
                        log("[$n/$total] fastboot ${args.joinToString(" ")}")
                        val r = f.command(cmd.cmd, cmd.timeout)
                        r.info.forEach { log("      $it") }
                        if (r.okay.isNotBlank()) log("      ${r.okay}")
                    }
                    is Fb.Reboot -> {
                        log("[$n/$total] reboot ${cmd.target ?: ""}")
                        val c = if (cmd.target == null) "reboot" else "reboot-${cmd.target}"
                        try { f.command(c, 10000) } catch (_: Exception) { /* phone disconnects while rebooting */ }
                        fb = null
                        if (cmd.target == "bootloader" || cmd.target == "fastboot") {
                            log("      waiting for the phone to come back in fastboot ...")
                            fb = reconnect()
                            log("      OK")
                        }
                    }
                    is Fb.Lock -> log("[$n/$total] SKIPPED (MiTool never locks the bootloader): fastboot ${cmd.text}")
                    is Fb.Wipe -> {
                        log("[$n/$total] fastboot -w (erase userdata + metadata)")
                        f.command("erase:userdata", 300000)
                        try { f.command("erase:metadata", 300000) } catch (e: FastbootException) { log("      metadata: ${e.message}") }
                    }
                    is Fb.Devices -> log("[$n/$total] device: ${f.getvar("product") ?: "unknown"}")
                }
                env["ERRORLEVEL"] = "0"
            } catch (e: FastbootException) {
                env["ERRORLEVEL"] = "1"
                if (e.message == "Stopped") throw e
                throw FastbootException("Step $n failed: ${e.message}")
            }
        }
    }
}
