package com.mitoolapp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TermBg = Color(0xFF05080D)
private val PanelBorder = BorderStroke(1.dp, Color(0xFF1E2C3D))
private val Mono = FontFamily.Monospace

private val adbInfo = listOf(
    "Devices" to "adb devices",
    "Model" to "adb shell getprop ro.product.model",
    "Manufacturer" to "adb shell getprop ro.product.manufacturer",
    "Codename" to "adb shell getprop ro.product.device",
    "Android" to "adb shell getprop ro.build.version.release",
    "Security patch" to "adb shell getprop ro.build.version.security_patch",
    "Build" to "adb shell getprop ro.build.display.id",
    "Serial" to "adb shell getprop ro.serialno",
    "CPU ABI" to "adb shell getprop ro.product.cpu.abi",
    "Battery" to "adb shell dumpsys battery",
    "Storage" to "adb shell df -h /data",
    "Memory" to "adb shell cat /proc/meminfo"
)

private val fbInfo = listOf(
    "Product" to "fastboot getvar product",
    "Serial" to "fastboot getvar serialno",
    "Unlocked" to "fastboot getvar unlocked",
    "Current slot" to "fastboot getvar current-slot",
    "Slot count" to "fastboot getvar slot-count",
    "Max download" to "fastboot getvar max-download-size",
    "Bootloader" to "fastboot getvar version-bootloader",
    "Userspace" to "fastboot getvar is-userspace",
    "Secure" to "fastboot getvar secure",
    "Device info" to "fastboot oem device-info",
    "All variables" to "fastboot getvar all"
)

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, fontSize = 11.sp, color = TextDim, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun CmdChips(items: List<Pair<String, String>>, enabled: Boolean, a: Actions) {
    // simple wrapping rows of 2-3 chips
    items.chunked(3).forEach { row ->
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            row.forEach { (label, cmd) ->
                AssistChip(onClick = { a.runTerm(cmd) }, enabled = enabled, label = { Text(label, fontSize = 12.sp) })
            }
        }
    }
}

/** ADB / Fastboot command center: device strip, 4 sub-tabs, left panel per tab, output console. */
@Composable
internal fun TerminalScreen(a: Actions, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("DEVICE COMMAND CENTER", fontSize = 10.sp, color = Accent, fontWeight = FontWeight.Bold)
        Text("ADB / Fastboot Commands", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Separate information-only checks from actions that change your phone.", fontSize = 12.sp, color = TextDim)

        // device strip
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CardBg)
                .border(PanelBorder, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Connected Device", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                if (Ui.connected) Text("${Ui.deviceName} · ${Ui.mode}", fontSize = 11.sp, color = TextDim, maxLines = 1)
            }
            Pill(if (Ui.connected) Ui.transport.uppercase() else "NOT SCANNED", if (Ui.connected) Green else TextDim)
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = a.connect, enabled = !Ui.busy, border = BorderStroke(1.dp, Accent),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)) {
                Icon(Icons.Filled.Refresh, null, tint = Accent, modifier = Modifier.height(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Refresh", color = Accent, fontSize = 12.sp)
            }
        }

        // sub-tabs
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ADB Info", "Fastboot Info", "Device Actions", "Manual Command").forEachIndexed { i, label ->
                val sel = Ui.cmdTab == i
                Text(
                    label, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    color = if (sel) Color.White else TextMain,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp))
                        .background(if (sel) Color(0xFF1E7BE0) else CardHi)
                        .border(1.dp, if (sel) Color(0xFF4DA3FF) else Color(0xFF2A3B4F), RoundedCornerShape(10.dp))
                        .clickable { Ui.cmdTab = i }
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                )
            }
        }

        // left panel (per tab)
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardBg)
                .border(PanelBorder, RoundedCornerShape(14.dp)).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (Ui.cmdTab) {
                0 -> {
                    val ok = Ui.transport == "adb" && !Ui.busy
                    Text("Shows information only. No partitions or data are modified.", fontSize = 11.sp, color = TextDim)
                    if (Ui.transport != "adb") Text("Connect the phone with USB debugging (ADB) to use this tab.", fontSize = 11.sp, color = Warn)
                    Button(
                        onClick = { a.runBatch(adbInfo.map { it.second }.filter { it != "adb devices" }) }, enabled = ok,
                        modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(22.dp)
                    ) { Text("Scan all info", fontWeight = FontWeight.Bold) }
                    CmdChips(adbInfo, ok, a)
                }
                1 -> {
                    val ok = Ui.transport == "fastboot" && !Ui.busy
                    Text("Shows information only. No partitions or data are modified.", fontSize = 11.sp, color = TextDim)
                    if (Ui.transport != "fastboot") Text("Boot the phone to fastboot to use this tab.", fontSize = 11.sp, color = Warn)
                    Button(
                        onClick = { a.runBatch(fbInfo.map { it.second }.filter { !it.endsWith("all") }) }, enabled = ok,
                        modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(22.dp)
                    ) { Text("Scan all info", fontWeight = FontWeight.Bold) }
                    CmdChips(fbInfo, ok, a)
                }
                2 -> {
                    Text("These actions can change the phone. Reboots ask for confirmation.", fontSize = 11.sp, color = Warn)
                    val en = Ui.connected && !Ui.busy
                    Section("Reboot") {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("System" to "system", "Bootloader" to "bootloader", "Recovery" to "recovery", "Fastbootd" to "fastboot")
                                .forEach { (l, t) -> AssistChip(onClick = { a.reboot(t) }, enabled = en, label = { Text(l, fontSize = 12.sp) }) }
                        }
                    }
                    Section("Boot slot (fastboot, A/B phones)") {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("a", "b").forEach { sl ->
                                AssistChip(
                                    onClick = { a.runTerm("fastboot set_active $sl") },
                                    enabled = Ui.transport == "fastboot" && !Ui.busy,
                                    label = { Text("Set active slot $sl", fontSize = 12.sp) }
                                )
                            }
                        }
                    }
                    Section("ROM sideload (ADB)") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = a.pickSideload, enabled = Ui.transport == "adb" && !Ui.busy,
                                shape = RoundedCornerShape(20.dp), modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent2)
                            ) { Text("Sideload ROM (.zip)", fontSize = 12.sp, maxLines = 1) }
                            OutlinedButton(
                                onClick = { a.reboot("sideload") }, enabled = Ui.transport == "adb" && !Ui.busy,
                                shape = RoundedCornerShape(20.dp), modifier = Modifier.weight(1f)
                            ) { Text("Reboot to sideload", fontSize = 12.sp, maxLines = 1) }
                        }
                        Text("Phone must be in recovery > Apply update from ADB. Use AOSP ADB Sideload for the full automatic flow.", fontSize = 10.sp, color = TextDim)
                    }
                    Section("ADB") {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AssistChip(onClick = { a.runTerm("adb root") }, enabled = Ui.transport == "adb" && !Ui.busy, label = { Text("adb root", fontSize = 12.sp) })
                            AssistChip(onClick = { a.runTerm("adb unroot") }, enabled = Ui.transport == "adb" && !Ui.busy, label = { Text("adb unroot", fontSize = 12.sp) })
                        }
                    }
                }
                else -> ManualPanel(a)
            }
        }

        ConsoleCard()
    }
}

@Composable
private fun ManualPanel(a: Actions) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(loadSaved(ctx)) }

    fun run(text: String) {
        if (text.isBlank()) return
        a.runTerm(text)
        input = ""
    }

    Text("Type adb or fastboot commands. Type help for the list.", fontSize = 11.sp, color = TextDim)

    // input row with automatic $ prompt
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(TermBg)
            .border(BorderStroke(1.dp, Accent.copy(alpha = 0.5f)), RoundedCornerShape(12.dp)).padding(start = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$", fontFamily = Mono, fontSize = 16.sp, color = Accent, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        BasicTextField(
            value = input, onValueChange = { input = it },
            textStyle = TextStyle(color = Color.White, fontFamily = Mono, fontSize = 14.sp),
            cursorBrush = SolidColor(Accent), singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { run(input) }),
            modifier = Modifier.weight(1f).padding(vertical = 12.dp),
            decorationBox = { inner ->
                if (input.isEmpty()) Text("type a command...", fontFamily = Mono, fontSize = 14.sp, color = TextDim)
                inner()
            }
        )
        TextButton(onClick = {
            val c = input.trim()
            if (c.isNotEmpty() && c !in saved) { saved = (saved + c).sorted(); storeSaved(ctx, saved) }
        }, enabled = input.isNotBlank()) { Text("Save", fontSize = 12.sp) }
        TextButton(onClick = { run(input) }, enabled = input.isNotBlank()) {
            Text("Run", color = Accent, fontWeight = FontWeight.Bold)
        }
    }

    val quick = if (Ui.transport == "adb")
        listOf("adb devices", "adb shell getprop ro.product.model", "adb shell dumpsys battery", "adb logcat -d", "adb reboot recovery")
    else
        listOf("fastboot getvar product", "fastboot getvar all", "fastboot getvar unlocked", "fastboot oem device-info", "fastboot reboot")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        quick.forEach { q -> AssistChip(onClick = { input = q }, label = { Text(q.removePrefix("adb ").removePrefix("fastboot "), fontSize = 11.sp) }) }
    }

    if (saved.isNotEmpty()) {
        Text("Saved commands", fontSize = 11.sp, color = TextDim)
        Column(
            Modifier.fillMaxWidth().heightIn(max = 150.dp).clip(RoundedCornerShape(10.dp))
                .background(CardHi).verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            saved.forEach { s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("$ $s", fontFamily = Mono, fontSize = 12.sp, maxLines = 1,
                        modifier = Modifier.weight(1f).clickable { input = s }.padding(vertical = 8.dp))
                    Text("Run", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { run(s) }.padding(horizontal = 10.dp, vertical = 8.dp))
                    Text("X", color = Danger, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { saved = saved - s; storeSaved(ctx, saved) }.padding(horizontal = 10.dp, vertical = 8.dp))
                }
            }
        }
    }
}

/** Right-hand panel of the desktop design: "Command Output / Results" with Copy. */
@Composable
private fun ConsoleCard() {
    val clipboard = LocalClipboardManager.current
    val listState = rememberLazyListState()
    LaunchedEffect(Ui.term.size) {
        if (Ui.term.isNotEmpty()) listState.scrollToItem(Ui.term.size - 1)
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardBg)
            .border(PanelBorder, RoundedCornerShape(14.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Command Output / Results", Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = { Ui.term.clear() }) { Text("Clear", fontSize = 12.sp) }
            TextButton(onClick = { clipboard.setText(AnnotatedString(Ui.term.joinToString("\n"))) }) { Text("Copy", fontSize = 12.sp) }
        }
        Box(
            Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(10.dp)).background(TermBg)
                .border(PanelBorder, RoundedCornerShape(10.dp))
        ) {
            if (Ui.term.isEmpty()) {
                Text("No commands executed.", fontFamily = Mono, fontSize = 12.sp, color = TextDim, modifier = Modifier.padding(12.dp))
            }
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 8.dp)) {
                items(Ui.term.toList()) { line ->
                    if (line.startsWith("$ ")) {
                        Row {
                            Text("$ ", fontFamily = Mono, fontSize = 13.sp, color = Accent, fontWeight = FontWeight.Bold)
                            Text(line.removePrefix("$ "), fontFamily = Mono, fontSize = 13.sp, color = Color.White)
                        }
                    } else {
                        val c = when {
                            line.startsWith("FAIL") || line.startsWith("error") || line.contains("failed") -> Danger
                            line.startsWith("OKAY") || line.startsWith("done") -> Green
                            else -> Color(0xFFC9D4E0)
                        }
                        Text(line.ifEmpty { " " }, fontFamily = Mono, fontSize = 12.sp, color = c)
                    }
                }
            }
        }
    }
}
