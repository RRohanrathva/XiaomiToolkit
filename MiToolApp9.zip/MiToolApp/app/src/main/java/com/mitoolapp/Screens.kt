package com.mitoolapp

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------
// Root: fixed top bar, content, floating reboot, bottom navigation
// ---------------------------------------------------------------------------

@Composable
internal fun Root(a: Actions) {
    val view = LocalView.current
    SideEffect { view.keepScreenOn = Ui.busy }
    BackHandler(enabled = Ui.screen != "home") { Ui.screen = "home" }

    Box(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            TopBar(a)
            GlobalProgress()
            if (Ui.screen == "terminal") {
                TerminalScreen(a, Modifier.weight(1f))
            } else LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (Ui.screen) {
                    "stockxiaomi" -> { backHeader("Stock ROM Xiaomi", "Find official Xiaomi firmware and download it."); stockRomItems() }
                    "aosp" -> { backHeader("Official AOSP ROMs", "Open a ROM's website and download from there."); aospItems() }
                    "downloads" -> { backHeader("Download Manager", "All downloads with progress."); downloadItems() }
                    "stockflash" -> stockFlashScreen(a)
                    "image" -> imageScreen(a)
                    "aospsideload" -> aospSideloadItems(a)
                    "hybrid" -> hybridItems(a)
                    "bloat" -> bloatItems(a)
                    "extract" -> extractScreenItems(a)
                    "unlock" -> unlockItems(a)
                    "logs" -> logsItems()
                    else -> homeItems(a)
                }
            }
            NavigationBar(containerColor = CardBg) {
                NavItem("home", "Home", Icons.Filled.Home)
                NavItem("logs", "Logs", Icons.Filled.List)
            }
        }
    }

    HybridDialogs(a)

    Ui.confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { Ui.confirm = null; c.cancel?.invoke() },
            containerColor = CardBg,
            title = { Text(c.title) },
            text = { Text(c.text) },
            confirmButton = { TextButton(onClick = { Ui.confirm = null; c.action() }) { Text("Continue") } },
            dismissButton = { TextButton(onClick = { Ui.confirm = null; c.cancel?.invoke() }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun RowScope.NavItem(id: String, label: String, icon: ImageVector) {
    NavigationBarItem(
        selected = Ui.screen == id || (id == "home" && Ui.screen != "logs"),
        onClick = { Ui.screen = id },
        icon = { Icon(icon, null) },
        label = { Text(label, fontSize = 11.sp, maxLines = 1) }
    )
}

// ---------------------------------------------------------------------------
// Fixed top bar
// ---------------------------------------------------------------------------

@Composable
internal fun TopBar(a: Actions) {
    val p by pulse(900)
    Row(
        Modifier.fillMaxWidth().background(CardBg).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("MiTool", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MiOrange)
        Spacer(Modifier.weight(1f))
        if (Ui.connected) {
            Column(horizontalAlignment = Alignment.End) {
                Text(Ui.deviceName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                val sub = listOf(Ui.mode, Ui.battery).filter { it.isNotEmpty() }.joinToString(" · ")
                if (sub.isNotEmpty()) Text(sub, fontSize = 10.sp, color = TextDim, maxLines = 1)
            }
            Spacer(Modifier.width(10.dp))
        }
        // always scanning: amber and pulsing while no device, green and glowing when connected
        Pill(if (Ui.connected) "Connected" else "Scanning...", if (Ui.connected) Green else Warn, p)
        Spacer(Modifier.width(8.dp))
        RebootButton(a)
    }
}

@Composable
private fun GlobalProgress() {
    if (!Ui.busy && !Ui.downloading) return
    Column(
        Modifier.fillMaxWidth().background(CardBg).padding(horizontal = 14.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (Ui.busy) GlowBar(Ui.progress, Ui.taskName.ifEmpty { "Working" })
        if (Ui.downloading) GlowBar(Ui.downloadPct, "Downloading", Accent2)
    }
}

// ---------------------------------------------------------------------------
// Reboot manager: round button in the top bar, reboots the connected USB phone
// ---------------------------------------------------------------------------

@Composable
private fun RebootButton(a: Actions) {
    var open by remember { mutableStateOf(false) }
    val p by pulse(900)
    val enabled = Ui.connected && !Ui.busy
    Box {
        Column(
            Modifier.size(42.dp).glow(Accent2, if (open) p else 0f, corner = 21.dp, spread = 8.dp)
                .clip(CircleShape).background(CardHi).border(1.dp, Accent2, CircleShape)
                .clickable { open = !open },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Filled.Refresh, null, tint = Accent2, modifier = Modifier.size(15.dp))
            Text("Reboot", fontSize = 8.sp, color = Accent2, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
        DropdownMenu(
            expanded = open, onDismissRequest = { open = false },
            modifier = Modifier.background(CardBg)
        ) {
            Text("Reboot manager", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp))
            Text(
                if (Ui.connected) "Device: ${Ui.deviceName}" else "No USB device connected",
                fontSize = 11.sp, color = if (Ui.connected) Green else Danger,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp)
            )
            listOf(
                Triple("Reboot system", "system", Accent),
                Triple("Reboot bootloader", "bootloader", Accent),
                Triple("Reboot recovery", "recovery", Accent),
                Triple("Reboot fastbootd", "fastboot", Accent2),
                Triple("Reboot EDL", "edl", Danger)
            ).forEach { (label, target, color) ->
                DropdownMenuItem(
                    text = { Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = color) },
                    enabled = enabled,
                    onClick = { open = false; a.reboot(target) }
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------

internal fun LazyListScope.homeItems(a: Actions) {
    item { Appear(0) { DeviceCard(a) } }

    item { Appear(1) { SectionHeader("Stock & Custom ROMs", "ROMS", Accent, Ui.isActive("download")) } }
    item {
        Appear(2) {
            TileRow(
                Tile("Stock ROM Xiaomi", Icons.Filled.Search, Accent) { Ui.screen = "stockxiaomi" },
                Tile("Official AOSP ROMs", Icons.Filled.Phone, Accent) { Ui.screen = "aosp" },
                Tile("Download Manager", Icons.Filled.Home, Accent, "download") { Ui.screen = "downloads" }
            )
        }
    }

    item { Appear(3) { SectionHeader("Flash", "FLASH", Accent2, Ui.isActive("flash")) } }
    item {
        Appear(4) {
            TileRow(
                Tile("Stock ROM Flash", Icons.Filled.PlayArrow, Accent2, "flash") { Ui.screen = "stockflash" },
                Tile("Flash Image", Icons.Filled.Build, Accent2, "flash") { Ui.screen = "image" },
                Tile("ADB / Fastboot Commands", Icons.Filled.Create, Accent2, "terminal") { Ui.screen = "terminal" }
            )
        }
    }
    item {
        Appear(5) {
            TileRow(
                Tile("AOSP ADB Sideload", Icons.Filled.Build, Accent2, "aosp") { Ui.screen = "aospsideload" },
                Tile("Hybrid Flasher", Icons.Filled.PlayArrow, Accent2, "hybrid") { Ui.screen = "hybrid" }
            )
        }
    }

    item { Appear(5) { SectionHeader("System & Modify", "MODIFY", Accent, Ui.isActive("extract")) } }
    item {
        Appear(6) {
            TileRow(
                Tile("Extract Archives", Icons.Filled.Create, Accent, "extract") { Ui.screen = "extract" },
                Tile("Bloatware Remover", Icons.Filled.Delete, Accent, "bloat") { Ui.screen = "bloat" }
            )
        }
    }

    item { Appear(7) { SectionHeader("Xiaomi & Device", "XIAOMI", Warn, Ui.isActive("unlock")) } }
    item {
        Appear(8) {
            TileRow(Tile("Bootloader Unlock", Icons.Filled.Lock, Warn, "unlock") { Ui.screen = "unlock" })
        }
    }

    item {
        Appear(9) {
            Text(
                "Unlocking and flashing can erase all data, void warranty or brick the phone. " +
                    "Use at your own risk. Unlock protocol based on MiForge/MiUnlockTool (Apache-2.0) " +
                    "and MiForge/migate (MIT).",
                fontSize = 11.sp, color = TextDim
            )
        }
    }
}

@Composable
internal fun DeviceCard(a: Actions) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, (if (Ui.connected) Green else Accent).copy(alpha = 0.3f))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(if (Ui.connected) Green else Danger))
                Spacer(Modifier.width(8.dp))
                Text("Connected Device", fontSize = 13.sp, color = if (Ui.connected) Green else TextDim)
            }
            Text(if (Ui.connected) Ui.deviceName else "No USB target", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            if (Ui.info.isNotEmpty()) {
                Ui.info.entries.toList().chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (k, v) -> InfoChip(k, v, Modifier.weight(1f)) }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            } else {
                Text(
                    "Boot the target phone to fastboot and connect it with a USB OTG cable. MiTool scans automatically.",
                    fontSize = 12.sp, color = TextDim
                )
            }
            Button(
                onClick = a.connect, enabled = !Ui.busy,
                modifier = Modifier.fillMaxWidth().height(46.dp), shape = RoundedCornerShape(23.dp)
            ) {
                Icon(Icons.Filled.Refresh, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (Ui.connected) "Reconnect" else "Scan now")
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Dedicated screens (no tabs: every tile opens only its own content)
// ---------------------------------------------------------------------------

internal fun LazyListScope.backHeader(title: String, sub: String) {
    item { Appear(0) { ScreenHeader(title, sub) } }
}

private fun LazyListScope.stockFlashScreen(a: Actions) {
    item {
        Appear(0) {
            Column {
                ScreenHeader("Stock ROM Flash", "Flash a Xiaomi fastboot ROM (.tgz).")
                Text(
                    if (Ui.connected && Ui.transport == "fastboot") "Target: ${Ui.deviceName}" else "Connect the phone in fastboot mode.",
                    fontSize = 12.sp, color = if (Ui.connected && Ui.transport == "fastboot") Green else Danger
                )
            }
        }
    }
    stockFlashItems(a)
}

private fun LazyListScope.imageScreen(a: Actions) {
    item { Appear(0) { ScreenHeader("Flash Image", "Write one .img file to a partition.") } }
    imageItems(a)
}

private fun LazyListScope.stockFlashItems(a: Actions) {
    item {
        Appear(1) {
            StepCard(1, "Select TGZ ROM", "Choose Xiaomi Fastboot ROM (.tgz)", trailing = {
                OutlinedButton(onClick = a.pickRom, enabled = !Ui.busy, border = BorderStroke(1.dp, Accent)) {
                    Text("Browse TGZ", color = Accent)
                }
            })
        }
    }
    item {
        Appear(2) {
            val stateColor = when (Ui.romState) {
                "Ready" -> Accent
                "Failed" -> Danger
                "Extracting..." -> Warn
                else -> TextDim
            }
            StepCard(2, "Extract & Prepare", "Extract archive and find flash scripts",
                trailing = { Text(Ui.romState, fontSize = 12.sp, color = stateColor, fontWeight = FontWeight.SemiBold) },
                body = {
                    Text(
                        Ui.romName ?: "No ROM selected",
                        fontSize = 12.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CardHi).padding(10.dp)
                    )
                    if (Ui.busy && Ui.romState == "Extracting...") GlowBar(Ui.progress, "Extracting ROM")
                })
        }
    }
    item {
        Appear(3) {
            StepCard(3, "ROM Information", "Detected from the file name and scripts", body = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Build", "Android", "Scripts").forEach { k ->
                        InfoChip(k, Ui.romInfo[k] ?: "-", Modifier.weight(1f))
                    }
                }
            })
        }
    }
    item {
        Appear(4) {
            StepCard(4, "Flashing Mode", "Select a flashing method", body = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeButton("Clean All", "clean", Accent, Modifier.weight(1f))
                    ModeButton("Save User Data", "save", Accent, Modifier.weight(1f))
                    ModeButton("Clean All + Lock", "lock", Danger, Modifier.weight(1f))
                }
                if (Ui.flashMode == "lock") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, null, tint = Danger, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Re-locks the bootloader. Use only the exact official ROM for this phone.",
                            fontSize = 11.sp, color = Danger)
                    }
                }
            })
        }
    }
    item {
        Appear(5) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                border = BorderStroke(1.dp, Color(0xFF223246))
            ) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                    Text("Options (Optional)", fontSize = 13.sp, color = TextDim)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = Ui.wipeMeta, onCheckedChange = { Ui.wipeMeta = it })
                        Text("Wipe Metadata", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Checkbox(checked = Ui.wipeData, onCheckedChange = { Ui.wipeData = it })
                        Text("Wipe Userdata", fontSize = 13.sp, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
    item {
        Appear(6) {
            val ok = Ui.connected && Ui.transport == "fastboot" && Ui.romOk && Ui.scriptFor(Ui.flashMode) != null && !Ui.busy
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = a.flashNow, enabled = ok,
                    modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF00382B))
                ) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Flash Now", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    when {
                        !Ui.connected -> "Connect a fastboot device first"
                        !Ui.romOk -> "Select a ROM with a supported flash script"
                        Ui.scriptFor(Ui.flashMode) == null -> "This ROM has no script for the selected mode"
                        else -> "Ready: ${Ui.scriptFor(Ui.flashMode)}"
                    },
                    fontSize = 12.sp, color = TextDim
                )
            }
        }
    }
    item { Appear(7) { LogCard(maxLines = 30) } }
}

private fun LazyListScope.imageItems(a: Actions) {
    item {
        Appear(1) {
            Panel("Flash single image", "Write a .img file to a partition (boot, recovery, vbmeta ...).") {
                OutlinedTextField(
                    value = Ui.partition, onValueChange = { Ui.partition = it },
                    label = { Text("Partition") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = a.pickImage, enabled = Ui.connected && Ui.transport == "fastboot" && !Ui.busy,
                    modifier = Modifier.fillMaxWidth().height(46.dp), shape = RoundedCornerShape(23.dp)
                ) { Text("Choose file and flash") }
            }
        }
    }
    item { Appear(2) { LogCard(maxLines = 30) } }
}

@Composable
private fun ModeButton(label: String, mode: String, color: Color, modifier: Modifier) {
    val available = Ui.scriptFor(mode) != null
    val selected = Ui.flashMode == mode && available
    val bg by animateColorAsState(if (selected) color.copy(alpha = 0.2f) else CardHi, label = "modeBg")
    Box(
        modifier.height(54.dp).alpha(if (available) 1f else 0.35f)
            .clip(RoundedCornerShape(14.dp)).background(bg)
            .border(1.dp, if (selected) color else Color(0xFF2A3B4F), RoundedCornerShape(14.dp))
            .clickable(enabled = available) { Ui.flashMode = mode }
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2,
            color = if (selected) color else TextMain, textAlign = TextAlign.Center
        )
    }
}

// ---------------------------------------------------------------------------
// Extract archives
// ---------------------------------------------------------------------------

internal fun LazyListScope.extractScreenItems(a: Actions) {
    item {
        Appear(0) {
            ScreenHeader("Extract Archives", "zip (also password protected), 7z, rar, tgz and tar.gz. Pick files from the result and save or flash them.")
        }
    }
    item {
        Appear(1) {
            Panel("Archive", "RAR5 and payload.bin are not supported. Needs free storage about the size of the archive plus its content.") {
                OutlinedTextField(
                    value = Ui.archivePassword, onValueChange = { Ui.archivePassword = it },
                    label = { Text("Password (only if the archive has one)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = a.pickArchive, enabled = !Ui.busy,
                    modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
                ) { Text("Choose archive") }
                Text(Ui.extractState, fontSize = 12.sp, color = if (Ui.extractState.startsWith("Failed")) Danger else TextDim)
                if (Ui.isActive("extract")) GlowBar(Ui.progress, Ui.taskName)
            }
        }
    }
    item {
        Appear(2) {
            var filter by remember { mutableStateOf("") }
            val root = Ui.extractRoot
            val shown = Ui.extractFiles.filter { filter.isBlank() || it.name.contains(filter, true) }.take(200)
            Panel(
                "Extracted files",
                if (Ui.extractFiles.isEmpty()) "Nothing extracted yet." else "${Ui.extractFiles.size} files, ${Ui.selected.size} selected"
            ) {
                if (Ui.extractFiles.isNotEmpty()) {
                    OutlinedTextField(
                        value = filter, onValueChange = { filter = it }, singleLine = true,
                        label = { Text("Search (example: .img)") }, modifier = Modifier.fillMaxWidth()
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = { filter = ".img" }, label = { Text("Only .img") })
                        AssistChip(onClick = { filter = "" }, label = { Text("All files") })
                        AssistChip(onClick = { Ui.selected = Ui.selected + shown.map { it.absolutePath } }, label = { Text("Select shown") })
                        AssistChip(onClick = { Ui.selected = emptySet() }, label = { Text("Clear selection") })
                    }
                }
                shown.forEach { f ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = f.absolutePath in Ui.selected,
                            onCheckedChange = { on ->
                                Ui.selected = if (on) Ui.selected + f.absolutePath else Ui.selected - f.absolutePath
                            }
                        )
                        Column(Modifier.weight(1f)) {
                            Text(if (root != null) f.relativeTo(root).path else f.name, fontSize = 13.sp, maxLines = 1)
                            Text(mb(f.length()), fontSize = 11.sp, color = TextDim)
                        }
                        if (f.name.endsWith(".img", true)) {
                            TextButton(onClick = { a.flashExtracted(f) }, enabled = Ui.connected && Ui.transport == "fastboot" && !Ui.busy) {
                                Text("Flash", color = Accent)
                            }
                        }
                    }
                }
                if (Ui.extractFiles.size > shown.size) {
                    Text("Showing ${shown.size} of ${Ui.extractFiles.size}. Use search to narrow the list.", fontSize = 11.sp, color = TextDim)
                }
                if (Ui.extractFiles.isNotEmpty()) {
                    Button(
                        onClick = a.saveSelected, enabled = Ui.selected.isNotEmpty() && !Ui.busy,
                        modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
                    ) { Text("Save selected (${Ui.selected.size}) to a folder") }
                    OutlinedButton(onClick = a.deleteExtracted, enabled = !Ui.busy) { Text("Delete extracted files", color = Danger) }
                }
            }
        }
    }
    item { Appear(3) { LogCard(maxLines = 20) } }
}

// ---------------------------------------------------------------------------
// Unlock
// ---------------------------------------------------------------------------

internal fun LazyListScope.unlockItems(a: Actions) {
    item {
        Appear(0) {
            Column {
                ScreenHeader("Bootloader Unlock", "Official Xiaomi unlock in 3 steps.")
                Text(
                    if (Ui.connected) "Target: ${Ui.deviceName}" else "USB target disconnected. Connect the phone in fastboot mode.",
                    fontSize = 12.sp, color = if (Ui.connected) Green else Danger
                )
            }
        }
    }
    item {
        Appear(1) {
            StepCard(1, "Xiaomi account",
                if (Ui.userId != null) "Logged in. Account ID: ${Ui.userId}"
                else "Opens Xiaomi's own login page in your browser, then come back here.",
                body = {
                    if (Ui.userId == null) {
                        Button(
                            onClick = a.login, enabled = !Ui.busy,
                            modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
                        ) { Text("Login with Xiaomi account") }
                    } else {
                        OutlinedButton(onClick = a.logout, enabled = !Ui.busy) { Text("Log out") }
                        Text("Server region", fontSize = 12.sp, color = TextDim)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MiServer.DOMAINS.keys.forEach { z ->
                                FilterChip(selected = Ui.zone == z, onClick = { Ui.zone = z }, label = { Text(z) })
                            }
                        }
                    }
                })
        }
    }
    item {
        Appear(2) {
            StepCard(2, "Unlock",
                "Needs fastboot mode, OTG connection, the phone's Mi account and Xiaomi's unlock permission.",
                body = {
                    Button(
                        onClick = a.unlock,
                        enabled = Ui.connected && Ui.transport == "fastboot" && Ui.userId != null && !Ui.busy,
                        modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Warn, contentColor = Color(0xFF3A2A00))
                    ) { Text("Unlock bootloader", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                })
        }
    }
    item { Appear(3) { LogCard(maxLines = 20) } }
}

// ---------------------------------------------------------------------------
// Logs
// ---------------------------------------------------------------------------

internal fun LazyListScope.logsItems() {
    item { Appear(0) { ScreenHeader("Operation Logs", "Everything the app did, newest at the bottom.") } }
    item { Appear(1) { LogCard(maxLines = 400) } }
}
