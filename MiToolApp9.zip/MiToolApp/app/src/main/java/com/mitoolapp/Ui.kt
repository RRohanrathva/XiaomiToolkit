package com.mitoolapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** Shared handle to the connected fastboot device (set by MainActivity). */
object Dev {
    @Volatile var fb: Fastboot? = null
    @Volatile var adb: Adb? = null
}

object Ui {
    val logs = mutableStateListOf<String>()

    // navigation
    var screen by mutableStateOf("home")
    // screens: home, logs, stockxiaomi, aosp, downloads, stockflash, image, terminal, extract, unlock

    // running task
    var busy by mutableStateOf(false)
    var progress by mutableFloatStateOf(-1f)
    var taskName by mutableStateOf("")
    var activeSection by mutableStateOf<String?>(null)
    var downloading by mutableStateOf(false)
    var downloadPct by mutableFloatStateOf(-1f)

    // device
    var connected by mutableStateOf(false)
    var transport by mutableStateOf("")   // "fastboot" | "adb" | ""
    var product by mutableStateOf("")
    var deviceName by mutableStateOf("No device")
    var mode by mutableStateOf("")
    var battery by mutableStateOf("")
    var info by mutableStateOf<Map<String, String>>(emptyMap())

    // flash
    var partition by mutableStateOf("boot")
    var romName by mutableStateOf<String?>(null)
    var romState by mutableStateOf("Not selected")
    var romOk by mutableStateOf(false)
    var romInfo by mutableStateOf<Map<String, String>>(emptyMap())
    var romScripts by mutableStateOf<List<String>>(emptyList())
    var flashMode by mutableStateOf("clean")
    var wipeMeta by mutableStateOf(false)
    var wipeData by mutableStateOf(false)

    // extract
    var extractFiles by mutableStateOf<List<File>>(emptyList())
    var extractRoot by mutableStateOf<File?>(null)
    var extractState by mutableStateOf("Nothing selected")
    var selected by mutableStateOf<Set<String>>(emptySet())
    var archivePassword by mutableStateOf("")

    // terminal
    val term = mutableStateListOf<String>()
    var sideloadName by mutableStateOf<String?>(null)
    var cmdTab by mutableIntStateOf(0)   // 0 ADB Info, 1 Fastboot Info, 2 Device Actions, 3 Manual Command

    fun termPrint(s: String) {
        s.split('\n').forEach { term.add(it) }
        while (term.size > 1500) term.removeAt(0)
    }

    // AOSP ADB sideload
    val aospParts = mutableStateMapOf("boot" to true, "init_boot" to true, "vendor_boot" to true, "dtbo" to true, "recovery" to true)
    val aospState = mutableStateMapOf<String, String>()   // pending | running | ok | fail | skipped
    var aospZipName by mutableStateOf<String?>(null)
    var aospStage by mutableIntStateOf(0)                 // 0 idle, 1..4 = stages
    var aospFail by mutableStateOf(false)
    var aospDone by mutableStateOf(false)
    var aospMsg by mutableStateOf("")
    @Volatile var aospCancel = false

    // Hybrid flasher (original BAT/CMD of a modified ROM)
    class HybridScript(
        val path: String, val name: String, val label: String, val steps: Int,
        val issues: List<String>, val product: String?, val wipes: Boolean, val locks: Int, val prompts: Boolean
    )
    var hybridZipName by mutableStateOf<String?>(null)
    var hybridState by mutableStateOf("Idle")   // Idle | Extracting... | Ready | Running | Done | Failed | Stopped
    var hybridScripts by mutableStateOf<List<HybridScript>>(emptyList())
    var hybridSel by mutableIntStateOf(0)
    var hybridPrompt by mutableStateOf<String?>(null)
    var hybridDialog by mutableStateOf(false)
    var hybridTyped by mutableStateOf(false)
    val hybridLog = mutableStateListOf<String>()
    @Volatile var hybridCancel = false

    fun hlog(s: String) {
        hybridLog.add(s)
        while (hybridLog.size > 1500) hybridLog.removeAt(0)
        log(s)
    }

    // Bloatware remover
    var bloatPkgs by mutableStateOf<List<Bloat.Pkg>>(emptyList())
    var bloatScanned by mutableStateOf(false)
    var bloatSel by mutableStateOf<Set<String>>(emptySet())
    var bloatQuery by mutableStateOf("")
    var bloatCat by mutableStateOf(Bloat.CAT_ALL)
    var bloatManual by mutableStateOf("")
    var bloatMsg by mutableStateOf("")
    var bloatHistory by mutableStateOf<List<Bloat.Hist>>(emptyList())

    // unlock
    var confirm by mutableStateOf<Confirm?>(null)
    var userId by mutableStateOf<String?>(null)
    var zone by mutableStateOf<String?>(null)

    class Confirm(
        val title: String,
        val text: String,
        val cancel: (() -> Unit)? = null,
        val action: () -> Unit
    )

    fun log(s: String) {
        logs.add(s)
        while (logs.size > 400) logs.removeAt(0)
    }

    /** Is the section with this key currently doing work? (used for glow) */
    fun isActive(key: String?): Boolean = when (key) {
        null -> false
        "download" -> downloading
        else -> busy && activeSection == key
    }

    /** Script of the ROM that matches a flashing mode: clean, save or lock. */
    fun scriptFor(m: String): String? = romScripts.firstOrNull {
        when (m) {
            "lock" -> it.contains("lock")
            "save" -> it.contains("except_storage") && !it.contains("lock")
            else -> !it.contains("lock") && !it.contains("except_storage")
        }
    }
}

class Actions(
    val connect: () -> Unit,
    val reboot: (String) -> Unit,
    val login: () -> Unit,
    val logout: () -> Unit,
    val unlock: () -> Unit,
    val pickImage: () -> Unit,
    val pickRom: () -> Unit,
    val flashNow: () -> Unit,
    val pickArchive: () -> Unit,
    val runTerm: (String) -> Unit,
    val pickSideload: () -> Unit,
    val bloatScan: () -> Unit,
    val bloatApply: (String, List<String>) -> Unit,
    val bloatPreview: (String) -> Unit,
    val bloatLoadHistory: () -> Unit,
    val bloatRestore: (List<Bloat.Hist>) -> Unit,
    val pickHybridZip: () -> Unit,
    val startHybrid: () -> Unit,
    val stopHybrid: () -> Unit,
    val hybridReply: (String) -> Unit,
    val hybridGo: () -> Unit,
    val runBatch: (List<String>) -> Unit,
    val pickAospZip: () -> Unit,
    val startAosp: () -> Unit,
    val cancelAosp: () -> Unit,
    val flashExtracted: (File) -> Unit,
    val deleteExtracted: () -> Unit,
    val saveSelected: () -> Unit
)
