package com.mitoolapp

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Known removable / disable-able apps (community debloat knowledge) and protected core packages. */
object Bloat {

    class Pkg(val id: String, val disabled: Boolean)
    class Hist(val serial: String, val pkg: String, val action: String, val time: Long)
    class Known(val name: String, val cat: String, val safe: Boolean)

    const val CAT_ALL = "All categories"
    val categories = listOf(CAT_ALL, "Xiaomi", "Google", "Partner", "Other")

    private fun k(name: String, cat: String, safe: Boolean = true) = Known(name, cat, safe)

    val known: Map<String, Known> = mapOf(
        // Xiaomi / MIUI / HyperOS
        "com.miui.analytics" to k("Analytics", "Xiaomi"),
        "com.miui.msa.global" to k("MSA (system ads)", "Xiaomi"),
        "com.miui.systemAdSolution" to k("System ads", "Xiaomi"),
        "com.xiaomi.mipicks" to k("GetApps", "Xiaomi"),
        "com.mi.globalbrowser" to k("Mi Browser", "Xiaomi"),
        "com.android.browser" to k("Browser", "Xiaomi"),
        "com.miui.videoplayer" to k("Mi Video", "Xiaomi"),
        "com.miui.player" to k("Mi Music", "Xiaomi"),
        "com.miui.bugreport" to k("Bug report", "Xiaomi"),
        "com.miui.yellowpage" to k("Yellow pages", "Xiaomi"),
        "com.xiaomi.glgm" to k("Games", "Xiaomi"),
        "com.miui.hybrid" to k("Quick apps", "Xiaomi"),
        "com.miui.hybrid.accessory" to k("Quick apps service", "Xiaomi"),
        "com.miui.fm" to k("FM Radio", "Xiaomi"),
        "com.miui.android.fashiongallery" to k("Wallpaper carousel", "Xiaomi"),
        "com.xiaomi.midrop" to k("ShareMe", "Xiaomi"),
        "com.miui.miservice" to k("Services & feedback", "Xiaomi"),
        "com.miui.huanji" to k("Mi Mover", "Xiaomi"),
        "com.miui.virtualsim" to k("Virtual SIM", "Xiaomi"),
        "com.miui.cleaner" to k("Cleaner", "Xiaomi", false),
        "com.miui.notes" to k("Notes", "Xiaomi", false),
        "com.miui.weather2" to k("Weather", "Xiaomi", false),
        "com.miui.compass" to k("Compass", "Xiaomi", false),
        "com.xiaomi.scanner" to k("Scanner", "Xiaomi", false),
        "com.miui.gallery" to k("Gallery", "Xiaomi", false),
        "com.miui.cloudservice" to k("Mi Cloud", "Xiaomi", false),
        "com.miui.cloudbackup" to k("Cloud backup", "Xiaomi", false),
        "com.miui.mishare.connectivity" to k("Mi Share", "Xiaomi", false),
        "com.xiaomi.payment" to k("Mi Payment", "Xiaomi", false),
        "com.xiaomi.joyose" to k("Joyose", "Xiaomi", false),
        "com.miui.personalassistant" to k("App vault", "Xiaomi", false),
        "com.miui.touchassistant" to k("Quick ball", "Xiaomi", false),
        // Google
        "com.google.android.youtube" to k("YouTube", "Google"),
        "com.google.android.apps.youtube.music" to k("YouTube Music", "Google"),
        "com.google.android.videos" to k("Google TV", "Google"),
        "com.google.android.music" to k("Play Music", "Google"),
        "com.google.android.apps.tachyon" to k("Google Meet", "Google"),
        "com.google.android.apps.docs" to k("Google Drive", "Google"),
        "com.google.android.apps.photos" to k("Google Photos", "Google"),
        "com.google.android.gm" to k("Gmail", "Google"),
        "com.google.android.apps.maps" to k("Google Maps", "Google"),
        "com.google.android.apps.podcasts" to k("Podcasts", "Google"),
        "com.google.android.apps.magazines" to k("Google News", "Google"),
        "com.google.android.apps.subscriptions.red" to k("Google One", "Google"),
        "com.google.android.keep" to k("Google Keep", "Google"),
        "com.google.android.apps.googleassistant" to k("Assistant", "Google", false),
        "com.google.android.googlequicksearchbox" to k("Google app", "Google", false),
        "com.google.android.calendar" to k("Calendar", "Google", false),
        // Partner apps
        "com.facebook.katana" to k("Facebook", "Partner"),
        "com.facebook.system" to k("Facebook system", "Partner"),
        "com.facebook.appmanager" to k("Facebook app manager", "Partner"),
        "com.facebook.services" to k("Facebook services", "Partner"),
        "com.netflix.mediaclient" to k("Netflix", "Partner"),
        "com.netflix.partner.activation" to k("Netflix activation", "Partner"),
        "com.linkedin.android" to k("LinkedIn", "Partner"),
        "com.amazon.mShop.android.shopping" to k("Amazon Shopping", "Partner"),
        "com.spotify.music" to k("Spotify", "Partner"),
        "com.instagram.android" to k("Instagram", "Partner"),
        "com.zhiliaoapp.musically" to k("TikTok", "Partner")
    )

    private val protectedExact = setOf(
        "android", "com.android.systemui", "com.android.settings", "com.android.phone", "com.android.shell",
        "com.android.packageinstaller", "com.google.android.packageinstaller", "com.android.vending",
        "com.miui.home", "com.mi.android.globallauncher", "com.miui.securitycenter", "com.miui.securitycore",
        "com.xiaomi.account", "com.xiaomi.xmsf", "com.miui.core", "com.miui.system", "com.miui.rom",
        "com.miui.powerkeeper", "com.miui.face", "com.android.updater", "com.android.mms", "com.android.contacts",
        "com.android.incallui", "com.android.dialer", "com.google.android.dialer", "com.google.android.contacts",
        "com.android.camera", "com.android.keychain", "com.android.certinstaller", "com.android.bluetooth",
        "com.android.nfc", "com.android.networkstack", "com.android.permissioncontroller",
        "com.google.android.permissioncontroller", "com.google.android.gms", "com.google.android.gsf",
        "com.android.webview", "com.google.android.webview", "com.android.captiveportallogin",
        "com.android.cellbroadcastreceiver", "com.android.server.telecom", "com.android.inputmethod.latin",
        "com.google.android.inputmethod.latin", "com.android.launcher3", "com.android.location.fused"
    )
    private val protectedPrefix = listOf(
        "com.android.providers.", "com.qualcomm.", "com.qti.", "com.mediatek.", "org.codeaurora.", "miui.",
        "com.fingerprints.", "com.android.internal.", "com.android.cts.", "com.google.android.ext.",
        "com.android.networkstack.", "com.android.systemui."
    )

    fun isProtected(id: String): Boolean = id in protectedExact || protectedPrefix.any { id.startsWith(it) }

    fun category(id: String): String = known[id]?.cat ?: when {
        id.startsWith("com.miui.") || id.startsWith("com.xiaomi.") || id.startsWith("com.mi.") -> "Xiaomi"
        id.startsWith("com.google.") -> "Google"
        else -> "Other"
    }

    fun isCandidate(id: String) = !isProtected(id) && known.containsKey(id)
    fun isSafe(id: String) = !isProtected(id) && known[id]?.safe == true

    private val validId = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")
    fun validId(id: String) = validId.matches(id)

    /**
     * Manual input: a package id, or one of the allowed pm commands. Arbitrary shell is never executed.
     * Returns the package id, or null if the text is not an allowed form.
     */
    fun parseManual(text: String): String? {
        val t = text.trim().removePrefix("adb").trim().removePrefix("shell").trim()
        if (t.isEmpty()) return null
        if (validId(t)) return t
        val toks = t.split(Regex("\\s+"))
        if (toks[0] != "pm") return null
        val verb = toks.getOrNull(1) ?: return null
        if (verb != "uninstall" && verb != "disable-user" && verb != "enable" && verb != "install-existing") return null
        val allowedFlags = setOf("-k", "--user", "0", "--user=0")
        val rest = toks.drop(2)
        val pkg = rest.lastOrNull() ?: return null
        if (!validId(pkg)) return null
        if (rest.dropLast(1).any { it !in allowedFlags }) return null
        return pkg
    }

    // ----- history (restore) -----

    fun loadHistory(p: SharedPreferences): List<Hist> = try {
        val a = JSONArray(p.getString("bloat_history", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Hist(o.getString("serial"), o.getString("pkg"), o.getString("action"), o.getLong("time"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveHistory(p: SharedPreferences, list: List<Hist>) {
        val a = JSONArray()
        list.takeLast(500).forEach {
            a.put(JSONObject().put("serial", it.serial).put("pkg", it.pkg).put("action", it.action).put("time", it.time))
        }
        p.edit().putString("bloat_history", a.toString()).apply()
    }
}
