package com.mitoolapp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val PHRASE = "RUN ORIGINAL HYBRID BAT"

internal fun LazyListScope.hybridItems(a: Actions) {
    item {
        Appear(0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Hybrid Flasher", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Modified ROM with its own BAT/CMD installer", fontSize = 12.sp, color = TextDim)
                }
                val c = when (Ui.hybridState) {
                    "Running", "Extracting..." -> Warn
                    "Done", "Ready" -> Green
                    "Failed", "Stopped" -> Danger
                    else -> TextDim
                }
                Pill(Ui.hybridState.uppercase(), c, if (Ui.isActive("hybrid")) 0.8f else 0f)
            }
        }
    }
    item {
        Appear(1) {
            Panel(
                "Custom ROM ZIP",
                "Browse a custom ROM zip. MiTool extracts it and detects the original BAT/CMD installer. Flashing starts only after you press Flash and confirm twice."
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        Ui.hybridZipName ?: "No ROM selected",
                        fontSize = 12.sp, fontFamily = FontFamily.Monospace, maxLines = 2,
                        modifier = Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(CardHi).padding(10.dp)
                    )
                    OutlinedButton(onClick = a.pickHybridZip, enabled = !Ui.busy, border = BorderStroke(1.dp, Accent)) {
                        Text("Browse ROM ZIP", color = Accent)
                    }
                }
                if (Ui.isActive("hybrid") && Ui.hybridState == "Extracting...") GlowBar(Ui.progress, "Extracting ROM")
            }
        }
    }
    if (Ui.hybridScripts.isNotEmpty()) {
        item {
            Appear(2) {
                Panel("Detected original BAT / installation method", "Select the method. Lines MiTool cannot run block that script.") {
                    Ui.hybridScripts.forEachIndexed { i, s ->
                        val sel = Ui.hybridSel == i
                        val bad = s.issues.isNotEmpty()
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .background(if (sel) Accent.copy(alpha = 0.12f) else CardHi)
                                .border(1.dp, if (sel) Accent else Color(0xFF2A3B4F), RoundedCornerShape(12.dp))
                                .clickable(enabled = !Ui.busy) { Ui.hybridSel = i }.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = sel, onClick = { if (!Ui.busy) Ui.hybridSel = i })
                            Column(Modifier.weight(1f)) {
                                Text("${s.name} - ${s.label}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${s.steps} fastboot steps" + (if (s.prompts) " - interactive" else "") +
                                        (if (s.wipes) " - erases data" else "") + (if (s.locks > 0) " - lock line skipped" else ""),
                                    fontSize = 11.sp, color = TextDim
                                )
                                if (bad) Text("Cannot run: " + s.issues.joinToString("; "), fontSize = 11.sp, color = Danger)
                            }
                        }
                    }
                    val s = Ui.hybridScripts.getOrNull(Ui.hybridSel)
                    if (s != null) {
                        Text(
                            "Detected: ${s.name} - ${s.label}" + (if (s.prompts) " - Interactive BAT" else "") +
                                (if (s.product != null) " - product ${s.product}" else ""),
                            fontSize = 11.sp, color = TextDim
                        )
                    }
                    val s2 = Ui.hybridScripts.getOrNull(Ui.hybridSel)
                    val ready = s2 != null && s2.issues.isEmpty() && Ui.transport == "fastboot" && !Ui.busy &&
                        (Ui.hybridState == "Ready" || Ui.hybridState == "Done" || Ui.hybridState == "Failed" || Ui.hybridState == "Stopped")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = a.startHybrid, enabled = ready,
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF00382B))
                        ) { Text("Flash Selected BAT", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        if (Ui.isActive("hybrid") && Ui.hybridState == "Running") {
                            OutlinedButton(onClick = a.stopHybrid, border = BorderStroke(1.dp, Danger), shape = RoundedCornerShape(20.dp)) {
                                Text("Stop Flash", color = Danger, fontSize = 12.sp)
                            }
                        }
                        if (Ui.hybridPrompt != null && !Ui.hybridDialog) {
                            OutlinedButton(onClick = { Ui.hybridDialog = true }, shape = RoundedCornerShape(20.dp)) {
                                Text("Reply to BAT", fontSize = 12.sp)
                            }
                        }
                    }
                    Text(
                        when {
                            Ui.transport != "fastboot" -> "Connect the phone in fastboot mode to flash."
                            else -> "Connected: ${Ui.deviceName} (fastboot)"
                        },
                        fontSize = 11.sp, color = if (Ui.transport == "fastboot") Green else Danger
                    )
                    if (Ui.isActive("hybrid") && Ui.hybridState == "Running") GlowBar(Ui.progress, "Running original BAT", Accent)
                }
            }
        }
    }
    item {
        Appear(3) {
            val clipboard = LocalClipboardManager.current
            Panel("Universal Hybrid Flash Log", null) {
                val sc = rememberScrollState()
                LaunchedEffect(Ui.hybridLog.size) { sc.scrollTo(sc.maxValue) }
                Text(
                    if (Ui.hybridLog.isEmpty()) "Nothing yet." else Ui.hybridLog.takeLast(300).joinToString("\n"),
                    fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextMain,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp).clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF05080D)).verticalScroll(sc).padding(10.dp)
                )
                Row {
                    TextButton(onClick = { clipboard.setText(AnnotatedString(Ui.hybridLog.joinToString("\n"))) }) { Text("Copy") }
                    TextButton(onClick = { Ui.hybridLog.clear() }) { Text("Clear") }
                }
            }
        }
    }
}

/** Prompt dialog ("Original BAT needs a reply") and the typed second confirmation. */
@Composable
internal fun HybridDialogs(a: Actions) {
    val prompt = Ui.hybridPrompt
    if (prompt != null && Ui.hybridDialog) {
        var reply by remember(prompt) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { Ui.hybridDialog = false },
            containerColor = CardBg,
            title = { Text("Original BAT needs a reply") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        prompt, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CardHi).padding(10.dp)
                    )
                    OutlinedTextField(
                        value = reply, onValueChange = { reply = it }, singleLine = true,
                        label = { Text("Your response") }, modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { a.hybridReply("Y") }) { Text("Yes") }
                        OutlinedButton(onClick = { a.hybridReply("N") }) { Text("No") }
                    }
                    Text(
                        "Your reply goes directly to the original ROM script. Unsupported prompts are not auto-answered.",
                        fontSize = 11.sp, color = TextDim
                    )
                }
            },
            confirmButton = { TextButton(onClick = { a.hybridReply(reply) }) { Text("Send Reply") } },
            dismissButton = { TextButton(onClick = { Ui.hybridDialog = false }) { Text("Close") } }
        )
    }
    if (Ui.hybridTyped) {
        var typed by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { Ui.hybridTyped = false },
            containerColor = CardBg,
            title = { Text("Final confirmation", color = Danger) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("This runs the original ROM installer on your phone. Type exactly:", fontSize = 12.sp)
                    Text(PHRASE, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Warn)
                    OutlinedTextField(value = typed, onValueChange = { typed = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = { Ui.hybridTyped = false; a.hybridGo() }, enabled = typed == PHRASE) { Text("Start", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { Ui.hybridTyped = false }) { Text("Cancel") } }
        )
    }
}
