package com.mitoolapp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun adbReady() = Ui.transport == "adb" && Ui.mode == "ADB"

internal fun LazyListScope.bloatItems(a: Actions) {
    item {
        Appear(0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ADB APP MANAGEMENT", fontSize = 10.sp, color = Accent, fontWeight = FontWeight.Bold)
                    Text("Bloatware Remover", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = a.bloatScan, enabled = adbReady() && !Ui.busy,
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E7BE0))
                ) { Text("Scan Apps", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            }
        }
    }
    if (!adbReady()) {
        item {
            Text("Connect an authorized phone with USB debugging (ADB) and tap Scan Apps.", fontSize = 12.sp, color = Warn)
        }
    }

    // package list panel: search + category + bulk actions
    item {
        Appear(1) {
            Panel(
                "Installed System Packages",
                if (Ui.bloatScanned) "${Ui.bloatPkgs.size} packages, ${Ui.bloatSel.size} selected" else "No packages scanned"
            ) {
                OutlinedTextField(
                    value = Ui.bloatQuery, onValueChange = { Ui.bloatQuery = it }, singleLine = true,
                    label = { Text("Search app name or package ID") }, modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Bloat.categories.forEach { c ->
                        FilterChip(selected = Ui.bloatCat == c, onClick = { Ui.bloatCat = c }, label = { Text(c, fontSize = 12.sp) })
                    }
                }
                val candidates = Ui.bloatPkgs.filter { Bloat.isCandidate(it.id) }
                val en = adbReady() && !Ui.busy && Ui.bloatScanned
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { Ui.bloatSel = candidates.map { it.id }.toSet() }, enabled = Ui.bloatScanned) {
                        Text("Select All Candidates", fontSize = 11.sp)
                    }
                    OutlinedButton(onClick = { Ui.bloatSel = emptySet() }, enabled = Ui.bloatSel.isNotEmpty()) { Text("Clear", fontSize = 11.sp) }
                    OutlinedButton(onClick = { a.bloatApply("disable", Ui.bloatSel.toList()) }, enabled = en && Ui.bloatSel.isNotEmpty()) {
                        Text("Disable Selected", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { a.bloatApply("remove", Ui.bloatSel.filter { Bloat.isSafe(it) }) },
                        enabled = en && Ui.bloatSel.any { Bloat.isSafe(it) }, border = BorderStroke(1.dp, Danger)
                    ) { Text("Remove Selected Safe", fontSize = 11.sp, color = Danger) }
                    OutlinedButton(
                        onClick = { a.bloatApply("remove", candidates.filter { Bloat.isSafe(it.id) }.map { it.id }) },
                        enabled = en && candidates.any { Bloat.isSafe(it.id) }, border = BorderStroke(1.dp, Danger)
                    ) { Text("Remove All Safe", fontSize = 11.sp, color = Danger) }
                }
            }
        }
    }

    // list rows
    val q = Ui.bloatQuery.trim().lowercase()
    val shown = Ui.bloatPkgs.filter { p ->
        (Ui.bloatCat == Bloat.CAT_ALL || Bloat.category(p.id) == Ui.bloatCat) &&
            (q.isEmpty() || p.id.lowercase().contains(q) || (Bloat.known[p.id]?.name ?: "").lowercase().contains(q))
    }.sortedWith(compareByDescending<Bloat.Pkg> { Bloat.isCandidate(it.id) }.thenBy { it.id }).take(400)
    if (Ui.bloatPkgs.isEmpty()) {
        item {
            Text(
                if (Ui.busy && Ui.isActive("bloat")) "Scanning..." else "Connect an authorized phone and scan.",
                fontSize = 12.sp, color = TextDim,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardBg).padding(24.dp)
            )
        }
    } else {
        items(shown, key = { it.id }) { p ->
            val prot = Bloat.isProtected(p.id)
            val cand = Bloat.isCandidate(p.id)
            val k = Bloat.known[p.id]
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CardBg)
                    .border(1.dp, Color(0xFF1E2C3D), RoundedCornerShape(12.dp))
                    .alpha(if (prot) 0.55f else 1f).padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = p.id in Ui.bloatSel,
                    onCheckedChange = { on -> Ui.bloatSel = if (on) Ui.bloatSel + p.id else Ui.bloatSel - p.id },
                    enabled = cand && !Ui.busy
                )
                Column(Modifier.weight(1f).padding(vertical = 4.dp)) {
                    Text(k?.name ?: p.id.substringAfterLast('.'), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(p.id, fontSize = 10.sp, color = TextDim, fontFamily = FontFamily.Monospace, maxLines = 1)
                }
                val (tag, col) = when {
                    prot -> "PROTECTED" to Danger
                    p.disabled -> "DISABLED" to Warn
                    k?.safe == true -> "SAFE" to Green
                    k != null -> "CAUTION" to Warn
                    else -> "" to TextDim
                }
                if (tag.isNotEmpty()) Text(tag, fontSize = 9.sp, color = col, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 8.dp))
            }
        }
        if (Ui.bloatPkgs.size > shown.size && q.isEmpty() && Ui.bloatCat == Bloat.CAT_ALL) {
            item { Text("Showing the first ${shown.size}. Use search or a category to narrow the list.", fontSize = 11.sp, color = TextDim) }
        }
    }

    // manual package manager
    item {
        Appear(2) {
            Panel(
                "Manual Package Manager",
                "Enter a package ID or an allowed ADB package command (pm uninstall / disable-user / enable). Arbitrary shell commands are never executed."
            ) {
                OutlinedTextField(
                    value = Ui.bloatManual, onValueChange = { Ui.bloatManual = it }, singleLine = true,
                    label = { Text("com.example.app or adb shell pm uninstall --user 0 com.example.app") },
                    modifier = Modifier.fillMaxWidth()
                )
                val id = Bloat.parseManual(Ui.bloatManual)
                val en = adbReady() && !Ui.busy && id != null
                if (Ui.bloatManual.isNotBlank() && id == null) {
                    Text("Not an allowed package ID or command.", fontSize = 11.sp, color = Danger)
                } else if (id != null && Bloat.isProtected(id)) {
                    Text("Protected core package: cannot be disabled or removed here.", fontSize = 11.sp, color = Danger)
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { id?.let(a.bloatPreview) }, enabled = en) { Text("Preview", fontSize = 12.sp) }
                    OutlinedButton(
                        onClick = { id?.let { a.bloatApply("disable", listOf(it)) } },
                        enabled = en && id != null && !Bloat.isProtected(id)
                    ) { Text("Disable Package", fontSize = 12.sp) }
                    OutlinedButton(
                        onClick = { id?.let { a.bloatApply("remove", listOf(it)) } },
                        enabled = en && id != null && !Bloat.isProtected(id), border = BorderStroke(1.dp, Danger)
                    ) { Text("Remove Eligible Package", fontSize = 12.sp, color = Danger) }
                }
            }
        }
    }

    // restore
    item {
        Appear(3) {
            Panel(
                "Restore Apps",
                "Restore one or all apps this tool changed on the SAME connected device, where the original packages are still present."
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = a.bloatLoadHistory, enabled = adbReady() && !Ui.busy) { Text("Load History", fontSize = 12.sp) }
                    Button(
                        onClick = { a.bloatRestore(Ui.bloatHistory) },
                        enabled = adbReady() && !Ui.busy && Ui.bloatHistory.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E7BE0))
                    ) { Text("Restore All Eligible", fontSize = 12.sp) }
                }
                Ui.bloatHistory.take(60).forEach { h ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(Bloat.known[h.pkg]?.name ?: h.pkg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text("${h.action} - ${h.pkg}", fontSize = 10.sp, color = TextDim, maxLines = 1)
                        }
                        TextButton(onClick = { a.bloatRestore(listOf(h)) }, enabled = adbReady() && !Ui.busy) { Text("Restore", color = Accent) }
                    }
                }
            }
        }
    }

    if (Ui.bloatMsg.isNotEmpty()) {
        item {
            Text(
                Ui.bloatMsg, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF05080D)).padding(10.dp)
            )
        }
    }
    item { LogCard(maxLines = 25) }
    item {
        Text(
            "Protected core packages cannot be disabled or removed here. A \"safe\" candidate can still affect device features. " +
                "Review every selection and save a backup.",
            fontSize = 12.sp, color = Danger,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Danger.copy(alpha = 0.12f))
                .border(1.dp, Danger.copy(alpha = 0.5f), RoundedCornerShape(12.dp)).padding(12.dp)
        )
    }
}
