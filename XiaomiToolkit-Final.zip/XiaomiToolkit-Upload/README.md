# XiaomiToolkit

🔧 Complete Android toolkit for Xiaomi devices with Material 3 Expressive UI

## 📦 Setup Instructions

### Method 1: Upload ZIP File Directly

1. Create a new repository on GitHub
2. Upload the `XiaomiToolkit.zip` file directly
3. Create `.github/workflows/build-from-zip.yml` with the workflow content
4. Push/commit changes
5. GitHub Actions will automatically:
   - Extract the ZIP file
   - Build the APK
   - Make it available in Artifacts

### Method 2: Extract and Upload Files

1. Extract `XiaomiToolkit.zip` 
2. Upload all files to your GitHub repository
3. GitHub Actions will automatically build APK

## 🚀 Download APK

After the build completes (5-10 minutes):
1. Go to **Actions** tab
2. Click on the latest workflow run
3. Download APK from **Artifacts** section

## ✨ Features

- 🔓 Bootloader Unlock UI
- ⚡ Fastboot Flash Interface
- 📱 Device Information Display
- ⚙️ Settings Configuration
- 🎨 Material 3 Expressive Design
- ✨ Beautiful Animations

## 📱 Screenshots

Beautiful Material 3 UI with smooth animations throughout the app.

## 🛠️ Tech Stack

- **Language:** Kotlin
- **UI:** Jetpack Compose
- **Design:** Material 3
- **Architecture:** MVVM

## 📄 License

Apache License 2.0

---

Made with ❤️ using Jetpack Compose & Material 3
