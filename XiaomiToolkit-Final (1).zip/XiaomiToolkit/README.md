# Xiaomi Toolkit

Kotlin + Jetpack Compose (Material 3) UI for Xiaomi bootloader unlock and fastboot ROM flashing.

> **Status: demo / UI prototype.** Login, device detection, unlock, ROM selection, flashing and
> device info are simulated. No real fastboot or Mi unlock commands are sent yet.

## Build the APK on GitHub (no extraction needed)
1. Create a repo, upload `XiaomiToolkit.zip` as-is (or the extracted files).
2. Add `.github/workflows/build-apk.yml` (code is in this repo's workflow file).
3. Actions tab -> "Build APK" -> download **XiaomiToolkit-APK** artifact.

The release APK is signed with the debug key, so both APKs install directly.
