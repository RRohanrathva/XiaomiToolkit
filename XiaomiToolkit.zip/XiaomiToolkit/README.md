# Xiaomi Toolkit

<div align="center">
  <h1>🔧 Xiaomi Toolkit</h1>
  <p>Complete solution for Xiaomi devices - Bootloader unlock, Fastboot flash & more</p>
  
  <img src="https://img.shields.io/badge/Android-3DDC84?style=for-the-badge&logo=android&logoColor=white" />
  <img src="https://img.shields.io/badge/Kotlin-0095D5?&style=for-the-badge&logo=kotlin&logoColor=white" />
  <img src="https://img.shields.io/badge/Material%20Design%203-757575?style=for-the-badge&logo=material-design&logoColor=white" />
</div>

---

## ✨ Features

### 🔓 Bootloader Unlock
- **Easy Mi Account Login** - Secure authentication with your Xiaomi account
- **Automatic Device Detection** - Detects device in fastboot mode automatically  
- **One-Click Unlock** - Simple and fast bootloader unlocking process
- **Progress Tracking** - Real-time progress updates during unlock

### ⚡ Fastboot Flash
- **ROM Flashing** - Flash any compatible ROM via fastboot
- **Flexible Options** - Choose to wipe data, cache, or format data
- **Progress Monitoring** - Track flashing progress with detailed steps
- **Multi-Step Verification** - Ensures safe and reliable flashing

### 📱 Device Information
- **Hardware Details** - View processor, RAM, storage info
- **Software Info** - Check Android version, MIUI version
- **Bootloader Status** - Check if bootloader is locked or unlocked
- **Real-Time Updates** - Refresh device information anytime

### ⚙️ Settings
- **Theme Support** - Light/Dark theme with system default
- **Language Options** - Multi-language support
- **Customizable Paths** - Configure fastboot binary path
- **USB Settings** - Adjust timeout and connection settings

---

## 🎨 Design

Built with **Material 3 Expressive UI** featuring:
- 🌈 **Dynamic Color Theming** - Adapts to your device theme
- ✨ **Smooth Animations** - Fluid transitions and interactions
- 🎯 **Modern UI Components** - Cards, buttons with elevated design
- 📐 **Responsive Layout** - Works beautifully on all screen sizes

---

## 📸 Screenshots

> Beautiful Material 3 design with smooth animations throughout the app

---

## 🚀 Download

Download the latest APK from the [Releases](../../releases) page.

---

## 🛠️ Build Instructions

### Prerequisites
- Android Studio Hedgehog or newer
- JDK 17
- Android SDK 35

### Steps
1. Clone the repository:
```bash
git clone https://github.com/yourusername/XiaomiToolkit.git
cd XiaomiToolkit
```

2. Open the project in Android Studio

3. Build the project:
```bash
./gradlew build
```

4. Generate APK:
```bash
./gradlew assembleRelease
```

The APK will be located at: `app/build/outputs/apk/release/app-release.apk`

---

## 📋 Requirements

- **Android 7.0 (API 24)** or higher
- **USB Debugging** enabled on device
- **Unlocked OEM** (for some features)
- **Fastboot drivers** installed on PC (if using PC connection)

---

## ⚠️ Disclaimer

**Warning:** 
- Unlocking bootloader will **void your warranty**
- Unlocking bootloader **may erase all data** on your device
- Flashing ROM **may brick your device** if done incorrectly
- Always **backup your data** before proceeding
- Use this tool **at your own risk**

---

## 🙏 Credits

- **MiUnlockTool** - Reference implementation by [MiForge](https://github.com/MiForge/MiUnlockTool)
- **Material Design 3** - Google's design system
- **Jetpack Compose** - Modern UI toolkit for Android

---

## 📄 License

```
Copyright 2024 Xiaomi Toolkit

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

---

## 💬 Support

If you encounter any issues or have questions:
- Open an [Issue](../../issues)
- Check [Discussions](../../discussions)

---

<div align="center">
  <p>Made with ❤️ using Jetpack Compose & Material 3</p>
  <p>⭐ Star this repo if you find it useful!</p>
</div>
