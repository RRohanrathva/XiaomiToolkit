# XiaomiToolkit Project Structure

## 📁 Project Overview

```
XiaomiToolkit/
├── .github/
│   └── workflows/
│       ├── android.yml          # Main CI workflow
│       └── build-apk.yml        # APK build workflow
├── app/
│   ├── src/main/
│   │   ├── java/com/xiaomi/toolkit/
│   │   │   ├── MainActivity.kt
│   │   │   └── ui/
│   │   │       ├── navigation/
│   │   │       │   ├── AppNavigation.kt
│   │   │       │   └── Screen.kt
│   │   │       ├── screens/
│   │   │       │   ├── home/
│   │   │       │   │   └── HomeScreen.kt
│   │   │       │   ├── bootloader/
│   │   │       │   │   ├── BootloaderUnlockScreen.kt
│   │   │       │   │   └── BootloaderViewModel.kt
│   │   │       │   ├── fastboot/
│   │   │       │   │   ├── FastbootFlashScreen.kt
│   │   │       │   │   └── FastbootViewModel.kt
│   │   │       │   ├── device/
│   │   │       │   │   ├── DeviceInfoScreen.kt
│   │   │       │   │   └── DeviceInfoViewModel.kt
│   │   │       │   └── settings/
│   │   │       │       └── SettingsScreen.kt
│   │   │       └── theme/
│   │   │           ├── Color.kt
│   │   │           ├── Theme.kt
│   │   │           ├── Type.kt
│   │   │           └── Shape.kt
│   │   ├── res/
│   │   │   ├── values/
│   │   │   │   ├── strings.xml
│   │   │   │   ├── colors.xml
│   │   │   │   └── themes.xml
│   │   │   ├── xml/
│   │   │   │   ├── device_filter.xml
│   │   │   │   ├── file_paths.xml
│   │   │   │   ├── backup_rules.xml
│   │   │   │   └── data_extraction_rules.xml
│   │   │   └── mipmap-*/
│   │   │       └── ic_launcher*
│   │   └── AndroidManifest.xml
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── gradle/
│   └── wrapper/
│       ├── gradle-wrapper.jar
│       └── gradle-wrapper.properties
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradlew
├── .gitignore
└── README.md
```

## 🎯 Key Features Implemented

### 1. **Material 3 Expressive UI**
- Dynamic color theming
- Smooth animations using Compose animations
- Gradient cards with spring animations
- Modern rounded corners and elevation
- Smooth screen transitions

### 2. **Bootloader Unlock**
- Step-by-step wizard UI
- Mi Account login interface
- Device connection detection
- Progress tracking with animations
- Success/failure states with visual feedback

### 3. **Fastboot Flash**
- ROM file selection
- Flash options (wipe data, cache, format)
- Real-time progress tracking
- Step-by-step flashing process
- Beautiful progress cards

### 4. **Device Information**
- Hardware details display
- Bootloader status
- Real-time device connection status
- Organized info sections with icons

### 5. **Settings**
- Theme configuration
- Language settings
- Fastboot path configuration
- About section

## 🔧 Technical Stack

- **Language:** Kotlin
- **UI Framework:** Jetpack Compose
- **Architecture:** MVVM with StateFlow
- **Material Design:** Material 3 (Material You)
- **Navigation:** Navigation Compose
- **Minimum SDK:** 24 (Android 7.0)
- **Target SDK:** 35 (Android 15)

## 📱 Animations

All screens feature:
- ✨ Slide and fade transitions
- 🌊 Spring-based scale animations
- 📊 Linear progress with smooth updates
- 🎨 Color transitions
- 🔄 Expand/collapse animations

## 🚀 Building

### Via GitHub Actions:
1. Push to GitHub
2. GitHub Actions automatically builds APK
3. Download from Actions artifacts or Releases

### Local Build:
```bash
./gradlew assembleDebug   # Debug APK
./gradlew assembleRelease # Release APK
```

## 📦 Output

APK will be generated at:
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release.apk`

## 🎨 UI Highlights

1. **Home Screen:** 4 animated gradient cards with spring animations
2. **Bootloader Screen:** 3-step wizard with expandable cards
3. **Fastboot Screen:** File picker, options, and real-time progress
4. **Device Info:** Organized sections with status indicators
5. **Settings:** Clean list with navigation icons

---

Made with ❤️ using Jetpack Compose & Material 3 Expressive UI
