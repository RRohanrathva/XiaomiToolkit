# Add project specific ProGuard rules here.
-keep class com.xiaomi.toolkit.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
