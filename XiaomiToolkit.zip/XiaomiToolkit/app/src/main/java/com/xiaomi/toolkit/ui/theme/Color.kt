package com.xiaomi.toolkit.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val PrimaryLight = Color(0xFFFF6900)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFFFDCC5)
val OnPrimaryContainerLight = Color(0xFF311300)

val SecondaryLight = Color(0xFF765848)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFFDCC5)
val OnSecondaryContainerLight = Color(0xFF2B160A)

val TertiaryLight = Color(0xFF646032)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFEBE4AB)
val OnTertiaryContainerLight = Color(0xFF1E1C00)

val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF410002)

val BackgroundLight = Color(0xFFFFFBFF)
val OnBackgroundLight = Color(0xFF201A17)
val SurfaceLight = Color(0xFFFFFBFF)
val OnSurfaceLight = Color(0xFF201A17)
val SurfaceVariantLight = Color(0xFFF4DED4)
val OnSurfaceVariantLight = Color(0xFF52443C)
val OutlineLight = Color(0xFF84746A)

// Dark Theme Colors
val PrimaryDark = Color(0xFFFFB787)
val OnPrimaryDark = Color(0xFF522200)
val PrimaryContainerDark = Color(0xFF743300)
val OnPrimaryContainerDark = Color(0xFFFFDCC5)

val SecondaryDark = Color(0xFFE6BEAA)
val OnSecondaryDark = Color(0xFF432B1D)
val SecondaryContainerDark = Color(0xFF5C4132)
val OnSecondaryContainerDark = Color(0xFFFFDCC5)

val TertiaryDark = Color(0xFFCEC891)
val OnTertiaryDark = Color(0xFF343208)
val TertiaryContainerDark = Color(0xFF4B481D)
val OnTertiaryContainerDark = Color(0xFFEBE4AB)

val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)
val ErrorContainerDark = Color(0xFF93000A)
val OnErrorContainerDark = Color(0xFFFFDAD6)

val BackgroundDark = Color(0xFF201A17)
val OnBackgroundDark = Color(0xFFECE0DB)
val SurfaceDark = Color(0xFF201A17)
val OnSurfaceDark = Color(0xFFECE0DB)
val SurfaceVariantDark = Color(0xFF52443C)
val OnSurfaceVariantDark = Color(0xFFD7C2B8)
val OutlineDark = Color(0xFF9F8D83)
