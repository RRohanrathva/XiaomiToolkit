# MiToolApp (standalone)

Material 3 Android app, no Termux needed. Fastboot runs over USB OTG inside the app.

- Unlock Bootloader: Xiaomi account login (browser) + official unlock server flow
  (port of MiForge/MiUnlockTool, Apache-2.0 and MiForge/migate, MIT)
- Flash ROM: fastboot ROM .tgz (runs flash_all script) or a single .img
- Not included: Mi Assistant, Firmware Content Extractor

Build: GitHub -> Actions -> "Build APK" -> Run workflow -> artifact `MiTool-apk`.
