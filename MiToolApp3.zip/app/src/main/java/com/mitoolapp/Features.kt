package com.mitoolapp

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.webkit.URLUtil
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Shared handle to the connected fastboot device (set by MainActivity). */
object Dev {
    @Volatile var fb: Fastboot? = null
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fun openBrowser(ctx: Context, url: String) {
    ctx.startActivity(Intent(ctx, BrowserActivity::class.java).putExtra("url", url))
}

object Downloads {
    class Item(val id: Long, val title: String, val status: Int, val total: Long, val done: Long)

    /** Returns null on success, or an error message. */
    fun enqueue(
        ctx: Context, url: String, userAgent: String? = null, contentDisposition: String? = null,
        mime: String? = null, cookie: String? = null
    ): String? {
        val uri = try { Uri.parse(url.trim()) } catch (e: Exception) { return "Invalid link" }
        if (uri.scheme != "http" && uri.scheme != "https") return "Only http/https links are supported"
        return try {
            val name = URLUtil.guessFileName(url.trim(), contentDisposition, mime)
            val req = DownloadManager.Request(uri)
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "MiTool/$name")
            if (!cookie.isNullOrEmpty()) req.addRequestHeader("Cookie", cookie)
            if (!userAgent.isNullOrEmpty()) req.addRequestHeader("User-Agent", userAgent)
            (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            null
        } catch (e: Exception) {
            e.message ?: "Could not start the download"
        }
    }

    fun list(ctx: Context): List<Item> {
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val out = ArrayList<Item>()
        try {
            dm.query(DownloadManager.Query())?.use { c ->
                val iId = c.getColumnIndex(DownloadManager.COLUMN_ID)
                val iTitle = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
                val iStatus = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val iTotal = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val iDone = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                while (c.moveToNext()) {
                    out.add(Item(c.getLong(iId), c.getString(iTitle) ?: "download", c.getInt(iStatus), c.getLong(iTotal), c.getLong(iDone)))
                }
            }
        } catch (_: Exception) {
        }
        return out.sortedByDescending { it.id }
    }

    fun remove(ctx: Context, id: Long) {
        (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id)
    }

    fun statusText(s: Int) = when (s) {
        DownloadManager.STATUS_PENDING -> "Pending"
        DownloadManager.STATUS_RUNNING -> "Downloading"
        DownloadManager.STATUS_PAUSED -> "Paused"
        DownloadManager.STATUS_SUCCESSFUL -> "Done"
        DownloadManager.STATUS_FAILED -> "Failed"
        else -> "?"
    }
}

private fun mb(n: Long) = "%.1f MB".format(n / 1048576.0)

@Composable
internal fun Panel(title: String, subtitle: String? = null, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, Color(0xFF223246))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = TextDim)
            content()
        }
    }
}

@Composable
internal fun ScreenHeader(title: String, subtitle: String) {
    Column {
        TopBar()
        Spacer(Modifier.height(8.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, fontSize = 12.sp, color = TextDim)
    }
}

// ---------------------------------------------------------------------------
// Firmware Finder
// ---------------------------------------------------------------------------

internal fun LazyListScope.firmwareItems() {
    item {
        Appear(0) {
            ScreenHeader("Firmware Finder", "Find official Xiaomi fastboot (.tgz) and recovery (.zip) ROMs for your device.")
        }
    }
    item {
        Appear(1) {
            val ctx = LocalContext.current
            var code by remember { mutableStateOf(if (Ui.connected) Ui.status.lowercase() else "") }
            val clean = code.trim().lowercase().filter { it.isLetterOrDigit() || it == '_' }
            Panel("Device codename", "Example: onyx, marble, gauguin. Connect the phone to fill it automatically.") {
                OutlinedTextField(
                    value = code, onValueChange = { code = it }, singleLine = true,
                    label = { Text("Codename") }, modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { openBrowser(ctx, "https://xmfirmwareupdater.com/hyperos/$clean/") },
                    enabled = clean.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
                ) {
                    androidx.compose.material3.Icon(Icons.Filled.Search, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Search HyperOS ROMs")
                }
                OutlinedButton(
                    onClick = { openBrowser(ctx, "https://miuirom.org") },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Open miuirom.org") }
            }
        }
    }
    item {
        Appear(2) {
            Text(
                "The page opens inside MiTool. Tap a ROM's download link and it is saved in Downloads/MiTool " +
                    "(see Download Manager). Then use Fastboot Flash > Browse TGZ. Always pick the exact region " +
                    "and codename of your phone.",
                fontSize = 12.sp, color = TextDim
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Official AOSP ROMs
// ---------------------------------------------------------------------------

private class AospRom(val name: String, val note: String, val url: String)

private val aospRoms = listOf(
    AospRom("LineageOS", "Official builds by device", "https://download.lineageos.org/devices"),
    AospRom("crDroid", "Official downloads", "https://crdroid.net/downloads"),
    AospRom("PixelOS", "Official device downloads", "https://pixelos.net/download"),
    AospRom("Evolution X", "Official build CDN", "https://cdn.evolution-x.org/"),
    AospRom("Paranoid Android (AOSPA)", "Official site", "https://paranoidandroid.co/"),
    AospRom("Lunaris AOSP", "Official GitHub", "https://github.com/Lunaris-AOSP")
)

internal fun LazyListScope.aospItems() {
    item {
        Appear(0) {
            ScreenHeader("Official AOSP ROMs", "Tap a ROM to open its official website and download from there.")
        }
    }
    aospRoms.forEachIndexed { i, r ->
        item {
            Appear(1 + i) {
                val ctx = LocalContext.current
                Panel(r.name, r.note) {
                    Text(r.url, fontSize = 11.sp, color = TextDim)
                    Button(
                        onClick = { openBrowser(ctx, r.url) },
                        modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(22.dp)
                    ) { Text("Open website") }
                }
            }
        }
    }
    item {
        Appear(8) {
            Text(
                "Custom ROMs need an unlocked bootloader and a build made for your exact device. " +
                    "Follow each ROM's own install guide.",
                fontSize = 12.sp, color = TextDim
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Download Manager
// ---------------------------------------------------------------------------

internal fun LazyListScope.downloadItems() {
    item {
        Appear(0) { ScreenHeader("Download Manager", "Direct link downloads and ROM downloads in one place.") }
    }
    item {
        Appear(1) {
            val ctx = LocalContext.current
            var link by remember { mutableStateOf("") }
            var msg by remember { mutableStateOf<String?>(null) }
            Panel("New download", "Files are saved in Downloads/MiTool.") {
                OutlinedTextField(
                    value = link, onValueChange = { link = it; msg = null }, singleLine = true,
                    label = { Text("Direct link (https://...)") }, modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        val err = Downloads.enqueue(ctx, link)
                        msg = err ?: "Download started"
                        if (err == null) link = ""
                    },
                    enabled = link.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
                ) { Text("Download") }
                OutlinedButton(onClick = { openBrowser(ctx, "https://xmfirmwareupdater.com/") }, modifier = Modifier.fillMaxWidth()) {
                    Text("Browse for ROMs")
                }
                msg?.let { Text(it, fontSize = 12.sp, color = Accent) }
            }
        }
    }
    item {
        Appear(2) {
            val ctx = LocalContext.current
            var items by remember { mutableStateOf<List<Downloads.Item>>(emptyList()) }
            var speeds by remember { mutableStateOf<Map<Long, Double>>(emptyMap()) }
            LaunchedEffect(Unit) {
                var prev = emptyMap<Long, Long>()
                var prevT = System.currentTimeMillis()
                while (true) {
                    val now = Downloads.list(ctx)
                    val t = System.currentTimeMillis()
                    val dt = (t - prevT) / 1000.0
                    if (dt > 0) {
                        speeds = now.filter { it.status == DownloadManager.STATUS_RUNNING }.associate { d ->
                            d.id to maxOf(0.0, (d.done - (prev[d.id] ?: d.done)) / dt)
                        }
                    }
                    prev = now.associate { it.id to it.done }
                    prevT = t
                    items = now
                    delay(1000)
                }
            }
            Panel("Downloads", if (items.isEmpty()) "No downloads yet." else "Saved in Downloads/MiTool") {
                items.take(30).forEach { d ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(d.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        val pct = if (d.total > 0) d.done.toFloat() / d.total else -1f
                        if (d.status == DownloadManager.STATUS_RUNNING || d.status == DownloadManager.STATUS_PENDING) {
                            if (pct >= 0f) LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth())
                            else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val pctText = if (d.total > 0) "  ${(d.done * 100 / d.total)}%" else ""
                            val sp = speeds[d.id]
                            val speedText = if (sp != null && sp > 0) "  ${"%.1f".format(sp / 1048576.0)} MB/s" else ""
                            Text(
                                Downloads.statusText(d.status) + pctText +
                                    (if (d.total > 0) "  ${mb(d.done)} / ${mb(d.total)}" else if (d.done > 0) "  ${mb(d.done)}" else "") +
                                    speedText,
                                fontSize = 11.sp, color = if (d.status == DownloadManager.STATUS_FAILED) Danger else TextDim,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { Downloads.remove(ctx, d.id) }) {
                                Text(
                                    if (d.status == DownloadManager.STATUS_SUCCESSFUL || d.status == DownloadManager.STATUS_FAILED) "Remove" else "Cancel",
                                    color = Danger
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Reboot Manager
// ---------------------------------------------------------------------------

internal fun LazyListScope.rebootItems(a: Actions) {
    item {
        Appear(0) { ScreenHeader("Reboot Manager", "Reboot the connected fastboot phone into a chosen mode.") }
    }
    item { Appear(1) { DeviceCard(a) } }
    item {
        Appear(2) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TileRow(
                    Tile("System", Icons.Filled.Refresh, Accent) { a.reboot("system") },
                    Tile("Bootloader", Icons.Filled.Phone, Accent) { a.reboot("bootloader") },
                    Tile("Recovery", Icons.Filled.Build, Accent) { a.reboot("recovery") }
                )
                TileRow(
                    Tile("FastbootD", Icons.Filled.PlayArrow, Accent2) { a.reboot("fastboot") },
                    Tile("EDL (Qualcomm)", Icons.Filled.Warning, Danger) { a.reboot("edl") }
                )
            }
        }
    }
    item {
        Appear(3) {
            Text(
                "EDL sends 'oem edl', which only works on some Xiaomi Qualcomm phones and leaves the phone " +
                    "looking switched off (black screen). Hold the power button for about 15 seconds to leave it. " +
                    "ADB (Android mode) reboot is not available in this app.",
                fontSize = 12.sp, color = TextDim
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Fastboot commands
// ---------------------------------------------------------------------------

private fun loadSaved(ctx: Context): List<String> =
    ctx.getSharedPreferences("mitool", Context.MODE_PRIVATE).getStringSet("saved_cmds", emptySet())!!.sorted()

private fun storeSaved(ctx: Context, list: List<String>) {
    ctx.getSharedPreferences("mitool", Context.MODE_PRIVATE).edit().putStringSet("saved_cmds", list.toSet()).apply()
}

internal fun LazyListScope.commandItems(a: Actions) {
    item {
        Appear(0) { ScreenHeader("Fastboot Commands", "Run fastboot commands on the connected phone.") }
    }
    item { Appear(1) { DeviceCard(a) } }
    item {
        Appear(2) {
            val ctx = LocalContext.current
            var cmd by remember { mutableStateOf("fastboot getvar product") }
            var saved by remember { mutableStateOf(loadSaved(ctx)) }
            Panel(
                "Command",
                "Supported: getvar, oem, flashing, erase, set_active, reboot. To flash files use the Flash screen. ADB commands are not supported."
            ) {
                OutlinedTextField(
                    value = cmd, onValueChange = { cmd = it }, singleLine = true,
                    label = { Text("fastboot getvar product") }, modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { a.runCommand(cmd) }, enabled = Ui.connected && !Ui.busy && cmd.isNotBlank(),
                        modifier = Modifier.weight(1f).height(46.dp), shape = RoundedCornerShape(23.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF00382B))
                    ) { Text("Run", fontWeight = FontWeight.Bold) }
                    OutlinedButton(
                        onClick = {
                            val c = cmd.trim()
                            if (c.isNotEmpty() && c !in saved) { saved = (saved + c).sorted(); storeSaved(ctx, saved) }
                        },
                        enabled = cmd.isNotBlank()
                    ) { Text("Save") }
                }
                Text("Quick commands", fontSize = 12.sp, color = TextDim)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "getvar product", "getvar all", "getvar unlocked", "getvar current-slot",
                        "getvar max-download-size", "oem device-info"
                    ).forEach { q -> AssistChip(onClick = { cmd = "fastboot $q" }, label = { Text(q) }) }
                }
                if (saved.isNotEmpty()) {
                    Text("Saved commands", fontSize = 12.sp, color = TextDim)
                    saved.forEach { s ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { cmd = s }, modifier = Modifier.weight(1f)) {
                                Text(s, maxLines = 1)
                            }
                            TextButton(onClick = { saved = saved - s; storeSaved(ctx, saved) }) {
                                Text("X", color = Danger)
                            }
                        }
                    }
                }
            }
        }
    }
    item { Appear(3) { LogCard(maxLines = 40) } }
}

// ---------------------------------------------------------------------------
// Extract ZIP / IMG files
// ---------------------------------------------------------------------------

internal fun LazyListScope.extractItems(a: Actions) {
    item {
        Appear(0) { ScreenHeader("Extract ZIP / IMG Files", "Extract .zip, .tgz or .tar.gz and flash the .img files inside.") }
    }
    item { Appear(1) { DeviceCard(a) } }
    item {
        Appear(2) {
            Panel("Archive", "ZIP and TGZ are supported. Encrypted ZIP, 7z, RAR and payload.bin are not.") {
                Button(
                    onClick = a.pickArchive, enabled = !Ui.busy,
                    modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
                ) { Text("Choose archive") }
                Text(Ui.extractState, fontSize = 12.sp, color = if (Ui.extractState.startsWith("Failed")) Danger else TextDim)
                if (Ui.busy && Ui.extractState.startsWith("Extracting")) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        }
    }
    item {
        Appear(3) {
            Panel("Extracted files", if (Ui.extractFiles.isEmpty()) "Nothing extracted yet." else "${Ui.extractFiles.size} files") {
                Ui.extractFiles.take(100).forEach { f ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name, fontSize = 13.sp, maxLines = 1)
                            Text(mb(f.length()), fontSize = 11.sp, color = TextDim)
                        }
                        if (f.name.endsWith(".img", true)) {
                            TextButton(
                                onClick = { a.flashExtracted(f) },
                                enabled = Ui.connected && !Ui.busy
                            ) { Text("Flash", color = Accent) }
                        }
                    }
                }
                if (Ui.extractFiles.size > 100) Text("Showing the first 100 files.", fontSize = 11.sp, color = TextDim)
                if (Ui.extractFiles.isNotEmpty()) {
                    OutlinedButton(onClick = a.deleteExtracted, enabled = !Ui.busy) { Text("Delete extracted files", color = Danger) }
                }
            }
        }
    }
    item { Appear(4) { LogCard(maxLines = 20) } }
}
