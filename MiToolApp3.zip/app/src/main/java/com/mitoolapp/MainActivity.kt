package com.mitoolapp

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.CountDownLatch

// ---------------------------------------------------------------------------
// Palette (change these to re-colour the whole app)
// ---------------------------------------------------------------------------

internal val Bg = Color(0xFF060A10)
internal val CardBg = Color(0xFF0E1620)
internal val CardHi = Color(0xFF142131)
internal val Accent = Color(0xFF22D3A6)      // teal / emerald
internal val Accent2 = Color(0xFFA78BFA)     // violet
internal val Warn = Color(0xFFFBBF24)        // amber
internal val Danger = Color(0xFFF87171)
internal val TextMain = Color(0xFFE6EDF5)
internal val TextDim = Color(0xFF8DA2B8)

// ---------------------------------------------------------------------------
// Shared UI state
// ---------------------------------------------------------------------------

object Ui {
    val logs = mutableStateListOf<String>()
    var screen by mutableStateOf("home")
    var busy by mutableStateOf(false)
    var progress by mutableFloatStateOf(-1f)
    var connected by mutableStateOf(false)
    var status by mutableStateOf("No USB target")
    var info by mutableStateOf<Map<String, String>>(emptyMap())
    var partition by mutableStateOf("boot")
    var confirm by mutableStateOf<Confirm?>(null)
    var userId by mutableStateOf<String?>(null)
    var zone by mutableStateOf<String?>(null)

    // Fastboot ROM flash screen
    var romName by mutableStateOf<String?>(null)
    var romState by mutableStateOf("Not selected")
    var romOk by mutableStateOf(false)
    var romInfo by mutableStateOf<Map<String, String>>(emptyMap())
    var romScripts by mutableStateOf<List<String>>(emptyList())
    var mode by mutableStateOf("clean")
    var wipeMeta by mutableStateOf(false)
    var wipeData by mutableStateOf(false)

    // Extract screen
    var extractFiles by mutableStateOf<List<File>>(emptyList())
    var extractState by mutableStateOf("Nothing selected")

    class Confirm(
        val title: String,
        val text: String,
        val cancel: (() -> Unit)? = null,
        val action: () -> Unit
    )

    fun log(s: String) {
        logs.add(s)
        while (logs.size > 400) logs.removeAt(0)
    }

    /** Script of the ROM that matches a flashing mode: clean, save or lock. */
    fun scriptFor(m: String): String? = romScripts.firstOrNull {
        when (m) {
            "lock" -> it.contains("lock")
            "save" -> it.contains("except_storage") && !it.contains("lock")
            else -> !it.contains("lock") && !it.contains("except_storage")
        }
    }
}

class Actions(
    val connect: () -> Unit,
    val reboot: (String) -> Unit,
    val login: () -> Unit,
    val logout: () -> Unit,
    val unlock: () -> Unit,
    val pickImage: () -> Unit,
    val pickRom: () -> Unit,
    val flashNow: () -> Unit,
    val pickArchive: () -> Unit,
    val runCommand: (String) -> Unit,
    val flashExtracted: (File) -> Unit,
    val deleteExtracted: () -> Unit
)

// ---------------------------------------------------------------------------
// Activity
// ---------------------------------------------------------------------------

class MainActivity : ComponentActivity() {

    private lateinit var usb: UsbManager
    @Volatile private var fb: Fastboot? = null
    private var romRoot: File? = null

    private val prefs by lazy { getSharedPreferences("mitool", Context.MODE_PRIVATE) }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Connector.ACTION ->
                    if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) startConnect()
                    else Ui.log("USB permission denied")
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    fb?.close(); fb = null; Dev.fb = null
                    Ui.connected = false
                    Ui.status = "No USB target"
                    Ui.info = emptyMap()
                    Ui.log("Device disconnected")
                }
            }
        }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) askFlashImage(uri, Ui.partition.trim())
    }
    private val pickRom = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) prepareRom(uri)
    }

    private val pickArchive = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) extractArchive(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        val f = IntentFilter().apply {
            addAction(Connector.ACTION)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(this, usbReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)

        loadPass()?.let { Ui.userId = it["userId"] }

        val actions = Actions(
            connect = ::connect,
            reboot = ::askReboot,
            login = ::miLogin,
            logout = ::miLogout,
            unlock = ::startUnlock,
            pickImage = { pickImage.launch(arrayOf("*/*")) },
            pickRom = { pickRom.launch(arrayOf("*/*")) },
            flashNow = ::askFlashNow,
            pickArchive = { pickArchive.launch(arrayOf("*/*")) },
            runCommand = ::runCommand,
            flashExtracted = ::askFlashExtracted,
            deleteExtracted = ::deleteExtracted
        )
        setContent {
            MiToolTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Root(actions)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(usbReceiver)
    }

    // ----- helpers -----

    private fun launchTask(block: () -> Unit) {
        if (Ui.busy) { toast("Another task is running"); return }
        Ui.busy = true
        Ui.progress = -1f
        Thread {
            try {
                block()
            } catch (e: Exception) {
                Ui.log("ERROR: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                Ui.busy = false
                Ui.progress = -1f
            }
        }.start()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun requireFb(): Fastboot = fb ?: throw FastbootException("No device connected")

    private fun askBlocking(title: String, text: String): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        Ui.confirm = Ui.Confirm(title, text, cancel = { latch.countDown() }) { ok = true; latch.countDown() }
        latch.await()
        return ok
    }

    private fun loadPass(): Map<String, String>? {
        val s = prefs.getString("passToken", null) ?: return null
        return try {
            val j = JSONObject(s)
            mapOf("deviceId" to j.getString("deviceId"), "passToken" to j.getString("passToken"), "userId" to j.getString("userId"))
        } catch (e: Exception) {
            null
        }
    }

    // ----- connect -----

    private fun connect() {
        val d = Connector.find(usb)
        if (d == null) {
            toast("No fastboot device found. Boot the phone to fastboot (Vol- + Power) and connect with an OTG cable.")
            Ui.log("No fastboot device found")
            return
        }
        if (usb.hasPermission(d)) {
            startConnect()
        } else {
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pi = PendingIntent.getBroadcast(this, 0, Intent(Connector.ACTION).setPackage(packageName), flags)
            usb.requestPermission(d, pi)
        }
    }

    private fun startConnect() = launchTask {
        val d = Connector.find(usb) ?: throw FastbootException("No fastboot device found")
        fb?.close()
        val f = Connector.open(usb, d) { Ui.log("(device) $it") }
        fb = f
        Dev.fb = f
        val vars = linkedMapOf<String, String>()
        listOf(
            "unlocked" to "Unlocked", "current-slot" to "Slot",
            "max-download-size" to "Max download", "serialno" to "Serial", "version-bootloader" to "Bootloader"
        ).forEach { (k, label) -> f.getvar(k)?.let { vars[label] = it } }
        val product = f.getvar("product")
        Ui.info = vars
        Ui.connected = true
        Ui.status = product ?: "Fastboot device"
        Ui.log("Connected to ${product ?: "device"}")
    }

    // ----- Mi account + unlock -----

    private fun miLogin() = launchTask {
        val http = MiHttp()
        val pt = MiAccount.loginBrowser(http, { url ->
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        }) { Ui.log(it) }
        prefs.edit().putString("passToken", JSONObject(pt).toString()).apply()
        Ui.userId = pt["userId"]
        Ui.log("Logged in. Account ID: ${pt["userId"]}")
        detectZone(pt)
    }

    private fun detectZone(pt: Map<String, String>) {
        val http = MiHttp()
        val region = MiAccount.region(http, pt)
        val zone = if (region != null) {
            Ui.log("Account region: $region")
            MiAccount.zoneForRegion(region)
        } else {
            MiAccount.zoneByUserId(http, pt["userId"]?.toLongOrNull() ?: 0L)
        }
        if (zone != null) {
            Ui.zone = zone
            Ui.log("Data center zone: $zone")
        } else {
            Ui.log("Could not detect the server region. Please select it below.")
        }
    }

    private fun miLogout() {
        prefs.edit().remove("passToken").apply()
        Ui.userId = null
        Ui.zone = null
        Ui.log("Logged out")
    }

    private fun startUnlock() = launchTask {
        val f = requireFb()
        val pt = loadPass() ?: throw IOException("Please log in with your Xiaomi account first")
        if (Ui.zone == null) detectZone(pt)
        val zone = Ui.zone ?: throw IOException("Select the server region first")
        val domain = MiServer.DOMAINS[zone] ?: throw IOException("Unknown region")
        val service = try {
            MiAccount.getService(MiHttp(), pt)
        } catch (e: IOException) {
            if (e.message?.contains("expired") == true) miLogout()
            throw e
        }
        MiServer.unlock(f, domain, service, { Ui.log(it) }) { t, x -> askBlocking(t, x) }
    }

    // ----- flashing -----

    private fun askFlashImage(uri: Uri, part: String) {
        if (part.isBlank()) { toast("Enter a partition name first"); return }
        Ui.confirm = Ui.Confirm(
            "Flash to \"$part\"?",
            "The selected file will be written to the $part partition. A wrong image or partition can " +
                "make the phone unbootable."
        ) {
            launchTask {
                val f = requireFb()
                contentResolver.openFileDescriptor(uri, "r")!!.use { pfd ->
                    val ch = FileInputStream(pfd.fileDescriptor).channel
                    Ui.log("Flashing $part (${ch.size() / 1024 / 1024} MB)...")
                    f.flashImage(part, ch) { d, t -> Ui.progress = d.toFloat() / t }
                }
                Ui.log("Flashed $part")
            }
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment ?: "rom.tgz"
    }

    private fun prepareRom(uri: Uri) = launchTask {
        val name = displayName(uri)
        Ui.romName = name
        Ui.romOk = false
        Ui.romScripts = emptyList()
        Ui.romInfo = emptyMap()
        Ui.romState = "Extracting..."
        try {
            val base = getExternalFilesDir("rom") ?: File(cacheDir, "rom")
            base.deleteRecursively()
            Ui.log("Extracting ROM (this can take several minutes, needs free storage)...")
            contentResolver.openInputStream(uri)!!.use { Rom.extractTarGz(it, base) { m -> Ui.log(m) } }
            val root = Rom.findRoot(base) ?: throw FastbootException("No images folder found in this ROM")
            val scripts = Rom.scripts(root)
            if (scripts.isEmpty()) throw FastbootException("No flash_all script found in this ROM")
            romRoot = root
            Ui.romScripts = scripts.map { it.name }
            Ui.romInfo = linkedMapOf(
                "Build" to (Regex("(OS\\d[\\w.]*|V\\d[\\w.]*)").find(name)?.value ?: "-"),
                "Android" to (Regex("_(\\d{1,2}\\.\\d)_").find(name)?.groupValues?.get(1) ?: "-"),
                "Scripts" to scripts.size.toString()
            )
            Ui.mode = listOf("clean", "save", "lock").firstOrNull { Ui.scriptFor(it) != null } ?: "clean"
            Ui.romState = "Ready"
            Ui.romOk = true
            Ui.log("ROM ready. Choose a flashing mode.")
        } catch (e: Exception) {
            Ui.romState = "Failed"
            throw e
        }
    }

    private fun askFlashNow() {
        val name = Ui.scriptFor(Ui.mode)
        if (name == null) { toast("This ROM has no script for the selected mode"); return }
        val lock = Ui.mode == "lock"
        val wipes = Ui.mode != "save"
        Ui.confirm = Ui.Confirm(
            "Flash now ($name)?",
            (if (lock) "This ERASES ALL DATA and RE-LOCKS the bootloader. Only do this with the official " +
                "stock ROM made for exactly this phone and a matching Xiaomi/MIUI/HyperOS version. " +
                "A wrong or older ROM with a locked bootloader can brick the phone. "
            else if (wipes) "This is a clean flash and ERASES ALL DATA. "
            else "This keeps your data where possible. ") +
                (if (Ui.wipeMeta || Ui.wipeData) "Extra: ${listOfNotNull(
                    if (Ui.wipeMeta) "erase metadata" else null,
                    if (Ui.wipeData) "erase userdata" else null
                ).joinToString(" + ")}. " else "") +
                "Do not disconnect the cable or close the app while flashing. The phone will reboot at the end."
        ) {
            val wipeMeta = Ui.wipeMeta
            val wipeData = Ui.wipeData
            launchTask {
                val f = requireFb()
                val root = romRoot ?: throw FastbootException("ROM not prepared")
                var steps = Rom.parse(File(root, name))
                if (steps.isEmpty()) throw FastbootException("Could not read any fastboot steps from $name")
                val extra = ArrayList<Rom.Step>()
                if (wipeMeta) extra.add(Rom.Step.Erase("metadata"))
                if (wipeData) extra.add(Rom.Step.Erase("userdata"))
                if (extra.isNotEmpty()) {
                    val idx = steps.indexOfFirst { it is Rom.Step.Reboot }
                    steps = if (idx < 0) steps + extra else steps.take(idx) + extra + steps.drop(idx)
                }
                Ui.log("Running $name (${steps.size} steps)")
                Rom.run(f, root, steps, lock, { Ui.log(it) }) { Ui.progress = it }
                Ui.log("Flash script finished")
                (getExternalFilesDir("rom") ?: File(cacheDir, "rom")).deleteRecursively()
            }
        }
    }

    private fun askReboot(target: String) {
        val cmd = when (target) {
            "system" -> "reboot"
            "edl" -> "oem edl"
            else -> "reboot-$target"
        }
        Ui.confirm = Ui.Confirm(
            "Reboot ($target)?",
            if (target == "edl") "The phone will go to EDL mode (black screen). This only works on some Xiaomi Qualcomm phones. Hold the power button about 15 seconds to leave it."
            else "The phone will restart."
        ) {
            launchTask {
                val f = requireFb()
                try {
                    f.command(cmd, 10000)
                } catch (e: Exception) {
                    // the phone often disconnects before it answers
                    Ui.log("(device) ${e.message}")
                }
                Ui.log("Reboot sent ($target)")
            }
        }
    }

    // ----- fastboot command console -----

    private fun toFastbootCommand(t: List<String>): String? {
        val head = t[0]
        val rest = t.drop(1).joinToString(" ")
        return when (head) {
            "getvar", "erase", "set_active" -> if (rest.isBlank()) null else "$head:$rest"
            "oem", "flashing" -> if (rest.isBlank()) null else "$head $rest"
            "reboot" -> if (rest.isBlank()) "reboot" else "reboot-$rest"
            "reboot-bootloader", "reboot-recovery", "reboot-fastboot", "continue" -> head
            else -> null
        }
    }

    private fun runCommand(line: String) {
        val trimmed = line.trim()
        if (trimmed.startsWith("adb")) { toast("ADB commands are not supported. Fastboot only."); return }
        val toks = trimmed.removePrefix("fastboot").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (toks.isEmpty()) return
        val cmd = toFastbootCommand(toks)
        if (cmd == null) {
            toast("Unsupported command. Use the Flash screen to flash files.")
            return
        }
        val rest = toks.drop(1).joinToString(" ")
        val risky = toks[0] == "erase" ||
            (toks[0] in listOf("oem", "flashing") && rest.contains("lock", true) && !rest.contains("unlock", true)) ||
            rest.contains("unlock", true) || rest.contains("edl", true)
        val go = {
            launchTask {
                val f = requireFb()
                Ui.log("> fastboot ${toks.joinToString(" ")}")
                val r = try {
                    f.command(cmd, 120000)
                } catch (e: FastbootException) {
                    Ui.log("FAIL: ${e.message}")
                    return@launchTask
                }
                if (r.okay.isNotBlank()) Ui.log(r.okay)
                Ui.log("OKAY")
            }
        }
        if (risky) {
            Ui.confirm = Ui.Confirm(
                "Run this command?",
                "fastboot ${toks.joinToString(" ")}\n\nThis can erase data, change the bootloader state or make the phone unbootable."
            ) { go() }
        } else go()
    }

    // ----- extract archives -----

    private fun extractArchive(uri: Uri) = launchTask {
        val name = displayName(uri)
        val base = File(getExternalFilesDir(null) ?: cacheDir, "extracted")
        base.deleteRecursively()
        base.mkdirs()
        Ui.extractFiles = emptyList()
        Ui.extractState = "Extracting $name..."
        try {
            contentResolver.openInputStream(uri)!!.use { ins ->
                if (name.endsWith(".zip", true)) Rom.extractZip(ins, base) { Ui.log(it) }
                else Rom.extractTarGz(ins, base) { Ui.log(it) }
            }
            Ui.extractFiles = base.walkTopDown().filter { it.isFile }.sortedBy { it.name }.toList()
            Ui.extractState = "Done: ${Ui.extractFiles.size} files from $name"
        } catch (e: Exception) {
            Ui.extractState = "Failed: ${e.message ?: "unsupported archive"}"
            throw e
        }
    }

    private fun askFlashExtracted(file: File) {
        val part = file.name.removeSuffix(".img").removeSuffix(".IMG").substringBefore('.')
        Ui.confirm = Ui.Confirm(
            "Flash ${file.name}?",
            "This writes the image to the \"$part\" partition. A wrong image or partition can make the phone unbootable."
        ) {
            launchTask {
                val f = requireFb()
                Ui.log("Flashing $part from ${file.name}...")
                RandomAccessFile(file, "r").use { raf ->
                    f.flashImage(part, raf.channel) { d, t -> Ui.progress = d.toFloat() / t }
                }
                Ui.log("Flashed $part")
            }
        }
    }

    private fun deleteExtracted() {
        File(getExternalFilesDir(null) ?: cacheDir, "extracted").deleteRecursively()
        Ui.extractFiles = emptyList()
        Ui.extractState = "Nothing selected"
        Ui.log("Extracted files deleted")
    }
}

// ---------------------------------------------------------------------------
// Theme (always dark)
// ---------------------------------------------------------------------------

private val Scheme = darkColorScheme(
    primary = Accent, onPrimary = Color(0xFF00382B),
    primaryContainer = Color(0xFF0B3B33), onPrimaryContainer = Color(0xFFB7F5E4),
    secondary = Accent2, secondaryContainer = CardHi, onSecondaryContainer = TextMain,
    background = Bg, onBackground = TextMain,
    surface = CardBg, onSurface = TextMain,
    surfaceVariant = CardHi, onSurfaceVariant = TextDim,
    error = Danger, outline = Color(0xFF2A3B4F)
)

@Composable
fun MiToolTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}

// ---------------------------------------------------------------------------
// Root: content + bottom navigation
// ---------------------------------------------------------------------------

@Composable
private fun Root(a: Actions) {
    val view = LocalView.current
    SideEffect { view.keepScreenOn = Ui.busy }
    BackHandler(enabled = Ui.screen != "home") { Ui.screen = "home" }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (Ui.screen) {
                "flash" -> flashItems(a)
                "unlock" -> unlockItems(a)
                "logs" -> logsItems()
                "firmware" -> firmwareItems()
                "aosp" -> aospItems()
                "downloads" -> downloadItems()
                "reboot" -> rebootItems(a)
                "commands" -> commandItems(a)
                "extract" -> extractItems(a)
                else -> homeItems(a)
            }
        }
        NavigationBar(containerColor = CardBg) {
            NavItem("home", "Home", Icons.Filled.Home)
            NavItem("flash", "Flash", Icons.Filled.PlayArrow)
            NavItem("logs", "Logs", Icons.Filled.List)
        }
    }

    Ui.confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { Ui.confirm = null; c.cancel?.invoke() },
            containerColor = CardBg,
            title = { Text(c.title) },
            text = { Text(c.text) },
            confirmButton = { TextButton(onClick = { Ui.confirm = null; c.action() }) { Text("Continue") } },
            dismissButton = { TextButton(onClick = { Ui.confirm = null; c.cancel?.invoke() }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.NavItem(id: String, label: String, icon: ImageVector) {
    NavigationBarItem(
        selected = Ui.screen == id,
        onClick = { Ui.screen = id },
        icon = { Icon(icon, null) },
        label = { Text(label) }
    )
}

// ---------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------

private fun LazyListScope.homeItems(a: Actions) {
    item { Appear(0) { TopBar() } }
    item { Appear(1) { DeviceCard(a) } }

    item { Appear(2) { SectionHeader("Flash & Firmware", "FLASH", Accent) } }
    item {
        Appear(3) {
            TileRow(
                Tile("Firmware Finder", Icons.Filled.Search, Accent) { Ui.screen = "firmware" },
                Tile("Fastboot Flash", Icons.Filled.PlayArrow, Accent) { Ui.screen = "flash" },
                Tile("Flash Image", Icons.Filled.Build, Accent) { Ui.screen = "flash" }
            )
        }
    }

    item { Appear(4) { SectionHeader("System & Modify", "MODIFY", Accent2) } }
    item {
        Appear(5) {
            TileRow(Tile("Extract ZIP / IMG Files", Icons.Filled.Info, Accent2) { Ui.screen = "extract" })
        }
    }

    item { Appear(6) { SectionHeader("Xiaomi & Device", "XIAOMI", Warn) } }
    item {
        Appear(7) {
            TileRow(
                Tile("Bootloader Unlock", Icons.Filled.Lock, Warn) { Ui.screen = "unlock" },
                Tile("Official AOSP ROMs", Icons.Filled.Phone, Warn) { Ui.screen = "aosp" }
            )
        }
    }

    item { Appear(8) { SectionHeader("Tools & Utilities", "TOOLS", Accent) } }
    item {
        Appear(9) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TileRow(
                    Tile("Reboot Manager", Icons.Filled.Refresh, Accent) { Ui.screen = "reboot" },
                    Tile("Fastboot Commands", Icons.Filled.PlayArrow, Accent) { Ui.screen = "commands" },
                    Tile("Download Manager", Icons.Filled.Home, Accent) { Ui.screen = "downloads" }
                )
                TileRow(Tile("Operation Logs", Icons.Filled.List, Accent2) { Ui.screen = "logs" })
            }
        }
    }

    item {
        Appear(10) {
            Text(
                "Unlocking and flashing can erase all data, void warranty or brick the phone. " +
                    "Use at your own risk. Unlock protocol based on MiForge/MiUnlockTool (Apache-2.0) " +
                    "and MiForge/migate (MIT).",
                fontSize = 11.sp, color = TextDim
            )
        }
    }
}

@Composable
internal fun TopBar() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Accent),
            contentAlignment = Alignment.Center
        ) { Text("Mi", color = Color(0xFF00382B), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("MiTool", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Fastboot Edition", fontSize = 12.sp, color = TextDim)
        }
        Pill(if (Ui.connected) "Connected" else "No device", if (Ui.connected) Accent else Danger)
    }
}

@Composable
internal fun Pill(text: String, color: Color) {
    Text(
        text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = color,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
internal fun SectionHeader(title: String, tag: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = color)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f).height(1.dp).background(color.copy(alpha = 0.35f)))
        Spacer(Modifier.width(10.dp))
        Pill(tag, color)
    }
}

internal class Tile(val label: String, val icon: ImageVector, val color: Color, val onClick: () -> Unit)

@Composable
internal fun TileRow(vararg tiles: Tile) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        tiles.forEach { t -> ToolTile(t, Modifier.weight(1f)) }
        repeat(3 - tiles.size) { Spacer(Modifier.weight(1f)) }
    }
}

@Composable
private fun ToolTile(t: Tile, modifier: Modifier) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.94f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium), label = "tile"
    )
    Card(
        modifier = modifier.height(96.dp).scale(scale)
            .clickable(interactionSource = source, indication = null, onClick = t.onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardHi),
        border = BorderStroke(1.dp, t.color.copy(alpha = 0.35f))
    ) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(
                Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(t.color.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) { Icon(t.icon, null, tint = t.color, modifier = Modifier.size(20.dp)) }
            Text(t.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
        }
    }
}

// ---------------------------------------------------------------------------
// Device card
// ---------------------------------------------------------------------------

@Composable
internal fun DeviceCard(a: Actions) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, Accent.copy(alpha = 0.3f))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(10.dp).clip(CircleShape).background(if (Ui.connected) Accent else Danger)
                )
                Spacer(Modifier.width(8.dp))
                Text("Connected Device", fontSize = 13.sp, color = if (Ui.connected) Accent else TextDim)
            }
            Text(Ui.status, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            if (Ui.info.isNotEmpty()) {
                Ui.info.entries.toList().chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (k, v) -> InfoChip(k, v, Modifier.weight(1f)) }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            } else {
                Text("Boot the target phone to fastboot, connect it with a USB OTG cable, then tap Connect.",
                    fontSize = 12.sp, color = TextDim)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = a.connect, enabled = !Ui.busy,
                    modifier = Modifier.weight(1f).height(46.dp), shape = RoundedCornerShape(23.dp)
                ) {
                    Icon(Icons.Filled.Refresh, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (Ui.connected) "Reconnect" else "Connect")
                }
                if (Ui.connected) {
                    FilledTonalButton(onClick = { a.reboot("system") }, enabled = !Ui.busy) { Text("Reboot") }
                }
            }
        }
    }
}

@Composable
internal fun InfoChip(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(CardHi).padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(label, fontSize = 10.sp, color = TextDim)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

// ---------------------------------------------------------------------------
// Fastboot Flash (Stock ROM)
// ---------------------------------------------------------------------------

@Composable
internal fun StepCard(
    n: Int, title: String, subtitle: String, trailing: @Composable () -> Unit = {},
    body: (@Composable () -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, Color(0xFF223246))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(28.dp).clip(CircleShape).background(Accent.copy(alpha = 0.2f))
                        .border(1.dp, Accent, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("$n", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Accent) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, fontSize = 12.sp, color = TextDim)
                }
                trailing()
            }
            body?.invoke()
        }
    }
}

private fun LazyListScope.flashItems(a: Actions) {
    item {
        Appear(0) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TopBar()
                Spacer(Modifier.height(4.dp))
                Text("Fastboot Flash (Stock ROM)", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (Ui.connected) "Target: ${Ui.status}" else "USB target disconnected. Connect from Home.",
                    fontSize = 12.sp, color = if (Ui.connected) Accent else Danger
                )
            }
        }
    }

    item {
        Appear(1) {
            StepCard(1, "Select TGZ ROM", "Choose Xiaomi Fastboot ROM (.tgz)", trailing = {
                OutlinedButton(onClick = a.pickRom, enabled = !Ui.busy, border = BorderStroke(1.dp, Accent)) {
                    Text("Browse TGZ", color = Accent)
                }
            })
        }
    }

    item {
        Appear(2) {
            val stateColor = when (Ui.romState) {
                "Ready" -> Accent
                "Failed" -> Danger
                "Extracting..." -> Warn
                else -> TextDim
            }
            StepCard(2, "Extract & Prepare", "Extract archive and find flash scripts",
                trailing = { Text(Ui.romState, fontSize = 12.sp, color = stateColor, fontWeight = FontWeight.SemiBold) },
                body = {
                    Text(
                        Ui.romName ?: "No ROM selected",
                        fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CardHi).padding(10.dp)
                    )
                    if (Ui.busy && Ui.romState == "Extracting...") LinearProgressIndicator(Modifier.fillMaxWidth())
                })
        }
    }

    item {
        Appear(3) {
            StepCard(3, "ROM Information", "Detected from the file name and scripts", body = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Build", "Android", "Scripts").forEach { k ->
                        InfoChip(k, Ui.romInfo[k] ?: "-", Modifier.weight(1f))
                    }
                }
            })
        }
    }

    item {
        Appear(4) {
            StepCard(4, "Flashing Mode", "Select a flashing method", body = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeButton("Clean All", "clean", Accent, Modifier.weight(1f))
                    ModeButton("Save User Data", "save", Accent, Modifier.weight(1f))
                    ModeButton("Clean All + Lock", "lock", Danger, Modifier.weight(1f))
                }
                if (Ui.mode == "lock") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, null, tint = Danger, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Re-locks the bootloader. Use only the exact official ROM for this phone.",
                            fontSize = 11.sp, color = Danger)
                    }
                }
            })
        }
    }

    item {
        Appear(5) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                border = BorderStroke(1.dp, Color(0xFF223246))
            ) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                    Text("Options (Optional)", fontSize = 13.sp, color = TextDim)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = Ui.wipeMeta, onCheckedChange = { Ui.wipeMeta = it })
                        Text("Wipe Metadata", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Checkbox(checked = Ui.wipeData, onCheckedChange = { Ui.wipeData = it })
                        Text("Wipe Userdata", fontSize = 13.sp, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }

    item {
        Appear(6) {
            val ok = Ui.connected && Ui.romOk && Ui.scriptFor(Ui.mode) != null && !Ui.busy
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = a.flashNow, enabled = ok,
                    modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF00382B))
                ) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Flash Now", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    when {
                        !Ui.connected -> "Connect a fastboot device first"
                        !Ui.romOk -> "Select a ROM with a supported flash script"
                        Ui.scriptFor(Ui.mode) == null -> "This ROM has no script for the selected mode"
                        else -> "Ready: ${Ui.scriptFor(Ui.mode)}"
                    },
                    fontSize = 12.sp, color = TextDim
                )
            }
        }
    }

    item { Appear(7) { LogCard(maxLines = 30) } }

    item {
        Appear(8) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                border = BorderStroke(1.dp, Color(0xFF223246))
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Flash single image", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = Ui.partition, onValueChange = { Ui.partition = it },
                        label = { Text("Partition (boot, recovery, vbmeta...)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = a.pickImage, enabled = Ui.connected && !Ui.busy,
                        modifier = Modifier.fillMaxWidth().height(46.dp), shape = RoundedCornerShape(23.dp)
                    ) { Text("Choose file and flash") }
                }
            }
        }
    }
}

@Composable
private fun ModeButton(label: String, mode: String, color: Color, modifier: Modifier) {
    val available = Ui.scriptFor(mode) != null
    val selected = Ui.mode == mode && available
    val bg by animateColorAsState(if (selected) color.copy(alpha = 0.2f) else CardHi, label = "modeBg")
    Box(
        modifier.height(54.dp).alpha(if (available) 1f else 0.35f)
            .clip(RoundedCornerShape(14.dp)).background(bg)
            .border(1.dp, if (selected) color else Color(0xFF2A3B4F), RoundedCornerShape(14.dp))
            .clickable(enabled = available) { Ui.mode = mode }
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2,
            color = if (selected) color else TextMain, textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

// ---------------------------------------------------------------------------
// Unlock
// ---------------------------------------------------------------------------

private fun LazyListScope.unlockItems(a: Actions) {
    item {
        Appear(0) {
            Column {
                TopBar()
                Spacer(Modifier.height(8.dp))
                Text("Bootloader Unlock", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Official Xiaomi unlock in 3 steps.", fontSize = 12.sp, color = TextDim)
            }
        }
    }
    item { Appear(1) { DeviceCard(a) } }

    item {
        Appear(2) {
            StepCard(2, "Xiaomi account",
                if (Ui.userId != null) "Logged in. Account ID: ${Ui.userId}"
                else "Opens Xiaomi's own login page in your browser, then come back here.",
                body = {
                    if (Ui.userId == null) {
                        Button(
                            onClick = a.login, enabled = !Ui.busy,
                            modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
                        ) { Text("Login with Xiaomi account") }
                    } else {
                        OutlinedButton(onClick = a.logout, enabled = !Ui.busy) { Text("Log out") }
                        Text("Server region", fontSize = 12.sp, color = TextDim)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MiServer.DOMAINS.keys.forEach { z ->
                                FilterChip(selected = Ui.zone == z, onClick = { Ui.zone = z }, label = { Text(z) })
                            }
                        }
                    }
                })
        }
    }

    item {
        Appear(3) {
            StepCard(3, "Unlock",
                "Needs fastboot mode, OTG connection, the phone's Mi account and Xiaomi's unlock permission.",
                body = {
                    Button(
                        onClick = a.unlock,
                        enabled = Ui.connected && Ui.userId != null && !Ui.busy,
                        modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Warn, contentColor = Color(0xFF3A2A00))
                    ) { Text("Unlock bootloader", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                })
        }
    }

    item { Appear(4) { LogCard(maxLines = 20) } }
}

// ---------------------------------------------------------------------------
// Logs
// ---------------------------------------------------------------------------

private fun LazyListScope.logsItems() {
    item {
        Appear(0) {
            Column {
                TopBar()
                Spacer(Modifier.height(8.dp))
                Text("Operation Logs", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
    item { Appear(1) { LogCard(maxLines = 400) } }
}

@Composable
internal fun LogCard(maxLines: Int) {
    val clipboard = LocalClipboardManager.current
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, Color(0xFF223246))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Info, null, tint = Accent, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Log / Progress", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                TextButton(onClick = { clipboard.setText(AnnotatedString(Ui.logs.joinToString("\n"))) }) { Text("Copy") }
                TextButton(onClick = { Ui.logs.clear() }) { Text("Clear") }
            }
            if (Ui.busy) {
                if (Ui.progress in 0f..1f) LinearProgressIndicator(progress = { Ui.progress }, modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            Text(
                if (Ui.logs.isEmpty()) "Nothing yet." else Ui.logs.takeLast(maxLines).joinToString("\n"),
                fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextMain,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CardHi).padding(10.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Entrance animation
// ---------------------------------------------------------------------------

@Composable
internal fun Appear(index: Int, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(50L * index); visible = true }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(spring(stiffness = Spring.StiffnessLow)) +
            slideInVertically(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) { it / 3 }
    ) { content() }
}
